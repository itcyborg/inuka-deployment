<?php

use App\Http\Controllers\AccumulatedLeaveDaysController;
use App\Http\Controllers\ApiTokenController;
use App\Http\Controllers\LeaveApprovalFlowController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\LeaveTypeController;
use App\Http\Controllers\StatisticsController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::middleware(['json'])->group(function(){
    Route::post('leave/unpaid',[LeaveController::class,'unpaidLeave']);
    Route::any('leave/stats',[StatisticsController::class,'totalLeaveRequests']);
    Route::get('leave/{id}/report',[LeaveController::class,'report']);
    Route::any('leave/staff/stats',[StatisticsController::class,'leaveRequest']);
    Route::any('stats',[StatisticsController::class,'totalLeaveRequests']);
    Route::any('staff/stats',[StatisticsController::class,'leaveRequest']);
    Route::post('leave/approve/{id}',[LeaveController::class,'approve']);
    Route::post('leave/reject/{id}',[LeaveController::class,'reject']);
    Route::get('leave/staff/{id}',[LeaveController::class,'listStaff']);
    Route::get('leave/filter',[LeaveController::class,'filterRequest'])->middleware('filter');
    Route::resource('leave','LeaveController');
    Route::resource('leave-flow','LeaveApprovalFlowController');
    Route::resource('leave-type','LeaveTypeController');
    Route::post('accumulated_days',[AccumulatedLeavedaysController::class,'index']);
    Route::post('accumulated_days/{id}/reset-debt',[AccumulatedLeavedaysController::class,'store']);
});
Route::post('leave/cache/refresh',function (){
    dd(Artisan::call('cache:clear'));
});
Route::post('token',[ApiTokenController::class,'issuePassportToken'])->middleware('passport-json');
