<?php

namespace Database\Seeders;

use App\RolePermission;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissionsJson = json_decode(file_get_contents(
            database_path('data/json/permissions.json') 
        ));

        DB::table('permissions')->truncate();

        $permissionData = [];
        $permissionsArray=[];
        $permissions=[];

        foreach ($permissionsJson as $item) {
            $permissionsArray[]=['name'=>$item->name,'description'=>$item->description];
        }

        foreach ($permissionsArray as $permission) {
            if(!in_array($permission['name'],$permissions)) {
                $permissions[] = $permission['name'];
                $permissionData[] = ['name' => $permission['name'], 'description' => $permission['description'], 'created_at' => now(), 'updated_at' => now()];
            }
        }

//        dd($permissionData);
        DB::table('permissions')->insert($permissionData);

        RolePermission::updateOrCreate ([
            'role_id'=>38
        ],[
            'role_id'=>38,
            'permissions'=>$permissions
        ]);
        RolePermission::updateOrCreate([
            'role_id'=>1
        ],[
            'role_id'=>1,
            'permissions'=>$permissions
        ]);
        RolePermission::updateOrCreate([
            'role_id'=>11
        ],[
            'role_id'=>11,
            'permissions'=>$permissions
        ]);
        RolePermission::updateOrCreate([
            'role_id'=>35
        ],[
            'role_id'=>35,
            'permissions'=>$permissions
        ]);
    }
}
