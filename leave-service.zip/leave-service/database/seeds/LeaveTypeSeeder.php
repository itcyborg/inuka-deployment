<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LeaveTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('leave_types')->truncate();
        $leaveTypes=[
            'Annual Leave'=>21,
            'Paid Maternity Leave'=>90,
            'Compassionate Leave (Spouse/Child)'=>14,
            'Compassionate Leave (Parent)'=>7,
            'Compassionate Leave (Parent/Sibling-in-Law)'=>3,
            'Unpaid Maternity Leave'=>90,
            'Paternity Leave'=>14,
            'Unpaid Leave'=>0,
            'Sick Leave'=>14,
        ];
        $data=[];
        foreach ($leaveTypes as $leaveType=>$days) {
            $data[]=['name'=>$leaveType,'days'=>$days,'created_at'=>now(),'updated_at'=>now()];
        }
        \App\LeaveType::insert($data);
        echo "Leave types migration completed.".PHP_EOL;
    }
}
