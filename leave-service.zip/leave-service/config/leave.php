<?php

return [

    /**
     * -----------------------------------------------------------------------------------------------------------------
     * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     * #################################################################################################################
     *
     * probation_period:  Probation period in months
     *
     */

    'probation_period'=> 3,


    /**
     * Send a reminder of leave ending soon
     * number of days before sending the reminder
     */
    'ending_reminder'=>env('ENDING_REMINDER',2),

    /**
     * Send a reminder of leave requires approval
     * number of days before sending the reminder
     */
    'approval_reminder'=>env('APPROVAL_REMINDER',2),


    /**
     * The rate at which leave days are accumulated in a month
     *
     *
     * rate
     *
     */

    'rate'=>env('ACCUMULATION_RATE','1.75'),


    /**
     * Fiscal month - the month which the year starts
     *
     * fiscal_month
     *
     */

    'fiscal_month'=>env('FISCAL_MONTH','01'),


    /**
     * Fiscal day - the day of the month which the year starts
     *
     * fiscal_day
     *
     */

    'fiscal_day'=>env('FISCAL_DAY','01'),



    /**
     * Approval days - the minimum number of days which should be allowed for approval of non-emergency leaves, i.e annual leave
     *
     * approval_days
     *
     */

    'approval_days'=>env('APPROVAL_DAYS',7),



    /**
     * Service name - the name of the service that should be used in providers and services i.e logs, notifications and telescope
     *
     * service_name
     *
     */

    'service_name'=>env('SERVICE_NAME','leave'),


    /**
     * Service level notifications such as errors, system dependencies failures, etc
     */

    'service_errors'=>[

        /**
         * No approver defined notification email address
         */

        'approver'=>env('DEFAULT_ERROR_NOTIFICATION_EMAIL','hr@app.com'),

        /**
         * Calendar connection/ communication errors
         */

        'calendar'=>env('DEFAULT_ERROR_NOTIFICATION_EMAIL','it@app.com'),

        /**
         * Staff role not defined
         */

        'staff_role'=>env('DEFAULT_ERROR_NOTIFICATION_EMAIL','hr@app.com'),

        /**
         * Leave approval flow not defined
         */

        'approval_flow'=>env('DEFAULT_ERROR_NOTIFICATION_EMAIL','hr@app.com'),

        /**
         * Leave type not defined
         */

        'leave_type'=>env('DEFAULT_ERROR_NOTIFICATION_EMAIL','hr@app.com'),

    ],


    /**
     * Auth Client id - the Identifier for the client to be used for authentication
     *
     * auth_client_id
     *
     */

    'auth_client_id'=>env('AUTH_CLIENT_ID','1'),
];