<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

/**
 * @method static where(string $string, string $string1)
 */
class Staff extends Model
{

    use Notifiable;

    protected $table='hrm_staff';

    public function role()
    {
        return $this->hasOne(Role::class,'staff','id');
    }

    public function leave()
    {
        return $this->hasMany(Leave::class,'staff_id','id');
    }
}
