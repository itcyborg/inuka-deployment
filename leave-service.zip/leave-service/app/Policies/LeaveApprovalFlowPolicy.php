<?php

namespace App\Policies;

use App\Http\Controllers\Authorize;
use App\LeaveApprovalFlow;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LeaveApprovalFlowPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any leave approval flows.
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_list_approval_flows');
    }

    /**
     * Determine whether the user can view the leave approval flow.
     *
     * @param User $user
     * @param LeaveApprovalFlow $leaveApprovalFlow
     * @return mixed
     */
    public function view(User $user, LeaveApprovalFlow $leaveApprovalFlow)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_view_approval_flows');
    }

    /**
     * Determine whether the user can create leave approval flows.
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_create_approval_flow');
    }

    /**
     * Determine whether the user can update the leave approval flow.
     *
     * @param User $user
     * @param LeaveApprovalFlow $leaveApprovalFlow
     * @return mixed
     */
    public function update(User $user, LeaveApprovalFlow $leaveApprovalFlow)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_update_approval_flow');
    }

    /**
     * Determine whether the user can delete the leave approval flow.
     *
     * @param User $user
     * @param LeaveApprovalFlow $leaveApprovalFlow
     * @return mixed
     */
    public function delete(User $user, LeaveApprovalFlow $leaveApprovalFlow)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_delete_approval_flow');
    }

    /**
     * Determine whether the user can restore the leave approval flow.
     *
     * @param User $user
     * @param LeaveApprovalFlow $leaveApprovalFlow
     * @return mixed
     */
    public function restore(User $user, LeaveApprovalFlow $leaveApprovalFlow)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_restore_approval_flow');
    }

    /**
     * Determine whether the user can permanently delete the leave approval flow.
     *
     * @param User $user
     * @param LeaveApprovalFlow $leaveApprovalFlow
     * @return mixed
     */
    public function forceDelete(User $user, LeaveApprovalFlow $leaveApprovalFlow)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_destroy_approval_flow');
    }
}
