<?php

namespace App\Policies;

use App\Http\Controllers\Authorize;
use App\LeaveType;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LeaveTypePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any leave types.
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_list_leave_types');
    }

    /**
     * Determine whether the user can view the leave type.
     *
     * @param User $user
     * @param LeaveType $leaveType
     * @return mixed
     */
    public function view(User $user, LeaveType $leaveType)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_view_leave_type');
    }

    /**
     * Determine whether the user can create leave types.
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_create_leave_types');
    }

    /**
     * Determine whether the user can update the leave type.
     *
     * @param User $user
     * @param LeaveType $leaveType
     * @return mixed
     */
    public function update(User $user, LeaveType $leaveType)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_update_leave_types');
    }

    /**
     * Determine whether the user can delete the leave type.
     *
     * @param User $user
     * @param LeaveType $leaveType
     * @return mixed
     */
    public function delete(User $user, LeaveType $leaveType)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_delete_leave_types');
    }

    /**
     * Determine whether the user can restore the leave type.
     *
     * @param User $user
     * @param LeaveType $leaveType
     * @return mixed
     */
    public function restore(User $user, LeaveType $leaveType)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_restore_leave_types');
    }

    /**
     * Determine whether the user can permanently delete the leave type.
     *
     * @param User $user
     * @param LeaveType $leaveType
     * @return mixed
     */
    public function forceDelete(User $user, LeaveType $leaveType)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_destroy_leave_types');
    }
}
