<?php

namespace App\Policies;

use App\Http\Controllers\Authorize;
use App\Leave;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

/**
 * Class LeavePolicy
 * @package App\Policies
 */
class LeavePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any leaves_
     *
     * @param User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_list_leaves');
    }

    /**
     * Determine whether the user can view the leave.
     *
     * @param User $user
     * @param Leave $leave
     * @return mixed
     */
    public function view(User $user, Leave $leave)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_view_leave');
    }

    /**
     * Determine whether the user can create leaves_
     *
     * @param User $user
     * @return mixed
     */
    public function create(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_create_leave');
    }

    /**
     * Determine whether the user can update the leave.
     *
     * @param User $user
     * @param Leave $leave
     * @return mixed
     */
    public function update(User $user, Leave $leave)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_update_leave');
    }

    /**
     * Determine whether the user can delete the leave.
     *
     * @param User $user
     * @param Leave $leave
     * @return mixed
     */
    public function delete(User $user, Leave $leave)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_delete_leave');
    }

    /**
     * Determine whether the user can restore the leave.
     *
     * @param User $user
     * @param Leave $leave
     * @return mixed
     */
    public function restore(User $user, Leave $leave)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_restore_leave');
    }

    /**
     * Determine whether the user can permanently delete the leave.
     *
     * @param User $user
     * @param Leave $leave
     * @return mixed
     */
    public function forceDelete(User $user, Leave $leave)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_destroy_leave');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function approve(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_approve_leave');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function reject(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_reject_leave');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function listStaff(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_view_staff_leave');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function filter(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_filter_leaves');
    }

    public function unpaidLeave(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_unpaid_leave');
    }

    public function report(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'leaves_report_from_leave');
    }
}
