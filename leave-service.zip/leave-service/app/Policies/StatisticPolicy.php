<?php

namespace App\Policies;

use App\Http\Controllers\Authorize;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class StatisticPolicy
{
    use HandlesAuthorization;

    function totalLeaveRequests(User $user): bool
    {
        $role = Authorize::getRole($user);
        return Authorize::action($role, 'leaves_view_leave_statistics');
    }


    function leaveRequest(User $user): bool
    {
        $role = Authorize::getRole($user);
        return Authorize::action($role, 'leaves_view_staff_leave_statistics');
    }
}
