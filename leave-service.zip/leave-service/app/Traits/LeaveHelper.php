<?php

namespace App\Traits;

use App\Leave;
use App\Leave\Response;
use App\LeaveApprovalFlow;
use App\LeaveType;
use App\Notifications\CalendarServiceIssueNotification;
use App\Notifications\LeaveTypeNotFound;
use App\Notifications\NotifyRequesterNewLeaveRequestApproved;
use App\Notifications\NotifyRequesterNewLeaveRequestRejected;
use App\Notifications\NotifyStaffLeaveFailedApprovalDateLate;
use App\Notifications\RoleApprovalFlowNotFound;
use App\Notifications\StaffRoleNotFound;
use App\Role;
use App\Staff;
use Carbon\Carbon;
use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\RequestOptions;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Notification;
use Throwable;

/**
 * Trait LeaveHelper
 * @package App\Traits
 */
trait LeaveHelper
{
    /**
     * @param $data
     * @return array
     * @throws Exception
     */
    protected static function getRequiredApprovers($data)
    {
        $newData=[];

        /**
         * if hq then require manager
         */

        if($data['branch'] ==1){
            $newData['manager_approval']=1;
        }else{
            $newData['manager_approval']=0;
        }

        $role=Role::where('staff',$data['staff_id'])->first();
        if(!$role){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffRoleNotFound($data['staff_id']));
            Response::make(422,'No role defined for this staff. A notification has been sent to the relevant party.');
        }
        $approvalFlow=LeaveApprovalFlow::where('role_id',$role->role)->first();
        if($approvalFlow){
            $newData['manager_approval']=$approvalFlow->manager_approval;
            $flows=$approvalFlow->flow;
            foreach ($flows as $flow){
                if(isset($flow['col_prefix_name'])) {
                    $newData[$flow['col_prefix_name'].'_req'] = 1;
                }
            }
            $data=array_merge($newData,$data);
        }else{
            Notification::route('mail',Config::get('leave.service_errors.approval_flow'))->notify(new RoleApprovalFlowNotFound($role->role));
            Response::make(422,'No leave approver has been defined for this staff role. This has been reported to the relevant party.');
        }
        return $data;
    }

    /**
     * @param $data
     * @param $bearer
     *
     * @return bool|Application|ResponseFactory|Response
     * @throws Exception
     */
    protected static function validateBeforeSave($data, $bearer) {
        // check if start date is in the past
        if(Carbon::parse($data['date_from'])->isPast()){
            Response::make(400,'Invalid leave start date.');
        }

        // check if end date is not before start date

        if(Carbon::parse($data['date_to'])->isBefore(Carbon::parse($data['date_from']))){
            Response::make(400,'Invalid leave end date.');
        }

        // validate if allowed approval days is defined and whether the leave satisfies it
        $allowedApprovalDays=env('APPROVAL_DAYS',0);
        $earliestApprovalDate=Carbon::parse($data['date_requested'])->addDays($allowedApprovalDays);

        // if earliest approval date is same as date from
        if($earliestApprovalDate->isSameDay(Carbon::parse($data['date_from'])) || $earliestApprovalDate->isAfter(Carbon::parse($data['date_from']))){
            Response::make(400,'Invalid dates selected as starting date should allow for '.$allowedApprovalDays .' from date of requesting.');
        }


        $client=new Client([
            'headers'=>[
                'authorization'=>'Bearer '.\Illuminate\Support\Facades\Request::bearerToken()
            ]
        ]);
        $uri=env('HOLIDAY_SERVICE').'/api/holiday/find';
        try {
            $response = $client->post($uri, [
                RequestOptions::JSON => [
                    'start_date' => $data['date_from'],
                    'end_date' => $data['date_to']
                ]
            ]);
            if ($response->getStatusCode() == 200) {
                $response = json_decode($response->getBody()->getContents(), false);
                $days = count($response);
                $proposed_date_to = Carbon::parse($data['date_to'])->addDays($days);
                if ($proposed_date_to->isWeekend()) {
                    $next_date = $proposed_date_to->nextWeekday();
                    foreach ($response as $holiday) {
                        if (Carbon::parse($holiday->calendar_date)->equalTo($next_date)) {
                            $data['date_to'] = $proposed_date_to->nextWeekday()->toDateString();
                        } else {
                            $data['date_to'] = $next_date->toDateString();
                        }
                    }
                }
            }
        }catch (ClientException | Throwable $e){
            Notification::route('mail',Config::get('leave.service_errors.calendar'))->notify(new CalendarServiceIssueNotification($e));
            Response::make(422,'A system error has occurred. Please try again later.');
        }
        return true;
    }

    protected static function approveRequest($leave,$comments){
        // check if leave has already been approved
        if($leave->status!==self::$__PENDING){
            if($leave->status==self::$__APPROVED){
                Response::make(422,'This leave request had already been approved.');
            }
            if($leave->status==self::$__REJECTED){
                Response::make(422,'This leave request had already been rejected. Reason:'.$leave->reject_notes);
            }
        }

        // check if dates are valid
        $leaveStartDate=Carbon::parse($leave->date_from);

        // check if approval date is not on / before start date
        if($leaveStartDate->isToday() && $leaveStartDate->isPast()){
            Staff::find($leave->staff_id)->notify(new NotifyStaffLeaveFailedApprovalDateLate($leave));
            Response::make(422,'This leave cannot be approved because it start date is past. Please update the leave request or create a new one.');
        }

        // get the staff role
        $staffRole=Role::where('staff',$leave->staff_id)->first();
        if(!$staffRole){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffRoleNotFound($leave->staff_id));
            Response::make(422,'Staff does not have a role defined in file.');
        }

        // get the staff role approval flow
        $flow=LeaveApprovalFlow::where('role_id',$staffRole->role)->first();
        if(!$flow){
            Notification::route('mail',Config::get('leave.service_errors.approval_flow'))->notify(new RoleApprovalFlowNotFound($staffRole->role));
            Response::make(422,'Staff role approval flow has been defined in file.');
        }

        $leave=$leave->toArray();

        // get the approver role
        $approverRole=Role::where('staff',Auth::user()->staff_id)->first();
        if(!$approverRole){
            Response::make(422,'The logged in user does not have a role assigned to effect any approval');
        }


        $getIndexes=function ($flows){
            $items=[];
            foreach ($flows as $flow) {
                $items[]=$flow['index'];
            }
            return $items;
        };

        $getCurrentApproverIndex=function($flows,$role){
            $index=null;
            foreach ($flows as $flow) {
                if($flow['role']==$role){
                    $index=$flow['index'];
                }
            }
            return $index;
        };

        // check if the current user has role to approve the leave request
        $index=$getCurrentApproverIndex($flow->flow,$approverRole->role);
        $indexes=$getIndexes($flow->flow);
        if(!in_array($index,$indexes)){
            Response::make(422,'You are not authorized to approve this leave request');
        }
        $maxIndex=max($indexes);


        /** Check if requester has not completed their leave days */
        // get the financial year
        $month=env('FISCAL_MONTH');
        $day=env('FISCAL_DAY');
        $currentYear=Carbon::now()->year;
        $startOfFiscal=Carbon::createSafe((int) $currentYear,(int) $month,(int) $day)->toDateString();
        $endOfFiscal=Carbon::createSafe((int) $currentYear,(int) $month,(int) $day)->addRealYear()->toDateString();
        // use the fiscal dates to query for leave requests
        $leave_requests=Leave::where('staff_id',$leave['staff_id'])
            ->where('reason',$leave['reason'])
            ->where('date_from','>=',$startOfFiscal)
            ->where('date_to','<=',$endOfFiscal)
            ->where(function ($q){
                $q->where('status',self::$__APPROVED)
                    ->orWhere('status',self::$__PENDING);
            })->get();

        $leave_type=LeaveType::where('name',$leave['reason'])->first();
        if(!$leave_type){
            Notification::route('mail',Config::get('leave.service_errors.leave_type'))->notify(new LeaveTypeNotFound($leave['reason']));
            Leave\Response::make(422,'The associated leave type/reason for this request cannot be found. Check if the reason is defined.');
        }else {
            $allowedLeaveDays = $leave_type->days;
        }

        $rejectLeave=function($leaveId,$reason,$user_id){
          $leave=Leave::find($leaveId);
          $leave->reject_notes=$reason;
          $leave->reject=$user_id;
          $leave->reject_datetime=Carbon::now()->toDateTimeString();
          $leave->status=self::$__REJECTED;
          $leave->save();
        };

        //check if the total number of days is less or equal to the number of leave type
        $usedDays=0;
        $requestedDays=Carbon::parse($leave['date_to'])->diffInWeekdays(Carbon::parse($leave['date_from']));
        foreach ($leave_requests as $leave_request) {
            if($leave_request->status==self::$__APPROVED){
                $usedDays+=Carbon::parse($leave_request->date_to)->diffInWeekdays(Carbon::parse($leave_request->date_from));
            }
        }
        $days=$requestedDays+$usedDays;
        $staff=Staff::find($leave['staff_id']);
        if($usedDays>=$allowedLeaveDays){
            $message='The leave request has been rejected because you have exhausted your available '.$leave['reason']. ' days.';
            $rejectLeave($leave['id'],$message,Auth::id());
            Staff::find($leave->staff_id)->notify(new NotifyRequesterNewLeaveRequestRejected((object) $leave));
            Response::make(422,$message);
        }elseif ($requestedDays>$allowedLeaveDays || $days>$allowedLeaveDays){
            $message='The leave request has been rejected because the requested period exceeds the number of available '.$leave['reason']. ' days.';
            $rejectLeave($leave['id'],$message,Auth::id());
            Staff::find($leave->staff_id)->notify(new NotifyRequesterNewLeaveRequestRejected((object) $leave));
            Response::make(422,$message);
        }


        $response=null;
        // check if approval has been done and perform approval
        foreach ($flow->flow as $item) {
            if($item['index']==$index){
                // if leave has been approved.
                if($leave[$item['col_prefix_name']]!==0 && $leave[$item['col_prefix_name']]!==null && $item['role']==$approverRole->role){
                    Response::make(422,'The leave request has already been approved.');
                }else{
                    // check if the logged in user has the necessary role to make the approval
                    if($item['role']==$approverRole->role){
                        // do the approval
                        $leave[$item['col_prefix_name']]=Auth::id();
                        $leave['comments']=$comments;
                        $leave[$item['col_prefix_name'].'_datetime']=Carbon::now()->toDateTimeString();
                        // check if you're the last approver
                        if($index==$maxIndex){
                            $msg="Leave approval successfully completed";
                            $leave['status']=self::$__APPROVED;
                            Staff::find($leave['staff_id'])->notify(new NotifyRequesterNewLeaveRequestApproved((object) $leave));
                        }else {
                            $msg="Leave approval successfully done and has moved to the next approver if any.";
                        }
                        $updateLeave=Leave::find($leave['id']);
                        if($updateLeave->update($leave)){
                            $response=['status'=>200,'message'=>$msg];
                        }
                    }
                }
            }else{
                $response=['status'=>401,'message'=>'You cannot perform this action at the moment. Please confirm if the leave has reached the current approval stage.'];
            }
        }
        Response::make($response['status'],$response['message']);
    }

    protected static function rejectRequest($leave,$reason){
        // define closures
        /**
         * @param $flows
         *
         * @return array
         * @author isaac
         */
        $getIndexes=function ($flows){
            $items=[];
            foreach ($flows as $flow) {
                $items[]=$flow['index'];
            }
            return $items;
        };

        $getCurrentApproverIndex=function($flows,$role){
            $index=null;
            foreach ($flows as $flow) {
                if($flow['role']==$role){
                    $index=$flow['index'];
                }
            }
            return $index;
        };

        // check if leave has been rejected previously
        if($leave->status==self::$__REJECTED){
            Response::make(422,'Leave request has already been rejected');
        }

        // get the role of the staff requesting leave
        $staff_role=Role::where('staff',$leave->staff_id)->first();
        if(!$staff_role){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffRoleNotFound($leave->staff_id));
            Response::make(422,'The leave owner does not have a role in file.');
        }

        // get the approval flow for staff requesting leave
        $flow=LeaveApprovalFlow::where('role_id',$staff_role->role)->first();
        if(!$flow){
            Notification::route('mail',Config::get('leave.service_errors.approval_flow'))->notify(new RoleApprovalFlowNotFound($staff_role->role));
            Response::make(422,'The staff role does not have an approval flow defined.');
        }

        // get the role of the approver
        $approverRole=Role::where('staff',Auth::user()->staff_id)->first();

        if(!$approverRole){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffRoleNotFound(Auth::user()->staff_id));
            Response::make(422,'The current user does not have a role in file.');
        }


        // check if the user has the role required to approve/ reject
        $index=$getCurrentApproverIndex($flow->flow,$approverRole->role);
        $indexes=$getIndexes($flow->flow);
        if(!in_array($index,$indexes)){
            Response::make(401,'You are not authorized to approve this leave request');
        }

        // update the leave status
        $leave->reject_notes=$reason;
        $leave->reject_datetime=Carbon::now()->toDateTimeString();
        $leave->reject=Auth::id();
        $leave->status=self::$__REJECTED;
        if($leave->save()){
            Staff::find($leave->staff-id)->notify(new NotifyRequesterNewLeaveRequestRejected($leave));
            Response::make(200,'Leave has been successfully rejected.');
        }
        Response::make(500,'An error occurred updating the leave status. Please try again later.');
    }
}
