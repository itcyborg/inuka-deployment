<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Auditable;

class LeaveType extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use Auditable;
    protected $fillable=[
        'name',
        'days'
    ];
}
