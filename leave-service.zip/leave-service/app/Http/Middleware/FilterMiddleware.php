<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class FilterMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  Request  $request
     * @param Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        foreach ($request->all() as $key=>$value) {
            $request->query->remove($key);
            $request->query->add(['filter'=>[$key=>$value]]);
        }
        return $next($request);
    }
}
