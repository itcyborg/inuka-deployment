<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;

class PassportJson
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure                  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //verify if key is valid and get the client_id
        if ($client = DB::table('oauth_clients')->where('name', Config::get('auth.auth_client_name'))->first()) {
            //add the client id to the request
            $input = $request->all();
            $input['client_id'] = $client->id;
            $input['client_secret'] = $client->secret;
            $input['grant_type'] = 'password';
            $input['scope'] = '*';
            $request->merge($input);
            //forward the request to passport token generator
            return $next($request);
        } else {
            //return an error if key does not validate
            return response()->json('Unauthorised', 401);
        }
    }
}
