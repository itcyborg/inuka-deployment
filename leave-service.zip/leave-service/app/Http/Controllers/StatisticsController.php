<?php

namespace App\Http\Controllers;

use App\AccumulatedLeaveDays;
use App\Branch;
use App\Leave;
use App\Staff;
use App\User;
use Carbon\Carbon;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Validation\ValidationException;

/**
 * Class StatisticsController
 * @package App\Http\Controllers
 */
class StatisticsController extends Controller
{

    /**
     * @var int
     */
    public $__APPROVED=1;
    /**
     * @var int
     */
    public $__REJECTED=2;
    /**
     * @var int
     */
    public $__PENDING=0;

    /**
     * StatisticsController constructor.
     */
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * @return mixed
     * @throws AuthorizationException
     */
    public function totalLeaveRequests()
    {
        /**
         * get stats for each staff, i.e
         *
         * leave requests made
         * leave requests approved
         * leave requests rejected
         * leave requests pending
         *
         * leave days requested per category
         *
         */

        $response=Cache::remember('statistics',3600,function(){
            $staffs=Staff::with('leave')->get();
            $staffReport=[];

            $leaveTypes=Leave::groupBy('reason')->pluck('reason');

            $results=[];

            $dateGenerated=Carbon::now()->toDateTimeString();

            foreach ($staffs as $staff) {
                $year=Carbon::now()->year;
                $from=Carbon::createFromDate($year,\Illuminate\Support\Facades\Config::get('leave.fiscal_month'),\Illuminate\Support\Facades\Config::get('leave.fiscal_day'))->toDateString();
                $to=Carbon::createFromDate($year,\Illuminate\Support\Facades\Config::get('leave.fiscal_month'),\Illuminate\Support\Facades\Config::get('leave.fiscal_day'))->addYear()->toDateString();


                $totalAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->get();
                $approvedAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__APPROVED)->get();
                $pendingAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__PENDING)->get();
                $rejectedAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__REJECTED)->get();

                $approvedAnnualDays=0;
                $pendingAnnualDays=0;
                $rejectedAnnualDays=0;
                $totalAnnualDays=0;

                // approved annual requests
                foreach ($totalAnnualRequests as $totalAnnualRequest) {
                    $totalAnnualDays=$totalAnnualDays+(Carbon::parse($totalAnnualRequest->date_from)->diffInDays(Carbon::parse($totalAnnualRequest->date_to)));
                }


                // approved annual requests
                foreach ($approvedAnnualRequests as $approvedAnnualRequest) {
                    $approvedAnnualDays=$approvedAnnualDays+(Carbon::parse($approvedAnnualRequest->date_from)->diffInDays(Carbon::parse($approvedAnnualRequest->date_to)));
                }


                // rejected annual requests
                foreach ($rejectedAnnualRequests as $rejectedAnnualRequest) {
                    $rejectedAnnualDays=$rejectedAnnualDays+(Carbon::parse($rejectedAnnualRequest->date_from)->diffInDays(Carbon::parse($rejectedAnnualRequest->date_to)));
                }


                // pending annual requests
                foreach ($pendingAnnualRequests as $pendingAnnualRequest) {
                    $pendingAnnualDays=$pendingAnnualDays+(Carbon::parse($pendingAnnualRequest->date_from)->diffInDays(Carbon::parse($pendingAnnualRequest->date_to)));
                }


                # leave requests made for the financial year
                $totalRequests=[
                    'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->count(),
                    'days'=>$totalAnnualDays
                ];
                $approvedRequests=[
                    'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__APPROVED)->count(),
                    'days'=>$approvedAnnualDays
                ];
                $rejectedRequests=[
                    'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__REJECTED)->count(),
                    'days'=>$rejectedAnnualDays
                ];
                $pendingRequests=[
                    'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__PENDING)->count(),
                    'days'=>$pendingAnnualDays
                ];

                $categories=[];

                foreach ($leaveTypes as $leaveType) {
                    $approvedDaysRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__APPROVED)->get();
                    $rejectedDaysRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__REJECTED)->get();
                    $pendingDaysRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__PENDING)->get();

                    $approvedDays=0;
                    $rejectedDays=0;
                    $pendingDays=0;

                    // count approved days
                    foreach ($approvedDaysRequests as $approvedDaysRequest) {
                        $approvedDays=$approvedDays+(Carbon::parse($approvedDaysRequest->date_from)->diffInDays(Carbon::parse($approvedDaysRequest->date_to)));
                    }


                    // count rejected days
                    foreach ($rejectedDaysRequests as $rejectedDaysRequest) {
                        $rejectedDays=$rejectedDays+(Carbon::parse($rejectedDaysRequest->date_from)->diffInDays(Carbon::parse($rejectedDaysRequest->date_to)));
                    }


                    // count pending days
                    foreach ($pendingDaysRequests as $pendingDaysRequest) {
                        $pendingDays=$pendingDays+(Carbon::parse($pendingDaysRequest->date_from)->diffInDays(Carbon::parse($pendingDaysRequest->date_to)));
                    }

                    $categories[$leaveType]['approved']=[
                        'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__APPROVED)->count(),
                        'days'=>$approvedDays
                    ];
                    $categories[$leaveType]['pending']=[
                        'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__PENDING)->count(),
                        'days'=>$pendingDays
                    ];
                    $categories[$leaveType]['rejected']=[
                        'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__REJECTED)->count(),
                        'days'=>$rejectedDays
                    ];
                }

                $accumulated=AccumulatedLeaveDays::where('staff_id',$staff->id)->first();

                $results[]=[
                    'staff'=>[
                        'name'=>$staff->name,
                        'staff_id'=>$staff->id,
                        'email'=>$staff->email,
                        'status'=>strtoupper($staff->status)
                    ],
                    'total'=>$totalRequests,
                    'approved'=>$approvedRequests,
                    'rejected'=>$rejectedRequests,
                    'pending'=>$pendingRequests,
                    'categories'=>$categories,
                    'available_days'=>floor($accumulated->accumulated_days),
                    'days_in_debt'=>floor($accumulated->debt_days),
                    'eligibility_status'=>($accumulated->eligible)?'YES':'NO'
                ];

                # leave requests per category
            }

            return [
                'time_generated'=>$dateGenerated,
                'results'=>$results
            ];
        });

        return $response;

    }

    /**
     * @param Request $request
     * @return JsonResponse|mixed
     * @throws ValidationException
     */
    public function leaveRequest(Request $request)
    {
        $role=Authorize::getRole(\auth()->user());
        if(!Authorize::action($role,'leaves_view_leave_statistics')){
            abort(403);
        }
        $this->validate($request,[
            'staff_id'=>'required'
        ]);
        $staff=Staff::with('leave')->where('id',$request->staff_id)->first();
        if($staff->count()<1){
            abort(404,'Staff with the staff id not found.');
        }
        $response=Cache::remember('statistics_'.$request->staff_id,3600,function() use ($request,$staff){
            $staffReport=[];

            $leaveTypes=Leave::groupBy('reason')->pluck('reason');

            $dateGenerated=Carbon::now()->toDateTimeString();

            $year=Carbon::now()->year;
            $from=Carbon::createFromDate($year,\Illuminate\Support\Facades\Config::get('leave.fiscal_month'),\Illuminate\Support\Facades\Config::get('leave.fiscal_day'))->toDateString();
            $to=Carbon::createFromDate($year,\Illuminate\Support\Facades\Config::get('leave.fiscal_month'),\Illuminate\Support\Facades\Config::get('leave.fiscal_day'))->addYear()->toDateString();


            $totalAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->get();
            $approvedAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__APPROVED)->get();
            $pendingAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__PENDING)->get();
            $rejectedAnnualRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__REJECTED)->get();

            $approvedAnnualDays=0;
            $pendingAnnualDays=0;
            $rejectedAnnualDays=0;
            $totalAnnualDays=0;

            // approved annual requests
            foreach ($totalAnnualRequests as $totalAnnualRequest) {
                $totalAnnualDays=$totalAnnualDays+(Carbon::parse($totalAnnualRequest->date_from)->diffInDays(Carbon::parse($totalAnnualRequest->date_to)));
            }


            // approved annual requests
            foreach ($approvedAnnualRequests as $approvedAnnualRequest) {
                $approvedAnnualDays=$approvedAnnualDays+(Carbon::parse($approvedAnnualRequest->date_from)->diffInDays(Carbon::parse($approvedAnnualRequest->date_to)));
            }


            // rejected annual requests
            foreach ($rejectedAnnualRequests as $rejectedAnnualRequest) {
                $rejectedAnnualDays=$rejectedAnnualDays+(Carbon::parse($rejectedAnnualRequest->date_from)->diffInDays(Carbon::parse($rejectedAnnualRequest->date_to)));
            }


            // pending annual requests
            foreach ($pendingAnnualRequests as $pendingAnnualRequest) {
                $pendingAnnualDays=$pendingAnnualDays+(Carbon::parse($pendingAnnualRequest->date_from)->diffInDays(Carbon::parse($pendingAnnualRequest->date_to)));
            }


            # leave requests made for the financial year
            $totalRequests=[
                'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->count(),
                'days'=>$totalAnnualDays
            ];
            $approvedRequests=[
                'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__APPROVED)->count(),
                'days'=>$approvedAnnualDays
            ];
            $rejectedRequests=[
                'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__REJECTED)->count(),
                'days'=>$rejectedAnnualDays
            ];
            $pendingRequests=[
                'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('status',$this->__PENDING)->count(),
                'days'=>$pendingAnnualDays
            ];

            $categories=[];

            foreach ($leaveTypes as $leaveType) {
                $approvedDaysRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__APPROVED)->get();
                $rejectedDaysRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__REJECTED)->get();
                $pendingDaysRequests=$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__PENDING)->get();

                $approvedDays=0;
                $rejectedDays=0;
                $pendingDays=0;

                // count approved days
                foreach ($approvedDaysRequests as $approvedDaysRequest) {
                    $approvedDays=$approvedDays+(Carbon::parse($approvedDaysRequest->date_from)->diffInDays(Carbon::parse($approvedDaysRequest->date_to)));
                }


                // count rejected days
                foreach ($rejectedDaysRequests as $rejectedDaysRequest) {
                    $rejectedDays=$rejectedDays+(Carbon::parse($rejectedDaysRequest->date_from)->diffInDays(Carbon::parse($rejectedDaysRequest->date_to)));
                }


                // count pending days
                foreach ($pendingDaysRequests as $pendingDaysRequest) {
                    $pendingDays=$pendingDays+(Carbon::parse($pendingDaysRequest->date_from)->diffInDays(Carbon::parse($pendingDaysRequest->date_to)));
                }

                $categories[$leaveType]['approved']=[
                    'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__APPROVED)->count(),
                    'days'=>$approvedDays
                ];
                $categories[$leaveType]['pending']=[
                    'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__PENDING)->count(),
                    'days'=>$pendingDays
                ];
                $categories[$leaveType]['rejected']=[
                    'requests'=>$staff->leave()->whereBetween('date_requested',[$from,$to])->whereBetween('date_from',[$from,$to])->whereBetween('date_to',[$from,$to])->where('reason',$leaveType)->where('status',$this->__REJECTED)->count(),
                    'days'=>$rejectedDays
                ];
            }

            $accumulated=AccumulatedLeaveDays::where('staff_id',$staff->id)->first();

            $results=[
                'staff'=>[
                    'name'=>$staff->name,
                    'staff_id'=>$staff->id,
                    'email'=>$staff->email,
                    'status'=>strtoupper($staff->status)
                ],
                'total'=>$totalRequests,
                'approved'=>$approvedRequests,
                'rejected'=>$rejectedRequests,
                'pending'=>$pendingRequests,
                'categories'=>$categories,
                'available_days'=>floor($accumulated->accumulated_days),
                'days_in_debt'=>floor($accumulated->debt_days),
                'eligibility_status'=>($accumulated->eligible)?'YES':'NO'
            ];

            return [
                'time_generated'=>$dateGenerated,
                'results'=>$results
            ];
        });

        return $response;
    }

    /**
     * @param $ability
     * @return bool
     */
    protected static function check($ability)
    {
        $role=Authorize::getRole(Auth::user());
        if(!Authorize::action($role,$ability)){
            abort(403);
        }
    }
}
