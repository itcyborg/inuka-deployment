<?php

namespace App\Http\Controllers;

use App\Leave\Response;
use App\LeaveApprovalFlow;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * Class LeaveApprovalFlowController
 *
 * @package App\Http\Controllers
 * @author  isaac
 */
class LeaveApprovalFlowController extends Controller
{

    /**
     * LeaveApprovalFlowController constructor.
     */
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @return LeaveApprovalFlow[]|Collection|Response
     * @throws AuthorizationException
     */
    public function index()
    {
        $this->authorize('viewAny',LeaveApprovalFlow::class);
        return LeaveApprovalFlow::paginate(20);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     * @throws AuthorizationException
     * @throws ValidationException
     */
    public function store(Request $request)
    {
        $this->authorize('create',LeaveApprovalFlow::class);
        $this->validate($request,[
            'role_id'=>'required',
            'flow'=>'required|array',
            'manager_approval'=>'digits:1'
        ]);
        $flow=json_decode(json_encode($request->flow));
        foreach ($flow as $item) {
            if(!isset($item->index)){
                Response::make(400,'Approval flow needs to have numbered roles.');
            }
            if(!isset($item->role)){
                Response::make(400,'Approval flow needs to have numbered roles.');
            }
            if(!isset($item->col_prefix_name)){
                Response::make(400,'Approval flow needs to have a column prefix.');
            }
            if(!isset($item->role_title)){
                Response::make(400,'Approval flow needs to have a role title.');
            }
        }
        return LeaveApprovalFlow::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function show($id)
    {
        $this->authorize('view',LeaveApprovalFlow::class);
        return LeaveApprovalFlow::findOrFail($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function update(Request $request, $id)
    {
        $this->authorize('update',LeaveApprovalFlow::class);
        $flow=LeaveApprovalFlow::find($id);
        return $flow->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function destroy($id)
    {
        $this->authorize('delete',LeaveApprovalFlow::class);
        $flow=LeaveApprovalFlow::find($id);
        return $flow->delete();
    }
}
