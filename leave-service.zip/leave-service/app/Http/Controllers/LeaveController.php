<?php

namespace App\Http\Controllers;

use App\Leave;
use App\LeaveType;
use App\Notifications\NotifyApproverNewUnpaidLeaveCreated;
use App\Notifications\NotifyStaffNewUnpaidLeaveCreated;
use App\Staff;
use App\Traits\LeaveHelper;
use Carbon\Carbon;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

/**
 * Class LeaveController
 * @package App\Http\Controllers
 */
class LeaveController extends Controller
{
    public static $__APPROVED=1;
    public static $__REJECTED=2;
    public static $__PENDING=0;

    public static $leaveRequest;

    use LeaveHelper;

    // public function __construct()
    // {
    //     $this->middleware('auth:api');
    // }

    /**
     * Display a listing of the resource.
     *
     * @return Leave[]|LengthAwarePaginator|Collection|Response|\Illuminate\Support\Collection
     * @throws AuthorizationException
     */
    public function index()
    {
        // $this->authorize('viewAny',Leave::class);

        return DB::table('hrm_leave_management')
            ->join('m_office','hrm_leave_management.branch','=','m_office.id')
            ->join('sso_users','hrm_leave_management.staff_id','=','sso_users.staff_id')
            ->select(['hrm_leave_management.*','m_office.name as office_name','sso_users.name as staff_name'])
            ->paginate(20);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     *
     * @return Response
     * @throws AuthorizationException
     * @throws ValidationException
     */
    public function store(Request $request)
    {
        // $this->authorize('create',Leave::class);
        $this->validate($request, [
            'reason' => 'required',
            'date_from' => 'required',
            'date_to' => 'required',
            'staff_id'=>'required'
        ]);
        $request->request->add(['applied_by'=>Auth::id()]);
        $request->request->add(['date_requested'=>Carbon::now()->toDateString()]);

        // Start running checks
        $checks=new Leave\Check($request->all());
        $checks->leaveTypeExists();
        $checks->isStaffExist();
        $checks->isStaffActive();
        $checks->hasStaffRole();
        $checks->isStaffProbationary();
        $checks->isStaffEligible();
        $checks->isAnnualLeave();
        $checks->isLeaveDaysValid();
        $checks->hasHoliday();
        $checks->hasApprovalFlow();

        return Leave::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param $id
     *
     * @return Response
     * @throws AuthorizationException
     */
    public function show($id)
    {
        // $this->authorize('view',Leave::class);
        return Leave::findOrFail($id);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function update(Request $request, $id)
    {
        // $this->authorize('update',Leave::class);
        $leave=Leave::findOrFail($id);
        return $leave->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function destroy($id)
    {
        // $this->authorize('delete',Leave::class);
        $leave=Leave::findOrFail($id);
        return $leave->delete();
    }

    /**
     * @param Request $request
     * @param $id
     *
     * @return Application|ResponseFactory|Response|void
     * @throws AuthorizationException
     * @throws ValidationException
     */
    public function approve(Request $request, $id)
    {
        // $this->authorize('approve',Leave::class);
        $this->validate($request,[
            'comments'=>'required'
        ]);
        $leave=Leave::findOrFail($id);
        return self::approveRequest($leave,$request->comments);
    }

    /**
     * @param Request $request
     * @param $id
     *
     * @return Application|ResponseFactory|Response|void
     * @throws AuthorizationException
     * @throws ValidationException
     */
    public function reject(Request $request, $id)
    {
        // $this->authorize('reject',Leave::class);
        $this->validate($request,[
            'reject_notes'=>'required'
        ]);
        try {
            $leave = Leave::findOrFail($id);
        }catch (ModelNotFoundException $e){
            return response("Leave request id:$id not found",404);
        }
        return $this->rejectRequest($leave,$request->reject_notes);
    }

    /**
     * @param $staffId
     * @param Request $request
     * @return mixed
     * @throws AuthorizationException
     */
    public function listStaff($staffId, Request $request)
    {
        // $this->authorize('listStaff',Leave::class);
        return Leave::where('staff_id',$staffId)->get();
    }

    /**
     * @param Request $request
     *
     * @return LengthAwarePaginator|Collection|QueryBuilder[]
     */
    public function filterRequest(Request $request)
    {
        // $this->authorize('filter',Leave::class);
        return QueryBuilder::for(Leave::class)->allowedFilters([
            AllowedFilter::exact('status'),
            AllowedFilter::exact('staff_id'),
            AllowedFilter::exact('branch'),
        ])->paginate(25);
    }

    public function report(Request $request,$leave)
    {
        // $this->authorize('report',Leave::class);
        $leave=Leave::findOrFail($leave);
        if($leave){
            $leave->reporting_date=Carbon::now()->toDateTimeString();
            if($request->has('reporting_date') && $request->filled('reporting_date')){
                $leave->reporting_date=Carbon::parse($request->reporting_date);
            }
            $leave->save();
            if(is_null($leave->reporting_date)) {
                // expected reporting date
                $expected = Carbon::parse($leave->date_to)->addDay();
                if ($expected->isSunday()) {
                    $expected->addDay();
                }

                // check if leave date is past reporting date and register it as unpaid leave
                if (Carbon::parse($leave->reporting_date)->isAfter($expected)) {
                    $data = [
                        'date_from' => $expected->toDateString(),
                        'date_to' => Carbon::parse($leave->reporting_date),
                        'reason' => 'Unpaid Leave',
                        'applied_by' => $leave->applied_by,
                        'branch' => $leave->branch,
                        'staff_id' => $leave->staff_id,
                        'date_requested' => $leave->date_requested,
                        'status' => 1,
                        'comments' => 'Automatic application due to late reporting. Ref leave application :' . $leave->id
                    ];

                    Leave::create($data);

                    $approvers = [];
                    if ($leave->admin_req) {
                        $approvers[] = $leave->admin;
                    }
                    if ($leave->rm_req) {
                        $approvers[] = $leave->rm;
                    }
                    if ($leave->hop_req) {
                        $approvers[] = $leave->hop;
                    }
                    if ($leave->hr_req) {
                        $approvers[] = $leave->hr;
                    }
                    if ($leave->md_req) {
                        $approvers[] = $leave->md;
                    }
                    $approvers = array_filter($approvers, function ($value) {
                        if (!is_null($value))
                            return $value;
                    });
                    foreach ($approvers as $approver) {
                        $staff=Staff::find($approver);
                        $staff->notify(new NotifyApproverNewUnpaidLeaveCreated($leave));
                    }
                    Staff::find($leave->staff_id)->notify(new NotifyStaffNewUnpaidLeaveCreated($leave));
                }
            }
        }
        return $leave;
    }

    public function unpaidLeave(Request $request)
    {
        // $this->authorize('unpaidLeave',Leave::class);
        $validated=(object) $request->validate([
            'staff_id'=>'required|numeric',
            'date_from'=>'required|date',
            'date_to'=>'required|date'
        ]);

        $start=Carbon::parse($validated->date_from)->toDateString();
        $end=Carbon::parse($validated->date_to)->toDateString();
        $today=now();

        // select all unpaid leave
        $leaves=Leave::where('staff_id',$validated->staff_id)
            ->whereBetween('date_from',[$start,$end])
            ->where('reason','like', '%unpaid%')
            ->where('status',1)->get();

        $days=0;

        foreach ($leaves as $leave) {
            $from=Carbon::parse($leave->date_from);
            $to=Carbon::parse($leave->date_to);
            $reporting=Carbon::parse($leave->reporting_date);

            if($to->isPast() && !is_null($leave->reporting_date)){
                $days=$days+Carbon::parse($leave->reporting_date)->diffInDays($from);
                $sundays=$this->getSundays($from,$leave->reporting_date);
                $days=$days-$sundays;
            }

            if($to->isPast() && is_null($leave->reporting_date)){
                $days=$days+Carbon::parse($today)->diffInDays($from);
                $sundays=$this->getSundays($from,$today);
                $days=$days-$sundays;
            }

            if($reporting->isFuture()){
                $days=$days+Carbon::parse($today)->diffInDays($from);
                $sundays=$this->getSundays($from,$today);
                $days=$days-$sundays;
            }
        }
        return [
            'staff_id'=>$validated->staff_id,
            'from'=>$start,
            'to'=>$end,
            'unpaid_days'=>$days
        ];
    }


    public function getSundays($from,$to)
    {
        $start= Carbon::parse($from);
        $to=Carbon::parse($to);
        $sundays=0;
        for($i=$start;!$i->isSameDay($to);$i->addDay()){
            if($i->isSunday()){
                $sundays=$sundays+1;
            }
        }
        return $sundays;
    }
}
