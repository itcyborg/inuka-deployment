<?php

namespace App\Http\Controllers;

use App\LeaveType;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

/**
 * Class LeaveTypeController
 *
 * @package App\Http\Controllers
 * @author  isaac
 */
class LeaveTypeController extends Controller
{

    /**
     * LeaveTypeController constructor.
     */
    // public function __construct()
    // {
    //     $this->middleware('auth:api');
    // }

    /**
     * Display a listing of the resource.
     *
     * @return LeaveType[]|Collection|Response
     * @throws AuthorizationException
     */
    public function index()
    {
        // $this->authorize('viewAny',LeaveType::class);
        return LeaveType::paginate(20);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     * @throws AuthorizationException
     */
    public function store(Request $request)
    {
        // $this->authorize('create',LeaveType::class);
        return LeaveType::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function show($id)
    {
        // $this->authorize('view',LeaveType::class);
        return LeaveType::findOrFail($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function update(Request $request, $id)
    {
        // $this->authorize('update',LeaveType::class);
        $leaveType=LeaveType::findOrFail($id);
        return $leaveType->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param $id
     * @return Response
     * @throws AuthorizationException
     */
    public function destroy($id)
    {
        // $this->authorize('delete',LeaveType::class);
        $leaveType=LeaveType::findOrFail($id);
        return $leaveType->delete();
    }
}
