<?php

namespace App\Http\Controllers;

use App\AccumulatedLeaveDays;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Carbon;

class AccumulatedLeaveDaysController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $request->validate(['staff_id'=>'required']);
        return AccumulatedLeaveDays::where('staff_id',$request->staff_id)->firstOrFail();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function store(Request $request,$id)
    {
        $validated=(object) $request->validate([
            'staff_id'=>'required',
            'days_penalized'=>'required|numeric'
        ]);

        $accumulation=AccumulatedLeaveDays::find($id);
        $accumulation->days_penalized=$accumulation->days_penalized+$validated->days_penalized;
        $accumulation->date_penalized=Carbon::now()->toDateTimeString();
        $accumulation->year=Carbon::now()->year;
        $accumulation->touch();
        $accumulation->save();
        return $accumulation;
    }

    /**
     * Display the specified resource.
     *
     * @param AccumulatedLeaveDays $accumulatedLeaveDays
     *
     * @return Response
     */
    public function show(AccumulatedLeaveDays $accumulatedLeaveDays)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param AccumulatedLeaveDays $accumulatedLeaveDays
     *
     * @return Response
     */
    public function edit(AccumulatedLeaveDays $accumulatedLeaveDays)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request              $request
     * @param AccumulatedLeaveDays $accumulatedLeaveDays
     *
     * @return Response
     */
    public function update(Request $request, AccumulatedLeaveDays $accumulatedLeaveDays)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param AccumulatedLeaveDays  $accumulatedLeaveDays
     *
     * @return Response
     */
    public function destroy(AccumulatedLeaveDays $accumulatedLeaveDays)
    {
        //
    }
}
