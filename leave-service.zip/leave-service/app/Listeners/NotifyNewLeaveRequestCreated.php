<?php

namespace App\Listeners;

use App\Events\NewLeaveRequestCreatedEvent;
use App\Staff;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class NotifyNewLeaveRequestCreated
{
    /**
     * Handle the event.
     *
     * @param  NewLeaveRequestCreatedEvent  $event
     * @return void
     */
    public function handle(NewLeaveRequestCreatedEvent $event)
    {
        $leave=$event->leave;
        $staff=Staff::find($leave->staff_id)->notify(new \App\Notifications\NotifyRequesterNewLeaveRequestCreated((object) $leave));
    }
}
