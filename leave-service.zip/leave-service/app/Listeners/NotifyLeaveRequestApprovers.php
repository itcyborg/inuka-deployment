<?php

namespace App\Listeners;

use App\Events\NewLeaveRequestCreatedEvent;
use App\LeaveApprovalFlow;
use App\Notifications\NotifyApproverNewLeaveRequested;
use App\Notifications\StaffForRoleNotFound;
use App\Notifications\StaffRoleNotFound;
use App\Role;
use App\Staff;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Notification;

/**
 * Class NotifyLeaveRequestApprovers
 *
 * @package App\Listeners
 * @author  isaac
 */
class NotifyLeaveRequestApprovers
{
    /**
     * Handle the event.
     *
     * @param  NewLeaveRequestCreatedEvent  $event
     * @return void
     */
    public function handle(NewLeaveRequestCreatedEvent $event)
    {
        $leave=$event->leave;
        // get the role of the request maker
        $staff_role=Role::where('staff',$leave->staff_id)->first();
        $staff=Staff::find($leave->staff_id);

        // check if staff role exists
        if(!$staff_role){
            // send a notification
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffRoleNotFound($leave->staff_id));
            return;
        }

        // get the approval flow
        $flow=LeaveApprovalFlow::where('role_id',$staff_role->role)->first();

        // check if approval flow exists
        if(!$flow){
            // send a notification
            Notification::route('mail',Config::get('leave.service_errors.approval_flow'))->notify(new StaffRoleNotFound($staff_role));
            return;
        }

        // get the list of approver roles from
        $roles=$this->approverRoles($flow);

        $emails=$this->getApproverStaff($roles);
        if(count($emails)<1){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffForRoleNotFound($staff_role->role));
        }

        foreach ($emails as $email) {
            Notification::route('mail',$email)->notify(new NotifyApproverNewLeaveRequested($leave));
        }
    }

    /**
     * @param $approvalFlow
     *
     * @return array
     * @author isaac
     */
    private function approverRoles($approvalFlow)
    {
        $flow=$approvalFlow->flow;
        $roles=null;
        foreach ($flow as $item) {
            $roles[]=$item['role'];
        }
        return $roles;
    }

    /**
     * @param          $roles
     * @param int|null $branch
     *
     * @return mixed
     * @author isaac
     */
    private function getApproverStaff($roles,int $branch=null)
    {
        $staffs_id=null;
        $staffs_results=null;
        foreach ($roles as $role) {
            $staffs=Role::where('role',$role);
            if($branch!==null){
                $staffs->where('office',$branch)->orWhere('office',1);
            }
            $results=$staffs->get();
            foreach ($results as $result) {
                $staffs_results[]=$result;
            }
        }
        foreach ($staffs_results as $staffs_result) {
            $staffs_id[]=$staffs_result->staff;
        }
       return Staff::whereIn('id',$staffs_id)->get(['id','email','name']);
    }
}
