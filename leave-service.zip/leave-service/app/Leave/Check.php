<?php


namespace App\Leave;


use App\AccumulatedLeaveDays;
use App\LeaveApprovalFlow;
use App\LeaveType;
use App\Notifications\CalendarServiceIssueNotification;
use App\Notifications\NotifyStaffInasufficientAccumulatedDays;
use App\Notifications\NotifyStaffLeaveDurationExceedsLeaveType;
use App\Notifications\RoleApprovalFlowNotFound;
use App\Notifications\StaffNotActive;
use App\Notifications\StaffNotFound;
use App\Notifications\StaffRoleNotFound;
use App\Role;
use App\Staff;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\RequestOptions;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Str;
use Throwable;

class Check
{
    private $leave;
    private $staff;
    private $staff_role;
    private $isAnnual=false;
    private $inUnpaid=false;

    /**
     * Add rules
     *
     * @param $leaveRequest
     */

    public function __construct($leaveRequest)
    {
        $this->leave=(object) $leaveRequest;
        if(Str::contains(Str::lower($this->leave->reason),'unpaid')){
            $this->inUnpaid=true;
        }
    }

    public function leaveTypeExists()
    {
        if(!LeaveType::where('name',$this->leave->reason)->exists()){
            Response::make(422,'This leave type cannot be found or has not been configured.');
        }
    }


    // check if staff_id has an associated staff record
    public function isStaffExist()
    {
        $this->staff=Staff::find($this->leave->staff_id);
        if(!$this->staff){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffNotFound($this->leave->staff_id));
            Response::make(422,'The applicant staff id does not exist in the Staff repository.');
        }
    }


    // check if staff is active
    public function isStaffActive()
    {
        if($this->staff->status!='active'){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffNotActive($this->leave->staff_id));
            Response::make(422,'The applicant/ staff is not active. ');
        }
    }

    // check if staff is probationary
    public function isStaffProbationary()
    {
        ($this->staff->confirmed)?true: Response::make(422,'The staff is still on probation.');
    }


    // check if staff has accumulated leave days and is eligible
    public function isStaffEligible()
    {
        $staff=Staff::find($this->leave->staff_id);
        if(Str::contains(Str::of($this->leave->reason)->lower(),'annual')){
            $accumulatedDays=AccumulatedLeaveDays::where('staff_id',$this->leave->staff_id)->first();
            if(!$accumulatedDays){
                $staff->notify(new NotifyStaffInasufficientAccumulatedDays($this->leave));
                Response::make(422,'You do not have any valid leave days available.');
            }
            $days=Carbon::parse($this->leave->date_from)->diffInDays(Carbon::parse($this->leave->date_to));
            if($days>$accumulatedDays->accumulated_days){
                $staff->notify(new NotifyStaffInasufficientAccumulatedDays($this->leave));
                Response::make(422,'You are not eligible for this type of leave. Days available to request: '.floor($accumulatedDays->accumulated_days));
            }
        }elseif(Str::contains(Str::lower($this->leave->reason),'unpaid')){
        }else{
            $leaveType=LeaveType::where('name',$this->leave->reason)->first();
            $days=Carbon::parse($this->leave->date_from)->diffInDays(Carbon::parse($this->leave->date_to));

            if($days>$leaveType->days){
                $staff->notify(new NotifyStaffLeaveDurationExceedsLeaveType($this->leave));
                Response::make(422,'You are not eligible for this type of leave. Days available to request: '.floor($leaveType->days));
            }
        }
    }


    // check if staff has an existing role
    public function hasStaffRole()
    {
        $role=Role::where('staff',$this->leave->staff_id)->first();
        if($role){
            $this->staff_role=$role->role;
            return;
        }
        Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffRoleNotFound($this->leave));
        Response::make(422,'Staff does not have a related role defined on file.');
    }


    // check if staff's role has an approval flow
    public function hasApprovalFlow()
    {
        if(!LeaveApprovalFlow::where('role_id',$this->staff_role)->exists()){
            Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new RoleApprovalFlowNotFound($this->leave));
            Response::make(422, 'Staff role does not have an approval flow defined.');
        }
    }


    // check if leave days is valid
    public function isLeaveDaysValid()
    {
        if(!$this->inUnpaid) {
            // check if start date is in the past
            if (\Carbon\Carbon::parse($this->leave->date_from)->isPast()) {
                Response::make(400, 'Invalid leave start date.');
            }

            // check if end date is not before start date

            if (Carbon::parse($this->leave->date_to)->isBefore(Carbon::parse($this->leave->date_from))) {
                Response::make(400, 'Invalid leave end date.');
            }
        }
    }

    public function isAnnualLeave()
    {
        if(Str::contains(Str::of($this->leave->reason)->lower(),'annual')){
            $this->isAnnual=true;
            // validate if allowed approval days is defined and whether the leave satisfies it
            $allowedApprovalDays=Config::get('leave.approval_days');
            $earliestApprovalDate=Carbon::parse($this->leave->date_requested)->addDays($allowedApprovalDays);

            // if earliest approval date is same as date from
            if($earliestApprovalDate->isSameDay(Carbon::parse($this->leave->date_from)) || $earliestApprovalDate->isAfter(Carbon::parse($this->leave->date_from))){
                Response::make(400,'Invalid dates selected as starting date should allow for '.$allowedApprovalDays .' from date of requesting.');
            }
        }
    }


    // check if there's a holiday in between start date and end date
    public function hasHoliday()
    {
        $client=new Client([
            'headers'=>[
                'authorization'=>'Bearer '.Request::instance()->bearerToken()
            ]
        ]);
        $uri=env('HOLIDAY_SERVICE').'/api/holiday/find';
        try {
            $response = $client->post($uri, [
                RequestOptions::JSON => [
                    'start_date' => $this->leave->date_from,
                    'end_date' => $this->leave->date_to
                ]
            ]);
            if ($response->getStatusCode() == 200) {
                $response = json_decode($response->getBody()->getContents(), false);
                $response=$response->holidays;
                $days = count($response);
                $proposed_date_to = \Carbon\Carbon::parse($this->leave->date_to)->addDays($days);
                if ($proposed_date_to->isSunday()) {
                    $next_date = $proposed_date_to->nextWeekday();
                    foreach ($response as $holiday) {
                        if (Carbon::parse($holiday->calendar_date)->equalTo($next_date)) {
                            $this->leave->date_to = $proposed_date_to->nextWeekday()->toDateString();
                        } else {
                            $this->leave->date_to = $next_date->toDateString();
                        }
                    }
                }
            }
        }catch (ClientException | ConnectException | Throwable $e){
            Notification::route('mail', Config::get('leave.service_error.calendar'))->notify(new CalendarServiceIssueNotification($e));
            Response::make(422,'A system error has occurred. Please try again later.');
        }
    }
}