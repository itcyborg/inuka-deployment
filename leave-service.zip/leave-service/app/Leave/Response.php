<?php


namespace App\Leave;


class Response
{
    public static function make($status,$msg=null)
    {
        abort($status,$msg);
    }
}