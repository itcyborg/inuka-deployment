<?php

namespace App\Notifications;

use App\Staff;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Carbon;

class NotifyStaffNewUnpaidLeaveCreated extends Notification
{
    use Queueable;
    private $leave;

    /**
     * Create a new notification instance.
     *
     * @param $leave
     */
    public function __construct(object $leave)
    {
        $this->leave=$leave;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line('The introduction to the notification.')
            ->action('Notification Action', url('/'))
            ->line('Thank you for using our application!');
    }



    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'type'=>'info',
            'title'=>'New Unpaid Leave',
            'priority'=>'1',
            'message'=> 'This is to notify you that an unpaid leave has been automatically requested and approved by the system.
                         This is due to the late reporting that was due on '.Carbon::parse($this->leave->date_to)->addDay()->toDateString()
        ];
    }
}
