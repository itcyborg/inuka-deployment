<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class StaffForRoleNotFound extends Notification
{
    use Queueable;

    private $role_id;

    /**
     * Create a new notification instance.
     *
     * @param $role_id
     */
    public function __construct($role_id)
    {
        $this->role_id=$role_id;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->error()
            ->line('An error occurred when trying to locate a staff with the role id : '.$this->role_id.' who may perform approvals for leave requests. This may cause an issue in notifying the approver on new leave requests.')
            ->line('Please confirm that the staff has the appropriate role defined.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
