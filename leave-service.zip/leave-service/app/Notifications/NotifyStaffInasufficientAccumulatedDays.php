<?php

namespace App\Notifications;

use App\AccumulatedLeaveDays;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NotifyStaffInasufficientAccumulatedDays extends Notification
{
    use Queueable;



    /**
     * @var object
     * @author isaac
     */
    private $leave;

    /**
     * Create a new notification instance.
     *
     * @param object $leave
     */
    public function __construct(object $leave)
    {
        $this->leave=$leave;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'type'=>'error',
            'title'=>'Insufficient Leave Days',
            'priority'=>'1',
            'message'=>     'This is to notify you that your leave request cannot be completed at the moment as you have not accumulated enough leave days.
                             Your available leave days are ['.AccumulatedLeaveDays::where('staff_id',$this->leave->staff_id)->first()->accumulated_days.'] days.'
        ];
    }
}
