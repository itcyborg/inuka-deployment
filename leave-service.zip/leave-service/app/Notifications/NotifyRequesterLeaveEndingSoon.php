<?php

namespace App\Notifications;

use App\Staff;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Carbon;

class NotifyRequesterLeaveEndingSoon extends Notification
{
    use Queueable;

    /**
     * @var object
     * @author isaac
     */
    private $leave;

    /**
     * Create a new notification instance.
     *
     * @param object $leave
     */
    public function __construct(object $leave)
    {
        $this->leave=$leave;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)->success()->subject($title)->line($message)->priority($priority);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'type'=>'info',
            'title'=>'Leave Ending Soon',
            'priority'=>'2',
            'message'=> 'This is to notify you that your leave will be ending '.Carbon::now()->diffInDays(Carbon::parse($this->leave->date_to)).' days. 
                         You will be expected to report back to work on '.Carbon::parse($this->leave->date_to)->addDay()->toDateString().'. Endeavor to report then.'
        ];
    }
}
