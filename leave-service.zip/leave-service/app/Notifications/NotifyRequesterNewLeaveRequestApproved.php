<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Carbon;

class NotifyRequesterNewLeaveRequestApproved extends Notification
{
    use Queueable;


    /**
     * @var object
     * @author isaac
     */
    private $leave;

    /**
     * Create a new notification instance.
     *
     * @param object $leave
     */
    public function __construct(object $leave)
    {
        $this->leave=$leave;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'type'=>($this->leave->status==1)?'success':'error',
            'title'=>'Leave Request '.($this->leave->status==1)?'Approved':'Rejected',
            'priority'=>'1',
            'message'=>     'This is to notify you that your leave request has been '.($this->leave->status==1)?'approved':'rejected. '.($this->leave->status==1)?'success':'
                            The following information was provided as possible reason for the rejection: '.$this->leave->comment
        ];
    }
}
