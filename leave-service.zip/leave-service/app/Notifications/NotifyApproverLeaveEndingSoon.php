<?php

namespace App\Notifications;

use App\Staff;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Carbon;

class NotifyApproverLeaveEndingSoon extends Notification
{
    use Queueable;

    /**
     * @var object
     * @author isaac
     */
    private $leave;

    /**
     * Create a new notification instance.
     *
     * @param object $leave
     */
    public function __construct(object $leave)
    {
        $this->leave=$leave;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->line('The introduction to the notification.')
                    ->action('Notification Action', url('/'))
                    ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
//        return [
//            'type'=>'info', // info, success, error
//            'title'=>'', // subject
//            'priority'=>'', //  1 - 5 (lowest)
//            'intro', //
//            'outro'=>'',
//            'attachments'=>[],  //
//            'message'=>''
//        ];
        return [
            'type'=>'info',
            'title'=>'Leave Ending Soon',
            'priority'=>'3',
            'message'=> 'This is to notify you that the requested leave by '.Staff::find($this->leave->staff_id)->name.' ,
                        Staff id: ['.$this->leave->staff_id.'] will be ending on '.Carbon::parse($this->leave->date_to)->toDateString().'
                            and should be expected back to work on '.$this->workingDay($this->leave->date_to)->toDateString().'. Please facilitate their transition back
                            to work to be as seamless as possible.'
        ];
    }

    private function workingDay($date){
        if(Carbon::parse($date)->isSunday()){
            return Carbon::parse($date)->nextWeekday();
        }
        return Carbon::parse($date)->addDay();
    }
}
