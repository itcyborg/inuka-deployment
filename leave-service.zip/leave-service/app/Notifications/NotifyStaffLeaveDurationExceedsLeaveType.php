<?php

namespace App\Notifications;

use App\LeaveType;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NotifyStaffLeaveDurationExceedsLeaveType extends Notification
{
    use Queueable;


    /**
     * @var object
     * @author isaac
     */
    private $leave;

    /**
     * Create a new notification instance.
     *
     * @param object $leave
     */
    public function __construct(object $leave)
    {
        $this->leave=$leave;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'type'=>'error',
            'title'=>'Leave Request Declined',
            'priority'=>'1',
            'message'=>     'This is to notify you that your leave request cannot be completed at the moment because you have requested more days than can be requested for the selected leave type.
                             The available leave days that can be requested are ['.LeaveType::where('name',$this->leave->reason)->first()->days.'] days.'
        ];
    }
}
