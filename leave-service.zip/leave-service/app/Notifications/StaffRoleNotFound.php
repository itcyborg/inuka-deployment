<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class StaffRoleNotFound extends Notification implements ShouldQueue
{
    use Queueable;

    private $staff_id;

    /**
     * Create a new notification instance.
     *
     * @param $staff_id
     */
    public function __construct($staff_id)
    {
        $this->staff_id=$staff_id;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->error()
                    ->line('An error occurred when trying to locate the staff role for the staff id: '.$this->staff_id)
                    ->line('Please confirm that the staff has the appropriate role defined.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
