<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class CalendarServiceIssueNotification extends Notification
{
    use Queueable;

    private $error;

    /**
     * Create a new notification instance.
     *
     * @param $error
     */
    public function __construct($error)
    {
        $this->error=$error;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('Calendar Service Error')
                    ->error()
                    ->line('An error occurred when trying to interact with the calendar service')
                    ->line('A log has been included highlighting the error encountered. More details may be found in the service log file.')
                    ->line('Thank you for using our application!')
                    ->attachData(print_r(['error'=>$this->error->getMessage()],true), 'calendar-error.log', [
                            'mime' => 'text/plain',
                        ]
                    );
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [

        ];
    }
}
