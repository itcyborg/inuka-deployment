<?php

namespace App\Notifications;

use App\Staff;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Carbon;

class NotifyApproverNewLeaveRequested extends Notification
{
    use Queueable;

    private $leave;

    /**
     * Create a new notification instance.
     *
     * @param object $leave
     */
    public function __construct(object $leave)
    {
        $this->leave=$leave;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->line('The introduction to the notification.')
                    ->action('Notification Action', url('/'))
                    ->line('Thank you for using our application!');
    }


    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'type'=>'info',
            'title'=>'New Leave Request',
            'priority'=>'2',
            'message'=> 'This is to notify you that a leave has been requested by '.Staff::find($this->leave->staff_id)->name.' , 
                        Staff id: ['.$this->leave->staff_id.'] is waiting for your action.'
        ];
    }

    private function workingDay($date){
        if(Carbon::parse($date)->isSunday()){
            return Carbon::parse($date)->nextWeekday();
        }
        return Carbon::parse($date);
    }
}
