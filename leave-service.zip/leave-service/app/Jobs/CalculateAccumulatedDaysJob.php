<?php

namespace App\Jobs;

use App\AccumulatedLeaveDays;
use App\Leave;
use App\Staff;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;

class CalculateAccumulatedDaysJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // check if the staff has used some of the annual leave days
        $year=Carbon::now()->year;
        $start=Carbon::create($year,Config::get('leave.fiscal_month'),Config::get('leave.fiscal_day'))->toDateString();
        $end=Carbon::now()->toDateString();
        $annualLeave='annual';

        $employees=Staff::where('status','active')->get();
        foreach ($employees as $employee) {
            $currentDate=Carbon::now()->endOfDay();
            $year=$currentDate->year;
            $fiscalDate=Carbon::create($year,Config::get('leave.fiscal_month'),Config::get('leave.fiscal_date'));
            $months=$fiscalDate->floatDiffInMonths($currentDate);
            $accumulated_days=$months*Config::get('leave.rate');

            $leaveDays=Leave::whereBetween('date_requested',[$start,$end])->where('reason','like','%'.$annualLeave.'%')->whereDate('date_to','<=',$end)->where('staff_id',$employee->id)->where('status',1)->get();

            $usedDays=0;

            foreach ($leaveDays as $leaveDay) {
                $days=Carbon::parse($leaveDay->date_from)->diffInDays(Carbon::parse($leaveDay->date_to));
                $sundays=$this->getSundays($leaveDay->date_from,$leaveDay->date_to);
                $used=$days-$sundays;
                $staff_ids[]=$leaveDay->staff_id;
                $usedDays=$usedDays+$used;
            }


            if($employee->confirmed){
                $eligible='true';
            }else{
                $eligible='false';
            }

            $debt=0;

            $accumulated_days=$accumulated_days-$usedDays;

            if($accumulated_days<0){
                $debt=$accumulated_days*(-1);
                $accumulated_days=0;
                $eligible='false';
            }

            AccumulatedLeaveDays::updateOrCreate([
                'staff_id'=>$employee->id,
                'year'=>Carbon::now()->year
            ],[
                'staff_id'=>$employee->id,
                'accumulated_days'=>$accumulated_days,
                'debt_days'=>$debt,
                'eligible'=>$eligible,
                'year'=>Carbon::now()->year
            ]);

            $accumulated=AccumulatedLeaveDays::where('staff_id',$employee->id)->first();
            $accumulated->debt_days=$accumulated->debt_days-$accumulated->days_penalized;
            $accumulated->save();
        }
    }

    public function getSundays($from,$to)
    {
        $start=Carbon::parse($from);
        $to=Carbon::parse($to);
        $sundays=0;
        for($i=$start;!$i->isSameDay($to);$i->addDay()){
            if($i->isSunday()){
                $sundays=$sundays+1;
            }
        }
        return $sundays;
    }
}
