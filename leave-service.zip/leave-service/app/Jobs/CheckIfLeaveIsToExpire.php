<?php

namespace App\Jobs;

use App\Leave;
use App\LeaveApprovalFlow;
use App\Notifications\NotifyApproverLeaveEndingSoon;
use App\Notifications\NotifyApproverNewLeaveRequested;
use App\Notifications\NotifyRequesterLeaveEndingSoon;
use App\Notifications\StaffForRoleNotFound;
use App\Notifications\StaffRoleNotFound;
use App\Role;
use App\Staff;
use App\Traits\LeaveHelper;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Notification;

class CheckIfLeaveIsToExpire implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels,LeaveHelper;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Leave::where('status',0)
            ->whereDate('date_from','>',Carbon::now()->addDays(Config::get('leave.ending_reminder',2)))
            ->chunk(100,function($leaves){
                foreach ($leaves as $leave){
                    // get the role of the request maker
                    $staff_role=Role::where('staff',$leave->staff_id)->first();
                    $staff=Staff::find($leave->staff_id);

                    // check if staff role exists
                    if(!$staff_role){
                        // send a notification
                        Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffRoleNotFound($leave->staff_id));
                        return;
                    }

                    // get the approval flow
                    $flow=LeaveApprovalFlow::where('role_id',$staff_role->role)->first();

                    // check if approval flow exists
                    if(!$flow){
                        // send a notification
                        Notification::route('mail',Config::get('leave.service_errors.approval_flow'))->notify(new StaffRoleNotFound($staff_role));
                        return;
                    }

                    // get the list of approver roles from
                    $roles=$this->approverRoles($flow);

                    $approvers=$this->getApproverStaff($roles);
                    if(count($approvers)<1){
                        Notification::route('mail',Config::get('leave.service_errors.staff_role'))->notify(new StaffForRoleNotFound($staff_role->role));
                    }

                    foreach ($approvers as $approver) {
                        $approver->notify(new NotifyApproverLeaveEndingSoon((object) $leave));
                    }
                    Staff::find($leave->staff_id)->notify(new NotifyRequesterLeaveEndingSoon((object) $leave));
                }
        });
    }

    /**
     * @param $approvalFlow
     *
     * @return array
     * @author isaac
     */
    private function approverRoles($approvalFlow)
    {
        $flow=$approvalFlow->flow;
        $roles=null;
        foreach ($flow as $item) {
            $roles[]=$item['role'];
        }
        return $roles;
    }

    /**
     * @param          $roles
     * @param int|null $branch
     *
     * @return mixed
     * @author isaac
     */
    private function getApproverStaff($roles,int $branch=null)
    {
        $staffs_id=null;
        $staffs_results=null;
        foreach ($roles as $role) {
            $staffs=Role::where('role',$role);
            if($branch!==null){
                $staffs->where('office',$branch)->orWhere('office',1);
            }
            $results=$staffs->get();
            foreach ($results as $result) {
                $staffs_results[]=$result;
            }
        }
        foreach ($staffs_results as $staffs_result) {
            $staffs_id[]=$staffs_result->staff;
        }
        return Staff::whereIn('id',$staffs_id)->get(['id','email','name']);
    }
}
