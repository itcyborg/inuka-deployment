<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Auditable;

class AccumulatedLeaveDays extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use Auditable;
    protected $fillable=[
        'staff_id',
        'accumulated_days',
        'debt_days',
        'eligible',
        'year'
    ];
}
