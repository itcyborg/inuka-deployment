<?php

namespace App;

use App\Events\NewLeaveRequestCreatedEvent;
use App\Traits\LeaveHelper;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use OwenIt\Auditing\Auditable;


/**
 * Class Leave
 *
 * @package App
 * @author  isaac
 */
class Leave extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use LeaveHelper;
    use Auditable;

    /**
     * @var string
     * @author isaac
     */
    protected $table='hrm_leave_management';

    /**
     * @var string[]
     * @author isaac
     */
    protected $fillable=[
        'date_requested',
        'staff_id',
        'branch',
        'reason',
        'leave_docs',
        'leave2_docs',
        'date_from',
        'date_to',
        'applied_by',
        'manager_approval',
        'comments',
        'admin_req',
        'admin',
        'admin_datetime',
        'rm_req',
        'rm',
        'rm_datetime',
        'hop_req',
        'hop',
        'hop_datetime',
        'hr_req',
        'hr',
        'hr_datetime',
        'reject',
        'reject_datetime',
        'reject_notes',
        'status'
    ];


    public function branch()
    {
        return $this->belongsTo(Branch::class,'branch_id','id');
    }

    public function user()
    {
        return $this->belongsTo(User::class,'staff_id','staff_id');
    }

    public function staff()
    {
        return $this->belongsTo(Staff::class,'staff_id','id');
    }

    /**
     * @var bool
     * @author isaac
     */
    public $timestamps=false;

    /**
     * @author isaac
     */
    protected static function boot()
    {
        parent::boot();
        self::creating(function($model){
            try {
                $model->date_requested = Carbon::now()->toDateString();
                if ($branch = DB::table('hrm_staff_roles')->where('staff', $model->staff_id)->first()) {
                    $model->branch = $branch->office;
                } else {
                    $model->branch = 1;
                }
                $request = request();
                $token = $request->bearerToken();
                $data = self::getRequiredApprovers($model->toArray());
                foreach ($data as $datum => $value) {
                    $model->$datum = $value;
                }
            }catch (\Throwable $e){
                abort($e->getCode(),$e->getMessage());
            }
        });
        self::created(function($model){
            event(new NewLeaveRequestCreatedEvent($model));
        });
    }



}
