<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Auditable;

/**
 * @method static find($id)
 * @method static findOrFail($id)
 * @method static create(array $all)
 * @method static where(string $string, $role)
 */
class LeaveApprovalFlow extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use Auditable;

    protected $fillable=[
        'role_id',
        'flow',
        'manager_approval'
    ];

    protected $casts=[
        'flow'=>'json'
    ];
}
