<?php

return [
    
    /*
    |--------------------------------------------------------------------------
    | System Color Codes
    |--------------------------------------------------------------------------
    |
    | This are all the color codes for charts
    |
    */
    'colors' => [
        'training_request' => [
            'request' => [
                'AWAITING_PUBLISHING' => 'rgba(0, 192, 239, 1)',
                'AWAITING_TRAINER_APPROVAL' => 'rgba(243, 156, 18, 1)',
                'AWAITING_PRE-TRAINING_EVALUATION' => 'rgb(133, 64, 245, 1)',
                'AWAITING_MANAGER_SIGNATURE' => 'rgba(0, 166, 90, 1)',
                'AWAITING_TRAINER_SIGNATURE' => 'rgba(210, 214, 222, 1)',
                'AWAITING_COMMENCEMENT' => 'rgba(253, 126, 20, 1)',
                'REJECTED_BY_THE_TRAINER' => 'rgba(245, 105, 84, 1)',
                'CANCELED' => 'rgba(132, 32, 41, 1)'
            ],
            'provision' => [
                'ONGOING' => 'rgba(8, 121, 144, 1)',
                'AWAITING_RATING' => 'rgba(214, 51, 132, 1)',
                'COMPLETED' => 'rgba(25, 135, 84, 1)',
            ]
        ]
    ] 
];