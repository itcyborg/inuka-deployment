<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application logo | Application
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with an organization
    |
    */
    'logo_path' => 'img/logos/default.png',

    /*
    |--------------------------------------------------------------------------
    | Application Aliases
    |--------------------------------------------------------------------------
    |
    | This option controls the aliasing of trainee and trainer titles
    |
    */
    'aliases' => [
        'trainee' => 'group',
        'trainer' => 'trainer'
    ],

    /*
    |--------------------------------------------------------------------------
    | Organization Values
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with an organization
    |
    */
    'organization' => [
        'status' => [
            'ACTIVE', 'DEACTIVATED'
        ],

        'types' => [
            'trainer', 'trainee'
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | User Values
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with a user
    |
    */
    'user' => [
        'status' => [
            'ACTIVE', 'DEACTIVATED'
        ],

        'genders' => [
            'male', 'female'
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Sytem Roles
    |--------------------------------------------------------------------------
    |
    | This option list the roles
    |
    */
    'roles' => [
        'manager' => [
            'manager_key_user',
        ],

        'trainee' => [
            'trainee_key_user',
            'contact_person',
        ],

        'trainer' => [
            'trainer_key_user',
            'contact_person',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Trainer Values
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with an workplan
    |
    */
    'trainer' => [
        'status' => [
            'AWAITING_PREQUALIFICATION',
            'PREQUALIFIED',
            'FAILED_PREQUALIFICATION',
            'UNAVAILABLE',
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Trainer Values
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with an workplan
    |
    */
    'trainee' => [
        'status' => [
            'AVAILABLE',
            'UNAVAILABLE'
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Workplan Values
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with an workplan
    |
    */
    'workplan' => [
        'status' => [
            'DRAFT', 'SUBMITTED',
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Upload Values
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with an upload
    |
    */
    'upload' => [
        'types' => [
            'avatar', 'resume', 'profile', 'training-material'
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Training Request Status
    |--------------------------------------------------------------------------
    |
    | This are all the status for a Training Request
    |
    */
    'training_request' => [
        'status' => [
            'requests' => array_keys( config('chart.colors.training_request.request') ),
            'provisions' => array_keys( config('chart.colors.training_request.provision') ),

            'exclude' => [
                'trainer' => [
                    'AWAITING_PUBLISHING'
                ],

                'trainee' => [
                    'AWAITING_PUBLISHING', 'AWAITING_TRAINER_APPROVAL',
                    'REJECTED_BY_THE_TRAINER'
                ]
            ],
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Language Values | Application
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with a languages
    |
    */
    'languages' => [
        'English',
        'Kiswahili',
        'French',
        'Arabic',
        'Chinese',
        'German',
        'Spanish'
    ],

    /*
    |--------------------------------------------------------------------------
    | SOW Effort levels | Application
    |--------------------------------------------------------------------------
    |
    | This option controls the values associated with sow effor levels
    |
    */
    'effort_level_units' => [
        'hours',
        'days',
        'weeks',
        'months',
        'years'
    ],

    /*
    |--------------------------------------------------------------------------
    |  System currency | Application
    |--------------------------------------------------------------------------
    |
    | This option controls the currency
    |
    */
    'currency' => 'KES',

    /*
    |--------------------------------------------------------------------------
    | Evaluation Options
    |--------------------------------------------------------------------------
    |
    | This option controls the evaluation types
    |
    */
    'evaluations' => [
        'types' => [
            'PRE', 'POST'
        ],

        'pre' => [
            'rating_options' => [
                'AGREE', 'NEUTRAL', 'DISAGREE', 'NOT_APPLICABLE'
            ]
        ],
        'post' => [
            'rating_options' => [
                'STRONGLY_AGREE', 'AGREE', 'NEUTRAL', 'DISAGREE', 'STRONGLY_DISAGREE'
            ]
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | rating_parameters Options
    |--------------------------------------------------------------------------
    |
    | This option controls the rating options types
    |
    */
    'rating_parameters' => [
        'types' => [
            'pre-qualification',
            'rating',
            'post-evaluation'
        ],
        'entities' => [
            'trainer',
            'trainee',
            'workplan'
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Rating types
    |--------------------------------------------------------------------------
    |
    | This is the maximum rating that will be displayed to users
    |
    */
    'rating_types' => [
        'training-request',
        'pre-evaluation',
        'post-evaluation',
        'pre-qualification'
    ],

    /*
    |--------------------------------------------------------------------------
    | Maximum rating value | Application
    |--------------------------------------------------------------------------
    |
    | This is the maximum rating that will be displayed to users
    |
    */
    'maximum_rating_value' => 5,

    /*
    |--------------------------------------------------------------------------
    | Prequalification threshold value | Application
    in percentage
    |--------------------------------------------------------------------------
    |
    | This is the maximum rating that will be displayed to users
    |
    */
    'prequalification_threshold' => 50.0,

    /*
    |--------------------------------------------------------------------------
    | Required number of pre-qualification raters | Application
    |--------------------------------------------------------------------------
    |
    | This is the maximum rating that will be displayed to users
    |
    */
    'required_number_of_prequalification_raters' => 2,

    /*
    |--------------------------------------------------------------------------
    | The types of settings supported | Systen
    |--------------------------------------------------------------------------
    |
    */
    'setting_types' => [
        'single', 'multiple'
    ]
];
