<?php

/*
|--------------------------------------------------------------------------
| Register the trainer alias
|--------------------------------------------------------------------------
|
*/
$trainer = config('settings.aliases.trainer');

/*
|--------------------------------------------------------------------------
| Register the trainee alias
|--------------------------------------------------------------------------
|
*/
$trainee = config('settings.aliases.trainee');

 /*
|--------------------------------------------------------------------------
| Notification Language Lines
|--------------------------------------------------------------------------
|
| The following language lines are used for notifications for various
| messages that we need to display to the user. You are free to modify
| these language lines according to your application's requirements.
|
*/
return [
    'user-activated' => [
        'user' => 'We are pleased to inform you that your account on the TMP App is now active. Log in to your account and explore the services available to you.',
    ],

    'user-deactivated' => [
        'user' => 'This is to inform that your account on the TMP platform has been deactivated for the following reason - ":reason". You will no longer be able to access the TMP App platform.',
    ],

    'trainer-registered' => [
        'trainer' => 'Welcome to '.config('app.name').'. You are required to verify your email address.',
        'manager' => ':trainer_name has registered as a new '.$trainer.'. You are required to prequalify the trainer.',
    ],

    'trainer-pre-qualification' => [
        'pre-qualification-submitted' => [
            'manager' => 'Thank you for completing and submitting your pre-qulification evaluation for the '.$trainer.' :trainer_name.',
            'all_managers' => 'This is to inform you that the '.$trainer.' :trainer_name has been partially rated.'
        ],

        'pre-qualification-completed' => [
            'manager' => 'This is to inform you that the pre-qualification of the '.$trainer.' :trainer_name has been successfully completed'
        ],

        'pre-qualification-results' => [
            'passed' => 'We are pleased to inform you that you have been pre-qualificated successfully as a '.$trainer.'. We take this opportunity to welcome you on board. We look forward to working with you',
            'failed' => 'We regret to inform you failed the pre-qualification as a '.$trainer.'. We wish you sucess in your future endevours'
        ],
    ],

    'training-request' => [
        'published' => [
            'trainer' => 'This is to inform you that you have been selected to serve as the designated TSP for the training request for the '.$trainee.' :trainee_name on the topic :topic_name. You are required to review this request and confirm your availability to conduct the training.',
            'manager' => 'This is to inform you that you have been selected to serve as the designated manager for the training request for the '.$trainee.' :trainee_name by the '.$trainer.' :trainer_name on the topic :topic_name.'
        ],

        'accepted' => [
            'manager' => 'This is to inform you that a new training request on the topic :topic_name has been accepted by the '.$trainer.', :trainer_name. It is now pending pre-training evaluation.',
            'trainee' => 'We are pleased to inform you that you have a new technical assistance on topic :topic_name by a trainer named :trainer_name. You are now required to perform a pre-training evaluation to determine the relevance of this training to you.'
        ],

        'declined' => [
            'manager' => 'We regret to inform you that a training request has been declined by the '.$trainer.' :trainer_name. They provided the following reason - ":reason"'
        ],

        'pre-evaluation-submitted' => [
            'manager' => 'This is to inform you that a new pre-training evaluation feedback form for the topic :topic_name has been completed and submitted by the '.$trainee.' member named :trainee_name',
            'trainee' => 'Thank you for completing and submitting your pre-training evaluation for the topic :topic_name. We will let you know when the training starts.'
        ],

        'requires_signing' => [
            'manager' => 'The pre evaluations for the training request on the topic :topic_name for the '.$trainee.' :trainee_name by the '.$trainer.' :trainer_name have been completed. This is to request you to create and sign the training\'s Statement of Work.'
        ],

        'signed_by_manager' => [
            'trainer' => 'The SOW agreement for the training on the topic, :topic_name for the '.$trainee.' named :trainee_name has been prepared and is ready for signing.'
        ],

        'signed_by_trainer' => [
            'manager' => 'The trainer named :trainer_name offering the topic :topic_name has signed an SOW document.',
            'trainer' => 'You are required to start training the '.$trainee.' :trainee_name on the topic :topic_name. Please remember to begin and end modules. We wish you all the best.',
            'trainee' => 'The training on the topic :topic_name by the '.$trainer.' :trainer_name is about to start. We will send you an email when the training begins.'
        ]
    ],

    'training-provision' => [
        'provision_started' => [
            'trainer' => 'The training on the topic :topic_name has just started. Please remember to start and end all modules.',
            'trainee' => 'The training on the topic :topic_name by the '.$trainer.' :trainer_name has just started. We hope that you will have a great learning experience.',
            'manager' => 'The training on the topic :topic_name by the '.$trainer.' :trainer_name for the '.$trainee.' :trainee_name has just started.'
        ],

        'module_started' => [
            'trainer' => 'The training for the module :module_name on the topic :topic_name has just started. Please remember to start and end all modules.',
            'trainee' => 'The training for the module :module_name on the topic :topic_name by the '.$trainer.' :trainer_name has just started.',
            'manager' => 'The training for the module :module_name on the topic :topic_name by the '.$trainer.' :trainer_name for the '.$trainee.' :trainee_name has just started.'
        ],

        'module_ended' => [
            'trainer' => 'The training for the module :module_name on the topic :topic_name has just ended.',
            'trainee' => 'The training for the module :module_name on the topic :topic_name by the '.$trainer.' :trainer_name has just ended.',
            'manager' => 'The training for the module :module_name on the topic :topic_name by the '.$trainer.' :trainer_name and the '.$trainee.' :trainee_name has just ended.'
        ],

        'provision_ended' => [
            'trainer' => 'The training on the topic :topic_name has just ended. Please rate the '.$trainee.' to help us improve your experience.',
            'trainee' => 'The training on the topic :topic_name by the '.$trainer.' :trainer_name has just ended. We hope that you have had a great learning experience. Please rate the '.$trainer.' :trainer_name to help us improve the training experience',
            'manager' => 'The training on the topic :topic_name by the '.$trainer.' :trainer_name and the '.$trainee.' :trainee_name has just ended. Please rate the '.$trainer.'.'
        ],

        'trainee_rated_trainer' => [
            'manager' => 'The trainee member, :trainee_name has rated the '.$trainer.' :trainer_name for the provision on the topic :topic_name .'
        ],

        'trainer_rated_trainee' => [
            'manager' => 'The trainer :trainer_name has rated the '.$trainee.' :trainee_name on the provision on the topic :topic_name .'
        ],

        'post-evaluation-submitted' => [
            'manager' => 'This is to inform you that a new post-training evaluation for the topic :topic_name has been submitted by the '.$trainee.' member named :trainee_name',
            'trainee' => 'Thank you for submitting your post-training evaluation for the topic :topic_name.'
        ],

        'provision-completed' => [
            'manager' => 'The training on the topic :topic_name by the '.$trainer.' :trainer_name and the '.$trainee.' :trainee_name has successfully been completed.',
            'trainer' => 'The training for the topic :topic_name on the topic :topic_name has been successfully completed. Thank you for your services',
            'trainee' => 'The training on the topic :topic_name by the '.$trainer.' :trainer_name has just ended. We hope that you have had a great learning experience.'
        ],
    ]
];
