<?php

/*
|--------------------------------------------------------------------------
| Register the trainer alias
|--------------------------------------------------------------------------
|
*/
$trainer = config('settings.aliases.trainer');

/*
|--------------------------------------------------------------------------
| Register the trainee alias
|--------------------------------------------------------------------------
|
*/
$trainee = config('settings.aliases.trainee');

/*
|--------------------------------------------------------------------------
| Alerts Language Lines
|--------------------------------------------------------------------------
|
| The following language lines are used for alerts for various
| messages that we need to display to the user. You are free to modify
| these language lines according to your application's requirements.
|
*/
return [

    /*
    |--------------------------------------------------------------------------
    | Handle error messages
    |--------------------------------------------------------------------------
    |
    */
    'error' => [
        'sow' => [
            'signing' => 'An error has occurred during signing'
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Handle success messages
    |--------------------------------------------------------------------------
    |
    */
    'success' => [
        'notification' => [
            'read' => 'All notifications have been marked as read',
            'unread' => 'All notifications have been marked as unread',
        ],

        'api' => [
            'trainee' => [
                'user' => [
                    'created' => 'The '.$trainee.' member has been created successfully',
                    'updated' => 'The '.$trainee.' member has been updated successfully',
                ],
                'organization' => [
                    'created' => 'The '.$trainee.' organization has been created successfully',
                    'updated' => 'The '.$trainee.' organization has been updated successfully',
                ]
            ]
        ],

        'user' => [
            'verification-email-resent' => 'A fresh verification link has been sent to your email address',
            'activated' => 'The user has been activated successfully',
            'deactivated' => 'The user has been deactivated successfully',
            'role' => 'The user role has assigned successfully',
            'permissions' => 'The user permission(s) has assigned successfully',
            'roles' => 'The user role has assigned successfully',
            'profile-updated' => 'You have successfully updated your profile',
        ],

        'trainee' => [
            'activated' => 'The '.$trainee.' has been activated successfully',
            'deactivated' => 'The '.$trainee.' has been deactivated successfully',
            'topic' => 'The '.$trainee.' topic(s) has assigned successfully',
        ],

        'trainer' => [
            'registered' => 'You have successfully registered as a '.$trainer.' in '.config('app.name').'. Please check your email for further instructions',
            'updated' => [
                'account' => 'Your account information has been updated successfully.',
                'professional' => 'Your professional information has been updated successfully.',
                'expertise' => 'Your areas of expertise have been updated successfully.',
            ],
            'activated' => 'The '.$trainer.' has been activated successfully',
            'deactivated' => 'The '.$trainer.' has been deactivated successfully',
        ],

        'module-template' => [
            'created' => 'The module has been created successfully',
            'updated' => 'The module has been updated successfully',
            'deleted' => 'The module has been deleted successfully'
        ],

        'training-material' => [
            'created' => 'The training material has been created successfully',
            'updated' => 'The training material has been updated successfully',
            'deleted' => 'The training material has been deleted successfully'
        ],

        'service' => [
            'created' => 'The service has been created successfully',
            'updated' => 'The service has been updated successfully',
            'deleted' => 'The service has been deleted successfully'
        ],

        'area' => [
            'created' => 'The area has been created successfully',
            'updated' => 'The area has been updated successfully',
            'deleted' => 'The area has been deleted successfully'
        ],

        'topic' => [
            'created' => 'The topic has been created successfully',
            'updated' => 'The topic has been updated successfully',
            'deleted' => 'The topic has been deleted successfully'
        ],

        'training-request' => [
            'created' => 'A draft training request has been created successfully. Please verify and publish it',
            'published' => 'The training request has been published successfully',
            'accepted' => 'The training request has been accepted successfully',
            'declined' => 'The training request has been declined successfully',
        ],

        'training-provision' => [
            'started' => 'The training has started successfully',
            'ended' => 'The training has ended successfully. Rate the trainee to complete.',
        ],

        'workplan-module' => [
            'created' => 'The module has been created successfully',
            'updated' => 'The module has been updated successfully',
            'deleted' => 'The module has been deleted successfully',
            'started' => 'The module training has been started successfully',
            'ended' => 'The module training has ended successfully',
        ],

        'evaluation' => [
            'created' => 'Your responses have been received.',
            'updated' => 'Your responses have been updated successfully',
        ],

        'post-evaluation' => [
            'created' => 'Your responses have been received. Please rate the trainer.',
            'updated' => 'Your responses have been updated successfully',
        ],

        'sow' => [
            'created' => 'The sow has been created successfully',
            'updated' => 'The sow has been updated successfully',
            'signed' => 'The sow has been signed successfully',
            'signed_by_trainer' => 'The sow has been signed successfully. You can now begin the training'
        ],

        'rating' => [
            'trainee' => [
                'created' => 'Your ratings has been received.',
                'updated' => 'Your ratings have been updated successfully',
            ],

            'trainer' => [
                'created' => 'Your ratings has been received',
                'updated' => 'Your ratings have been updated successfully',
            ],

            'manager' => [
                'created' => 'Your ratings has been received',
                'updated' => 'Your ratings have been updated successfully',
            ]
        ],

        'pre-qualification' => [
            'created' => 'Your pre-qualification ratings have been received',
            'updated' => 'Your pre-qualification ratings have been updated successfully',
        ],

        'setting' => [
            'created' => 'The setting has been created successfully',
            'updated' => 'The setting has been updated successfully',
        ],

        'setting-value' => [
            'created' => 'The setting value has been updated successfully',
            'updated' => 'The setting value has been updated successfully',
            'deleted' => 'The setting value has been deleted successfully'
        ],
    ]
];
