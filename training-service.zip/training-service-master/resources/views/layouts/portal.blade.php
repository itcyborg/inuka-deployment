@extends('layouts.app')
@push('app.css')
    @stack('css')
@endpush
@section('app.content')
    <div id="portal-layout">
        <div id="sidebar-layout">
            @include('layouts.portal.sidebar.layout')
        </div>
        <div id="content-layout">
            @include('layouts.portal.navbar.layout')
            <main id="portal-content">
                @stack('main-alert')
                <div class="container-fluid">
                    @sectionMissing('no-title')
                        <div class="d-flex align-items-center py-3">
                            @hasSection('title')
                                <h5 class="text-uppercase fw-normal">@yield('title')</h5>
                            @endif
                            <div class="ms-auto">
                                @stack('actions')
                            </div>
                        </div>
                    @endif
                    @stack('status-alerts')
                    @yield('content')
                </div>
            </main>
            @include('layouts.portal.footer')
        </div>
    </div>
@endsection
@push('app.js')
    @stack('js')
@endpush
