@extends('layouts.app')

@push('app.css')
    @stack('css')
@endpush

@section('app.social-metas')
    <meta property="og:title" content="{{ config('app.name') }} - @yield('title')"/>
    <meta property="og:url" content="{{ url()->current() }}"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="@yield('meta-description')"/>
    <meta property="og:image" content=""/>
    <meta name="twitter:card" content="summary"/>
    <meta name="twitter:title" content="{{ config('app.name') }} - @yield('title')"/>
    <meta name="twitter:card" content="summary"/>
    <meta property="twitter:description" content="@yield('meta-description')"/>
    <meta property="twitter:url" content="{{ url()->current() }}"/>
    <meta property="twitter:image" content=""/>
@endsection

@section('app.content')
    @sectionMissing('no-navbar')
        @include('layouts.guest.navbar')
    @endif
    @yield('content')
@endsection

@push('app.js')
    @stack('js')
@endpush
