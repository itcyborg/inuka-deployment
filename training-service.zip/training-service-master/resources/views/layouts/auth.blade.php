@extends('layouts.guest')
@section('no-navbar', true)
@section('content')
    <main id="authentication-layout">
        <section class="row auth-container mx-auto">
            <div class="col-lg-12">
                <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="text-center mb-3">
                                    <a class="link-dark text-decoration-none" href="{{ route('home') }}">
                                        <img style="width: 5rem;" class="img-fluid me-3 mb-2" src="{{ asset( config('settings.logo_path') ) }}" alt="">
                                        <h4 class="mb-1 fw-bold">{{ config('app.name') }}</h4>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="card shadow-lg border-0 rounded-0">
                                    <div class="card-header">
                                        <h4 class="text-center fw-light my-2">
                                            @yield('auth.title')
                                        </h4>
                                    </div>
                                    <div class="card-body">
                                        @yield('auth.content')
                                    </div>
                                    @hasSection('auth.footer-actions')
                                        <div class="card-footer text-center">
                                            <div class="small">
                                                @yield('auth.footer-actions')
                                            </div>
                                        </div>
                                    @endif
                                </div>
                                {{-- <div class="social-links">
                                    <a href="{{ route('socials.redirect', ['provider' => 'google']) }}" class="btn btn-danger w-100 rounded-0">
                                        Login With Google
                                    </a>
                                    <a href="{{ route('socials.redirect', ['provider' => 'microsoft']) }}" class="btn btn-primary w-100 rounded-0">
                                        Login With Microsoft
                                    </a>
                                </div> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
