<div class="navbar-container">
    <nav class="top-nav navbar navbar-expand-lg navbar-dark position-absolute pe-2">
        <button class="btn order-1 order-lg-0 ms-2" id="sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-nav ms-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="notification-dropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-bell fa-lg"></i>
                    <span class="badge bg-success py-1 px-1 mt-n3">
                        <small>{{ $unreadNotifications }}</small>
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right notifications" aria-labelledby="notification-dropdown">
                    <x-notification :notifications="$userNotifications" />
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="user-dropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Hi, {{ Auth::user()->name }}
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="user-dropdown">
                    <a href="{{ route('logout') }}"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                        class="dropdown-item"
                    >
                    <i class="fa fa-power-off" aria-hidden="true"></i>
                        {{ __('Logout') }}
                    </a>
                    <a href="{{ route(\App\View\Profile::profileRouteName(), ['user' => Auth::user()]) }}" class="dropdown-item">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        {{ __('My Profile') }}
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                        @csrf
                    </form>
                </div>
            </li>
        </ul>
    </nav>
</div>
