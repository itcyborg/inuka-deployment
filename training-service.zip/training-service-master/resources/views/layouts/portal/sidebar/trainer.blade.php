@can('view_trainer_portal')
    <div class="nav">
        <a class="nav-link {{ Route::is('portal.trainers.dashboard') ? 'active' : '' }}" href="{{ route('portal.trainers.dashboard') }}">
            <div class="nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
            Dashboard
        </a>
    </div>
@endcan
@can('view_trainer_portal')
    <div class="nav">
        <a class="nav-link {{ Route::is(['portal.trainers.profiles.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.profiles.show') }}">
            <div class="nav-link-icon"><i class="fas fa-address-card"></i></div>
            My Profile
        </a>
    </div>
@endcan
@can('viewAny', \App\Models\TrainingRequest::class)
    <div class="nav">
        <a class="nav-link {{ (isset($trainingRequest) && $trainingRequest->isARequest()) || (isset($sow) && $sow->trainingRequest->isARequest()) || url()->full() === route('portal.trainers.training-requests.index') ? 'active' : '' }}"
            href="{{ route('portal.trainers.training-requests.index') }}">
            <div class="nav-link-icon"><i class="fas fa-diagnoses"></i></div>
            Training Requests
        </a>
    </div>
@endcan
@can('viewAny', \App\Models\TrainingRequest::class)
    <div class="nav">
        <a class="nav-link {{ (isset($trainingRequest) && $trainingRequest->isAProvision()) || (isset($sow) && $sow->trainingRequest->isAProvision()) || url()->full() === route('portal.trainers.training-requests.index', ['type' => 'provisions']) ? 'active' : '' }}"
            href="{{ route('portal.trainers.training-requests.index', ['type' => 'provisions']) }}">
            <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
            Training Provisions
        </a>
    </div>
@endcan
@can('generate_report')
    <div class="nav">
        <a class="nav-link collapsed {{ Route::is(['portal.trainers.reports.workplans.*', 'portal.trainers.reports.sow.*', 'portal.trainers.reports.training-requests.*', 'portal.trainers.reports.training-provisions.*', 'portal.trainers.reports.complete-trainings.*', 'portal.trainers.reports.ratings.*', 'portal.trainers.reports.pre-qualification-ratings.*', 'portal.trainers.reports.trainer-ratings.*', 'portal.trainers.reports.trainee-ratings.*']) ? 'active' : '' }}" href="#" data-bs-toggle="collapse" data-bs-target="#collapse-reports-menu" aria-expanded="false" aria-controls="collapse-reports-menu">
            <div class="nav-link-icon"><i class="fas fa-chart-bar"></i></div>
            Reports
            <div class="sidebar-collapse-arrow"><i class="fas fa-angle-down"></i></div>
        </a>
    </div>
@endcan
<div class="collapse {{ Route::is(['portal.trainers.reports.workplans.*', 'portal.trainers.reports.sow.*', 'portal.trainers.reports.training-requests.*', 'portal.trainers.reports.training-provisions.*', 'portal.trainers.reports.complete-trainings.*', 'portal.trainers.reports.ratings.*', 'portal.trainers.reports.pre-qualification-ratings.*', 'portal.trainers.reports.trainer-ratings.*', 'portal.trainers.reports.trainee-ratings.*']) ? 'show' : '' }}" id="collapse-reports-menu" data-bs-parent="#sidebar-accordion">
    @can('generateWorkPlanReports', \App\Models\WorkplanModule::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.workplans.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.workplans.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-times"></i></div>
                WorkPlan Reports
            </a>
        </div>
    @endcan
    @can('generateSowReports', \App\Models\Sow::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.sow.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.sow.index') }}">
                <div class="nav-link-icon"><i class="fas fa-file-contract"></i></div>
                SOW Reports
            </a>
        </div>
    @endcan
    @can('generateTrainingRequestReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.training-requests.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.training-requests.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                Training Request Reports
            </a>
        </div>
    @endcan
    @can('generateTrainingRequestReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.training-provisions.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.training-provisions.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                Training Provision Reports
            </a>
        </div>
    @endcan
    @can('generateTrainingRequestReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.complete-trainings.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.complete-trainings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-check"></i></div>
                Complete Training Reports
            </a>
        </div>
    @endcan
    @can('generateRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.pre-qualification-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.pre-qualification-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                PreQualification Rating Reports
            </a>
        </div>
    @endcan
    @can('generateRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.trainer-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.trainer-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                Trainer Rating Reports
            </a>
        </div>
    @endcan
    @can('generateRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainers.reports.trainee-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.trainers.reports.trainee-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                Trainee Rating Reports
            </a>
        </div>
    @endcan
</div>
