@can('view_manager_portal')
    <div class="nav">
        <a class="nav-link {{ Route::is('portal.managers.dashboard') ? 'active' : '' }}" href="{{ route('portal.managers.dashboard') }}">
            <div class="nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
            Dashboard
        </a>
    </div>
@endcan
@can('viewAny', \App\Models\User::class)
    <div class="sidebar-menu-nested nav">
        <a class="nav-link {{ Route::is('portal.managers.users.*') ? 'active' : '' }}" href="{{ route('portal.managers.users.index') }}">
            <div class="nav-link-icon"><i class="fa fa-users"></i></div>
            Users
        </a>
    </div>
@endcan
@can('viewAny', \App\Models\Trainer::class)
    <div class="nav">
        <a class="nav-link {{ Route::is('portal.managers.trainers.*') ? 'active' : '' }}" href="{{ route('portal.managers.trainers.index') }}">
            <div class="nav-link-icon"><i class="fas fa-chalkboard-teacher"></i></div>
            @prettify(Str::plural(config('settings.aliases.trainer')))
        </a>
    </div>
@endcan
<div class="nav">
    <a class="nav-link collapsed {{ Route::is(['portal.managers.trainees.*', 'portal.managers.training-requests.*']) ? 'active' : '' }}" href="#" data-bs-toggle="collapse" data-bs-target="#collapse-trainees-menu" aria-expanded="false" aria-controls="collapse-trainees-menu">
        <div class="nav-link-icon"><i class="fas fa-school"></i></div>
        @prettify(Str::plural(config('settings.aliases.trainee')))
        <div class="sidebar-collapse-arrow"><i class="fas fa-angle-down"></i></div>
    </a>
</div>
<div class="collapse {{ Route::is(['portal.managers.trainees.*', 'portal.managers.training-requests.*', 'portal.managers.sows.*', 'portal.managers.organizations.*']) ? 'show' : '' }}" id="collapse-trainees-menu" data-bs-parent="#sidebar-accordion">
    @can('viewAny', \App\Models\Trainee::class)
        <div class="nav">
            <a class="nav-link {{ Route::is(['portal.managers.organizations.*']) ? 'active' : '' }}" href="{{ route('portal.managers.organizations.index') }}">
            <div class="nav-link-icon"><i class="fas fa-sitemap"></i></div>
            @prettify(config('settings.aliases.trainee'))s Settings
            </a>
        </div>
    @endcan
    @can('viewAny', \App\Models\Trainee::class)
        <div class="nav">
            <a class="nav-link {{ Route::is(['portal.managers.trainees.*']) ? 'active' : '' }}" href="{{ route('portal.managers.trainees.index') }}">
            <div class="nav-link-icon"><i class="fas fa-id-card-alt"></i></div>
            @prettify(config('settings.aliases.trainee')) Profiles
            </a>
        </div>
    @endcan
    @can('viewAny', \App\Models\TrainingRequest::class)
        <div class="nav">
            <a class="nav-link {{ (isset($trainingRequest) && $trainingRequest->isARequest()) || url()->full() === route('portal.managers.training-requests.index') ? 'active' : '' }}" href="{{ route('portal.managers.training-requests.index') }}">
            <div class="nav-link-icon"><i class="fas fa-diagnoses"></i></div>
            Training Requests
            </a>
        </div>
    @endcan
    @can('viewAny', \App\Models\TrainingRequest::class)
        <div class="nav">
            <a class="nav-link {{ (isset($trainingRequest) && $trainingRequest->isAProvision()) || url()->full() === route('portal.managers.training-requests.index', ['type' => 'provisions']) ? 'active' : '' }}" href="{{ route('portal.managers.training-requests.index', ['type' => 'provisions']) }}">
            <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
            Training Provisions
            </a>
        </div>
    @endcan
</div>
<div class="nav">
    <a class="nav-link collapsed {{ Route::is(['portal.managers.module-templates.*', 'portal.managers.services.*', 'portal.managers.training-materials.*', 'portal.managers.settings.*', 'portal.managers.rating-parameters.*']) ? 'active' : '' }}" href="#" data-bs-toggle="collapse" data-bs-target="#collapse-application-menu" aria-expanded="false" aria-controls="collapse-application-menu">
        <div class="nav-link-icon"><i class="fas fa-laptop"></i></div>
        System
        <div class="sidebar-collapse-arrow"><i class="fas fa-angle-down"></i></div>
    </a>
</div>
<div class="collapse {{ Route::is(['portal.managers.module-templates.*', 'portal.managers.services.*', 'portal.managers.areas.*', 'portal.managers.training-materials.*', 'portal.managers.settings.*', 'portal.managers.values.*', 'portal.managers.rating-parameters.*']) ? 'show' : '' }}" id="collapse-application-menu" data-bs-parent="#sidebar-accordion">
    @can('viewAny', \App\Models\ModuleTemplate::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.module-templates.*', 'portal.managers.training-materials.*']) ? 'active' : '' }}" href="{{ route('portal.managers.module-templates.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-times"></i></div>
                Workplan Template
            </a>
        </div>
    @endcan
    @can('viewAny', \App\Models\RatingParameter::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.rating-parameters.*']) ? 'active' : '' }}" href="{{ route('portal.managers.rating-parameters.index') }}">
                <div class="nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Rating/Assessment Params
            </a>
        </div>
    @endcan
    @can('viewAny', \App\Models\Service::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.services.*', 'portal.managers.areas.*']) ? 'active' : '' }}" href="{{ route('portal.managers.services.index') }}">
                <div class="nav-link-icon"><i class="fa fa-briefcase"></i></div>
                Services
            </a>
        </div>
    @endcan
    @can('viewAny', \App\Models\Setting::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.settings.*', 'portal.managers.values.*']) ? 'active' : '' }}" href="{{ route('portal.managers.settings.index') }}">
                <div class="nav-link-icon"><i class="fas fa-cog"></i></div>
                Settings
            </a>
        </div>
    @endcan
</div>

<div class="nav">
    <a class="nav-link collapsed {{ Route::is(['portal.managers.reports.workplans.*', 'portal.managers.reports.sow.*', 'portal.managers.reports.training-requests.*', 'portal.managers.reports.training-provisions.*', 'portal.managers.reports.complete-trainings.*', 'portal.managers.reports.ratings.*', 'portal.managers.reports.pre-qualification-ratings.*', 'portal.managers.reports.trainer-ratings.*', 'portal.managers.reports.trainee-ratings.*', 'portal.managers.reports.pre-evaluations.*', 'portal.managers.reports.post-evaluations.*']) ? 'active' : '' }}" href="#" data-bs-toggle="collapse" data-bs-target="#collapse-reports-menu" aria-expanded="false" aria-controls="collapse-reports-menu">
        <div class="nav-link-icon"><i class="fas fa-chart-bar"></i></div>
        Reports
        <div class="sidebar-collapse-arrow"><i class="fas fa-angle-down"></i></div>
    </a>
</div>
<div class="collapse {{ Route::is(['portal.managers.reports.workplans.*', 'portal.managers.reports.sow.*', 'portal.managers.reports.training-requests.*', 'portal.managers.reports.training-provisions.*', 'portal.managers.reports.complete-trainings.*', 'portal.managers.reports.ratings.*', 'portal.managers.reports.pre-qualification-ratings.*', 'portal.managers.reports.trainer-ratings.*', 'portal.managers.reports.trainee-ratings.*', 'portal.managers.reports.pre-evaluations.*', 'portal.managers.reports.post-evaluations.*']) ? 'show' : '' }}" id="collapse-reports-menu" data-bs-parent="#sidebar-accordion">
    {{-- @can('generateWorkPlanReports', \App\Models\WorkplanModule::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.workplans.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.workplans.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-times"></i></div>
                WorkPlan Reports
            </a>
        </div>
    @endcan --}}
    {{-- @can('generatePreEvaluationReport', \App\Models\Evaluation::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.pre-evaluations.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.pre-evaluations.index') }}">
                <div class="nav-link-icon"><i class="fa fa-check-circle"></i></div>
                Pre Evaluation Reports
            </a>
        </div>
    @endcan
    @can('generatePostEvaluationReport', \App\Models\Evaluation::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.post-evaluations.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.post-evaluations.index') }}">
                <div class="nav-link-icon"><i class="fa fa-check-circle"></i></div>
                Post Evaluation Reports
            </a>
        </div>
    @endcan --}}
    @can('generateSowReports', \App\Models\Sow::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.sow.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.sow.index') }}">
                <div class="nav-link-icon"><i class="fas fa-file-contract"></i></div>
                SOW Reports
            </a>
        </div>
    @endcan
    @can('generateTrainingRequestReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.training-requests.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.training-requests.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                Training Request Reports
            </a>
        </div>
    @endcan
    @can('generateTrainingProvisionReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.training-provisions.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.training-provisions.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                Training Provision Reports
            </a>
        </div>
    @endcan
    @can('generateCompleteTrainingReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.complete-trainings.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.complete-trainings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-check"></i></div>
                Complete Training Reports
            </a>
        </div>
    @endcan
    @can('generatePreQualificationRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.pre-qualification-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.pre-qualification-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                PreQualification Rating Reports
            </a>
        </div>
    @endcan
    @can('generateTrainerRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.trainer-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.trainer-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                @prettify(config('settings.aliases.trainer')) Rating Reports
            </a>
        </div>
    @endcan
    @can('generateTraineeRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.managers.reports.trainee-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.managers.reports.trainee-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                @prettify(config('settings.aliases.trainee')) Rating Reports
            </a>
        </div>
    @endcan
</div>
