@can('view_trainee_portal')
    <div class="nav">
        <a class="nav-link {{ Route::is('portal.trainees.dashboard') ? 'active' : '' }}" href="{{ route('portal.trainees.dashboard') }}">
            <div class="nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
            Dashboard
        </a>
    </div>
@endcan
@can('viewAny', \App\Models\Trainee::class)
    <div class="nav">
        <a class="nav-link {{ Route::is(['portal.trainees.profiles.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.profiles.show') }}">
        <div class="nav-link-icon"><i class="fas fa-address-card"></i></div>
        My Profile
        </a>
    </div>
@endcan
@can('viewAny', \App\Models\TrainingRequest::class)
    <div class="nav">
        <a class="nav-link {{ Route::is(['portal.trainees.training-requests.*', 'portal.trainees.pre-evaluations.*', 'portal.trainees.post-evaluations.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.training-requests.index') }}">
        <div class="nav-link-icon"><i class="fas fa-diagnoses"></i></div>
        Trainings
        </a>
    </div>
@endcan
@can('generate_report')
<div class="nav">
    <a class="nav-link collapsed {{ Route::is(['portal.trainees.reports.workplans.*', 'portal.trainees.reports.sow.*', 'portal.trainees.reports.training-requests.*', 'portal.trainees.reports.training-provisions.*', 'portal.trainees.reports.complete-trainings.*', 'portal.trainees.reports.ratings.*', 'portal.trainees.reports.pre-qualification-ratings.*', 'portal.trainees.reports.trainer-ratings.*', 'portal.trainees.reports.trainee-ratings.*', 'portal.trainees.reports.pre-evaluations.*', 'portal.trainees.reports.post-evaluations.*']) ? 'active' : '' }}" href="#" data-bs-toggle="collapse" data-bs-target="#collapse-reports-menu" aria-expanded="false" aria-controls="collapse-reports-menu">
        <div class="nav-link-icon"><i class="fas fa-chart-bar"></i></div>
        Reports
        <div class="sidebar-collapse-arrow"><i class="fas fa-angle-down"></i></div>
    </a>
</div>
@endcan
<div class="collapse {{ Route::is(['portal.trainees.reports.workplans.*', 'portal.trainees.reports.sow.*', 'portal.trainees.reports.training-requests.*', 'portal.trainees.reports.training-provisions.*', 'portal.trainees.reports.complete-trainings.*', 'portal.trainees.reports.ratings.*', 'portal.trainees.reports.pre-qualification-ratings.*', 'portal.trainees.reports.trainer-ratings.*', 'portal.trainees.reports.trainee-ratings.*', 'portal.trainees.reports.pre-evaluations.*', 'portal.trainees.reports.post-evaluations.*']) ? 'show' : '' }}" id="collapse-reports-menu" data-bs-parent="#sidebar-accordion">
    @can('generateWorkPlanReports', \App\Models\WorkplanModule::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.workplans.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.workplans.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-times"></i></div>
                WorkPlan Reports
            </a>
        </div>
    @endcan
    {{-- @can('generatePreEvaluationReport', \App\Models\Evaluation::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.pre-evaluations.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.pre-evaluations.index') }}">
                <div class="nav-link-icon"><i class="fa fa-check-circle"></i></div>
                Pre Evaluation Reports
            </a>
        </div>
    @endcan
    @can('generatePostEvaluationReport', \App\Models\Evaluation::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.post-evaluations.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.post-evaluations.index') }}">
                <div class="nav-link-icon"><i class="fa fa-check-circle"></i></div>
                Post Evaluation Reports
            </a>
        </div>
    @endcan --}}
    @can('generateTrainingRequestReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.training-requests.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.training-requests.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                Training Request Reports
            </a>
        </div>
    @endcan
    @can('generateTrainingProvisionReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.training-provisions.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.training-provisions.index') }}">
                <div class="nav-link-icon"><i class="fas fa-calendar-check"></i></div>
                Training Provision Reports
            </a>
        </div>
    @endcan
    @can('generateCompleteTrainingReports', \App\Models\TrainingRequest::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.complete-trainings.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.complete-trainings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-check"></i></div>
                Complete Training Reports
            </a>
        </div>
    @endcan
    @can('generateRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.pre-qualification-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.pre-qualification-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                PreQualification Rating Reports
            </a>
        </div>
    @endcan
    @can('generateRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.trainer-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.trainer-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                @prettify(config('settings.aliases.trainer')) Rating Reports
            </a>
        </div>
    @endcan
    @can('generateRatingReports', \App\Models\Rating::class)
        <div class="sidebar-menu-nested nav">
            <a class="nav-link {{ Route::is(['portal.trainees.reports.trainee-ratings.*']) ? 'active' : '' }}" href="{{ route('portal.trainees.reports.trainee-ratings.index') }}">
                <div class="nav-link-icon"><i class="fa fa-star"></i></div>
                @prettify(config('settings.aliases.trainee')) Rating Reports
            </a>
        </div>
    @endcan
</div>
