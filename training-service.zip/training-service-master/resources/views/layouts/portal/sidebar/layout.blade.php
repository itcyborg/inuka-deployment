<nav class="sidebar accordion sidebar-dark" id="sidebar-accordion">
    <a class="sidebar-brand text-uppercase" href="#">
        {{ config('app.name') }}
    </a>
    <div class="sidebar-menu">
        @includeWhen(Route::is('portal.managers.*'), 'layouts.portal.sidebar.manager')
        @includeWhen(Route::is('portal.trainees.*'), 'layouts.portal.sidebar.trainee')
        @includeWhen(Route::is('portal.trainers.*'), 'layouts.portal.sidebar.trainer')
    </div>
    <div class="sidebar-footer">
        {{ config('app.name') }} &#169; {{ date('Y') }}
    </div>
</nav>
