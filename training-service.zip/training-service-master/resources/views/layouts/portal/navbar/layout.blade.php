<div class="navbar-container">
    <nav class="top-nav navbar navbar-expand-lg navbar-dark position-absolute pe-2">
        <button class="btn order-1 order-lg-0 ms-2" id="sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
        @includeWhen(Route::is('portal.managers.*'), 'layouts.portal.navbar.manager')
        @includeWhen(Route::is('portal.trainees.*'), 'layouts.portal.navbar.trainee')
        @includeWhen(Route::is('portal.trainers.*'), 'layouts.portal.navbar.trainer')
    </nav>
</div>
