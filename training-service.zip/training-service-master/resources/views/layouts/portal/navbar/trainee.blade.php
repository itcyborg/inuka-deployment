<ul class="navbar-nav ms-auto">
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="notification-dropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-bell fa-lg"></i>
            <span class="badge bg-success py-1 px-1 mt-n3">
                <small>{{ $unreadNotifications }}</small>
            </span>
        </a>
        <div class="dropdown-menu dropdown-menu-right notifications" aria-labelledby="notification-dropdown">
            <x-notification :notifications="$userNotifications" />
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="user-dropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Hi, {{ Auth::user()->name }}
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="user-dropdown">
            <a href="{{ route('portal.trainees.user-profiles.show') }}" class="dropdown-item">
                <i class="fa fa-user" aria-hidden="true"></i>
                {{ __('My Profile') }}
            </a>
            <a href="{{ route('logout') }}"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                class="dropdown-item"
            >
            <i class="fa fa-power-off" aria-hidden="true"></i>
                {{ __('Logout') }}
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                @csrf
            </form>
        </div>
    </li>
</ul>
