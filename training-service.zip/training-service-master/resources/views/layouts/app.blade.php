<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <title>{{ config('app.name') }} - @yield('title')</title>

        <link rel="shortcut icon" href="{{ asset('img/favicons/favicon.ico') }}" type="image/x-icon">
        <link rel="icon" href="{{ asset('img/favicons/favicon.ico') }}" type="image/x-icon">

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0,user-scalable=0, shrink-to-fit=no"/>
        <meta name="description" content="@yield('meta-description')">
        <meta name="author" content="Inuka Africa">
        <meta name="theme-color" content="#212121">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        {{-- Social Meta Tags --}}
        @yield('app.social-metas')

        <link rel="canonical" href="{{ url()->current() }}" />
        <link href="{{ mix('css/app.css') }}" rel="stylesheet">
        @stack('app.css')
    </head>
    <body class="navigation-fixed">
        <div id="app" class="h-100 w-100">
            @include('layouts.alerts')
            @yield('app.content')
        </div>
        <script src="{{ mix('js/manifest.js') }}"></script>
        <script src="{{ mix('js/vendor.js') }}"></script>
        <script src="{{ mix('js/app.js') }}"></script>
        @stack('app.js')
    </body>
</html>
