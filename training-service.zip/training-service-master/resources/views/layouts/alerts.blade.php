<div class="toast-container position-fixed w-100 me-2">
	{{-- Display a single instance of an error message --}}
	@if(session()->has('error'))
		<x-toast :message="session('error')" type="error" />
	@endif

	{{-- Display a password reset success message --}}
	@if(session()->has('status'))
		<x-toast :message="session('status')" type="info" />
	@endif
	
	{{-- Display success messages --}}
	@if(session()->has('success'))
		<x-toast :message="session('success')" type="success" />
	@endif

	{{-- Message when verification link is requested again --}}
	@if (session()->has('resent'))
		<x-toast :message="trans('alerts.success.user.verification-email-resent')" type="info" />
	@endif
</div>