@extends('layouts.portal')
@section('title', 'Post Evaluations Reports')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="Post Evaluations Reports" />
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
