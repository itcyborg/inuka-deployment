@extends('layouts.portal')
@section('title', 'Statement of Works Reports')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$sows">
                    <x-datatable id="sow-report-table" class="table">
                        <thead>
                            <tr>
                                <th>Sow No</th>
                                <th>Fee in KES</th>
                                <th>Manager Signature</th>
                                <th>Manager Signature Date</th>
                                <th>@prettify(config('settings.aliases.trainer')) Signature</th>
                                <th>@prettify(config('settings.aliases.trainer')) Signature Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($sows as $sow)
                                <tr>
                                    <td>{{ $sow->sow_no }}</td>
                                    <td>@currency($sow->fee)</td>
                                    <td>{{ $sow->manager_signature ? "Signed!" : 'Unavailable' }}</td>
                                    <td>{{ format_date_time($sow->manager_signature_date) ?? 'N/A' }}</td>
                                    <td>{{ $sow->trainer_signature ? "Signed!" : 'Unavailable' }}</td>
                                    <td>{{ format_date_time($sow->trainer_signature_date) ?? 'N/A' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
