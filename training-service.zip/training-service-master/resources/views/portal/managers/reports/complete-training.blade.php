@extends('layouts.portal')
@section('title', 'Complete Trainings List')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$completeTrainings">
                    <x-datatable id="complete-training-report" class="table">
                        <thead>
                            <tr>
                                <th>{{ Str::title(config('settings.aliases.trainer')) }}</th>
                                <th>{{ Str::title(config('settings.aliases.trainee')) }}</th>
                                <th>Manager</th>
                                <th>Course</th>
                                <th>Status</th>
                                <th>Request On</th>
                                <th>Actual Start Date</th>
                                <th>Actual End Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($completeTrainings as $trainingProvision)
                                <tr>
                                    <td>{{ $trainingProvision->trainer->trainable->name }}</td>
                                    <td>{{ $trainingProvision->courseTrainee->trainee->trainable->name }}</td>
                                    <td>{{ $trainingProvision->manager->name }}</td>
                                    <td>{{ $trainingProvision->courseTrainee->course->name }}</td>
                                    <td>@prettify($trainingProvision->status)</td>
                                    <td>{{ format_date_time($trainingProvision->created_at) }}</td>
                                    <td>{{ format_date_time($trainingProvision->start_date) ?? 'N/A' }}</td>
                                    <td>{{ format_date_time($trainingProvision->end_date) ?? 'N/A' }}</td>
                                    </tr>
                            @endforeach
                        </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
