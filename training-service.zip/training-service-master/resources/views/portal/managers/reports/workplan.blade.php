@extends('layouts.portal')
@section('title', 'Work Plans Reports')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$workPlans">
                    <x-datatable id="workplan-report-table" class="table">
                        <thead>
                            <tr>
                                <th>@prettify(config('settings.aliases.trainee'))</th>
                                <th>Course</th>
                                <th>Number of Modules</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($workPlans as $workPlan)
                                <tr>
                                    <td>{{ $workPlan->trainingRequest->courseTrainee->trainee->trainable->name ?? 'Unavailable' }}</td>
                                    <td>{{ $workPlan->trainingRequest->courseTrainee->course->name ?? 'Unavailable'}}</td>
                                    <td>{{ $workPlan->modules->count() }} Module/s</td>
                                    <td>{{ format_date_time($workPlan->trainingRequest->start_date) ?? 'N/A' }}</td>
                                    <td>{{ format_date_time($workPlan->trainingRequest->end_date) ?? 'N/A' }}</td>
                                    <td>@prettify($workPlan->status)</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
