@extends('layouts.portal')
@section('title', config('settings.aliases.trainer').' Ratings Reports')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$trainerRatings">
                    <x-datatable id="trainer-ratings-report" class="table">
                            <thead>
                                <tr>
                                    {{-- <th>@prettify(config('settings.aliases.trainee'))</th> --}}
                                    <th class="w-25">User</th>
                                    <th>@prettify(config('settings.aliases.trainer'))</th>
                                    <th class="w-25">Question</th>
                                    <th class="text-center">Percentage Score</th>
                                    <th class="text-center">Awarded Marks</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($trainerRatings as $rating)
                                    <tr>
                                        <td>{{ $rating->user->name }}</td>
                                        <td>{{ $rating->entity->trainable->name }}</td>
                                        <td class="w-25">{{ $rating->rateable->name }}</td>
                                        <td class="text-center">{{ $rating->rating_percentage }}%</td>
                                        <td class="text-center">{{ $rating->value }} / {{ $rating->max_value }} </td>
                                    </tr>
                                @endforeach
                            </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
