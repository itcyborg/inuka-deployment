@extends('layouts.portal')
@section('title', 'Pre Qualification Ratings Reports')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$preQualificationRatings">
                    <x-datatable id="pre-ratings-report" class="table">
                            <thead>
                                <tr>
                                    <th>Manager</th>
                                    <th>@prettify(config('settings.aliases.trainer'))</th>
                                    <th>Question</th>
                                    <th>Percentage Score</th>
                                    <th>Awarded Marks</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($preQualificationRatings as $rating)
                                    <tr>
                                        <td>{{ $rating->user->name }}</td>
                                        <td>{{ $rating->entity->trainable->name }}</td>
                                        <td>{{ $rating->rateable->name }}</td>
                                        <td>{{ $rating->rating_percentage }}%</td>
                                        <td>{{ $rating->value }} / {{ $rating->max_value }} </td>
                                    </tr>
                                @endforeach
                            </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
