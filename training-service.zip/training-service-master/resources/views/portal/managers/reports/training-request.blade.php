@extends('layouts.portal')
@section('title', 'Training Request List')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$trainingRequests">
                    <x-datatable id="training-request-report-table" class="table">
                        <thead>
                            <tr>
                                <th>{{ Str::title(config('settings.aliases.trainer')) }}</th>
                                <th>{{ Str::title(config('settings.aliases.trainee')) }}</th>
                                <th>Manager</th>
                                <th>Course</th>
                                <th>Status</th>
                                <th>Request On</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($trainingRequests as $trainingRequest)
                                <tr>
                                    <td>{{ $trainingRequest->trainer->trainable->name }}</td>
                                    <td>{{ $trainingRequest->courseTrainee->trainee->trainable->name }}</td>
                                    <td>{{ $trainingRequest->manager->name }}</td>
                                    <td>{{ $trainingRequest->courseTrainee->course->name }}</td>
                                    <td>@prettify($trainingRequest->status)</td>
                                    <td>{{ format_date_time($trainingRequest->created_at) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
