@extends('layouts.portal')
@section('title', config('settings.aliases.trainee').' Ratings Reports')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="ratings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$traineeRatings">
                    <x-datatable id="trainee-ratings-report" class="table">
                            <thead>
                                <tr>
                                    <th>@prettify(config('settings.aliases.trainer'))</th>
                                    <th>@prettify(config('settings.aliases.trainee'))</th>
                                    <th>Question</th>
                                    <th>Percentage Score</th>
                                    <th>Awarded Marks</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($traineeRatings as $rating)
                                    <tr>
                                        <td>{{ $rating->user->name }}</td>
                                        <td>{{ $rating->entity->trainable->name }}</td>
                                        <td style="width:40%">{{ $rating->rateable->name }}</td>
                                        <td>{{ $rating->rating_percentage }}%</td>
                                        <td>{{ $rating->value }} / {{ $rating->max_value }} </td>
                                    </tr>
                                @endforeach
                            </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
