@extends('layouts.portal')
@section('title', 'Rating/Evaluation Parameters List')
@push('actions')
    @can('create', \App\Models\RatingParameter::class)
        <x-modals.forms.rating-parameter
            id="create-rating-parameter-modal"
            class="btn btn-primary btn-sm"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Rating/Evaluation Parameters" :collection="$ratingParameters">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Entity</th>
                                <th>Type</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($ratingParameters as $parameter)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $parameter->name }}</td>
                                    <td> @prettify($parameter->entity) </td>
                                    <td> @prettify($parameter->type) </td>
                                    <td class="text-center">
                                        @can('view', $parameter)
                                            <x-modals.tables.rating-parameter
                                                id="rating-parameter-show-modal-{{$parameter->id}}"
                                                class="btn btn-primary btn-sm"
                                                :parameter="$parameter"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-eye"></i>
                                                </x-slot>
                                            </x-modals.tables.service-template>
                                        @endcan
                                        @can('update', $parameter)
                                            <x-modals.forms.rating-parameter
                                                id="rating-parameter-update-modal-{{$parameter->id}}"
                                                class="btn btn-primary btn-sm"
                                                :parameter="$parameter"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.service-template>
                                        @endcan
                                        @can('delete', $parameter)
                                            <x-modals.confirmation
                                                id="rating-parameter-delete-modal-{{ $parameter->id }}"
                                                title="Delete Parameter"
                                                confirmation-title="Rating Parameter Deletion Confirmation"
                                                action="{{ route('portal.managers.rating-parameters.destroy', ['rating_parameter' => $parameter]) }}"
                                                method="DELETE"
                                                class="btn btn-danger btn-sm"
                                            >
                                                <i class="fas fa-times"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to activate this rating/evaluation parameter?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
