@extends('layouts.portal')
@section('title', 'Workplan Template')
@push('actions')
    @can('create', \App\Models\ModuleTemplate::class)
        <x-modals.forms.module-templates 
            id="module-templates-modal" 
            class="btn btn-primary btn-sm" 
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Modules" :collection="$modules">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="w-25">Name</th>
                                <th class="w-50">Description</th>
                                <th>Duration</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($modules as $module)
                                <tr>
                                    <td>{{ $module->name }}</td>
                                    <td>{{ $module->description }}</td>
                                    <td>{{ $module->duration }} Hours</td>
                                    <td class="text-center">
                                        @can('viewAny', \App\Models\Upload::class)
                                            <a title="View Training Materials" data-tooltip="tooltip" class="btn btn-success btn-sm" href="{{ route('portal.managers.training-materials.index', [
                                                'module_template' => $module
                                            ]) }}">
                                                <i class="fas fa-file-alt"></i>
                                            </a>
                                        @endcan
                                        @can('update', $module)
                                            <x-modals.forms.module-templates 
                                                id="module-templates-modal-{{$module->id}}" 
                                                class="btn btn-primary btn-sm" 
                                                :module="$module"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.module-templates>
                                        @endcan
                                        @can('delete', $module)
                                            <x-modals.confirmation
                                                id="module-deletion-modal-{{ $module->id }}"
                                                title="Delete Module"
                                                confirmation-title="Module Deletion Confirmation"
                                                action="{{ route('portal.managers.module-templates.destroy', ['module_template' => $module]) }}" 
                                                method="DELETE"
                                                class="btn btn-danger btn-sm" 
                                            >
                                                <i class="fas fa-times"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to delete this module?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
