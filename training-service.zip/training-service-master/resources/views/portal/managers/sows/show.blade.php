@extends('layouts.portal')
@section('title', "Statement of Work Document")
@push('actions')
    @can('update', $sow)
        <x-modals.forms.sow
            id="update-sows-modal"
            class="btn btn-primary btn-sm"
            :effort-level-units="config('settings.effort_level_units')"
            :sow="$sow"
        />
    @endcan
@endpush
@section('content')
    <main id="sow">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="Statement of Work Details">
                    <x-tables.sow :sow="$sow" />
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
