@extends('layouts.portal')
@section('title', $topic->name)
@section('content')
    <main id="tenants-show">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="general-tab" data-bs-toggle="tab" href="#general" role="tab"
                                aria-controls="general" aria-selected="true">List or Training Providers</a>
                        </li>

                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="expertise-tab" data-bs-toggle="tab" href="#expertise" role="tab"
                                aria-controls="expertise" aria-selected="false">Areas of Expertise</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        {{-- General Infromation tab --}}
                        <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Website</th>
                                        <th>County Location</th>
                                        <th>Status</th>
                                        <th>Raise Training Request</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($topic->trainers as $trainer)
                                        <tr>
                                            <td class="text-center">{{ $trainer->trainable->name }}</td>
                                            <td class="text-center">{{ $trainer->trainable->email }}</td>
                                            <td class="text-center">{{ $trainer->website }}</td>
                                            <td class="text-center">{{ $trainer->trainable->county->name }}</td>
                                            <td class="text-center">@prettify($trainer->trainable->status)</td>
                                            <td class="text-center">
                                                <a href="{{ route('portal.managers.topics.show', ['topic' => $topic]) }}"
                                                    class="btn btn-primary btn-sm">
                                                    <i class="fab fa-wpforms"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        {{-- Topics, Areas and Services tab --}}
                        <div class="tab-pane fade" id="expertise" role="tabpanel" aria-labelledby="expertise-tab">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Topic</th>
                                        <th>Area</th>
                                        <th>Service</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($trainer->topics as $topic)
                                        <tr>
                                            <td>{{ $topic->name }}</td>
                                            <td>{{ $topic->area->name }}</td>
                                            <td>{{ $topic->area->service->name }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>
            </x-cards.content>
            </div>
        </section>
    </main>
@endsection
