@extends('layouts.portal')
@section('title', 'Notifications')
@section('content')
    <main id="notifications-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content :collection="$notifications">
                    <x-slot name="title">
                        <div class="d-flex justify-content-end">
                            {{ $notifications->links() }}
                        </div>
                    </x-slot>
                    <x-tables.notifications 
                        route-prefix="portal.managers.notifications"
                        :notifications="$notifications" 
                    />
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
