@extends('layouts.portal')
@section('title', 'Dashboard')
@section('content')
    <main id="dashboard">
        <section class="row justify-content-center">
            <div class="col-lg-3">
                <x-cards.info-box title="{{ prettify(Str::plural(config('settings.aliases.trainer'))) }}" :number="$trainers->count()" icon-background="bg-aqua">
                    <x-slot name="icon">
                        <i class="fas fa-users"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-3">
                <x-cards.info-box title="{{ prettify(Str::plural(config('settings.aliases.trainee'))) }}" :number="$trainees->count()" icon-background="bg-red">
                    <x-slot name="icon">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-3">
                <x-cards.info-box title="Training Requests" :number="$trainingRequests['requests']->count()" icon-background="bg-green">
                    <x-slot name="icon">
                        <i class="fas fa-id-card-alt"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-3">
                <x-cards.info-box title="Training Provisions" :number="$trainingRequests['provisions']->count()" icon-background="bg-yellow">
                    <x-slot name="icon">
                        <i class="fas fa-calendar-check"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
        </section>

        <section class="row justify-content-center">
            <div class="col-lg-6">
                <x-cards.content title="Overview of Training Requests" :collection="$trainingRequests['requests']" class="chart">
                    <x-charts.doughnuts.training-requests
                        id="requests-summary"
                        :payload="$trainingRequests['charts']['requests']"
                    />
                </x-cards.content>
            </div>
            <div class="col-lg-6">
                <x-cards.content title="Overview of Training Provisions" :collection="$trainingRequests['provisions']" class="chart">
                    <x-charts.doughnuts.training-provisions
                        id="provisions-summary"
                        :payload="$trainingRequests['charts']['provisions']"
                    />
                </x-cards.content>
            </div>
        </section>

        <section class="row">
            <div class="col-lg-4">
                <x-cards.info-box title="Unapproved Training Requests" :progress="$trainingRequests['unapproved']" number-suffix="%" background-color="bg-aqua" icon-background="bg-aqua">
                    <x-slot name="icon">
                        <i class="fas fa-hourglass-half"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-4">
                <x-cards.info-box title="Ongoing Training Provisions" :progress="$trainingRequests['ongoing']" number-suffix="%" background-color="bg-yellow" icon-background="bg-yellow">
                    <x-slot name="icon">
                        <i class="fas fa-calendar-alt"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-4">
                <x-cards.info-box title="Completed Training Provisions" :progress="$trainingRequests['completed']" number-suffix="%" background-color="bg-green" icon-background="bg-green">
                    <x-slot name="icon">
                        <i class="fas fa-check"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
        </section>

        <section class="row">
            <div class="col-lg-12">
                <x-cards.content class="dashboard-card" title="Latest Training Requests and Provisions" :collection="$trainingRequests['all']">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="index">#</th>
                                <th>@prettify(config('settings.aliases.trainee'))</th>
                                <th>@prettify(config('settings.aliases.trainer'))</th>
                                <th>Training Need</th>
                                <th>Status</th>
                                <th class="actions"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($trainingRequests['all'] as $request)
                                <tr>
                                    <td style="white-space: nowrap;">{{ $loop->iteration }}</td>
                                    <td style="white-space: nowrap;">{{ $request->topicTrainee->trainee->trainable->name }}</td>
                                    <td style="white-space: nowrap;">{{ $request->trainer->trainable->name }}</td>
                                    <td style="white-space: nowrap;">{{ $request->topicTrainee->topic->name }}</td>
                                    <td style="white-space: nowrap;">@prettify($request->status)</td>
                                    <td class="text-center">
                                        @can('view', $request)
                                            <a class="btn btn-primary btn-sm" data-tooltip="tooltip" title="View Training Request" href="{{ route('portal.managers.training-requests.show', [
                                                'training_request' => $request
                                            ]) }}">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>

        <section class="row">
            <div class="col-lg-4">
                <x-cards.content title="Number of Services">
                    <x-cards.stat-box :number="$services->count()" text="Services" :footer-url="route('portal.managers.trainers.index')" footer-text="View" background-color="bg-aqua">
                        <x-slot name="icon">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </x-slot>
                    </x-cards.stat-box>
                </x-cards.content>
            </div>
            <div class="col-lg-4">
                <x-cards.content title="Number of Topics">
                    <x-cards.stat-box :number="$topics->count()" text="Topics" :footer-url="route('portal.managers.trainees.index')" footer-text="View" background-color="bg-yellow">
                        <x-slot name="icon">
                            <i class="fa fa-briefcase"></i>
                        </x-slot>
                    </x-cards.stat-box>
                </x-cards.content>
            </div>
            <div class="col-lg-4">
                <x-cards.content title="Number of workplan modules">
                    <x-cards.stat-box :number="$modules->count()" text="Workplan Modules" :footer-url="route('portal.managers.module-templates.index')" footer-text="View" background-color="bg-red">
                        <x-slot name="icon">
                            <i class="fas fa-calendar-times"></i>
                        </x-slot>
                    </x-cards.stat-box>
                </x-cards.content>
            </div>
        </section>

        <section class="row">
            <div class="col-lg-12">
                <x-cards.content class="dashboard-card" title="New {{ prettify(Str::plural(config('settings.aliases.trainee'))) }}" :collection="$trainees">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="index">#</th>
                                <th>@prettify(config('settings.aliases.trainee')) Name</th>
                                <th>County</th>
                                <th>Rating</th>
                                <th>Status</th>
                                <th class="actions"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($trainees->take(5) as $trainee)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>@prettify($trainee->trainable->name) </td>
                                    <td>{{ $trainee->trainable->county->name ?? 'Unavailable' }}</td>
                                    <td>
                                      <x-rating-star :rating="$trainee->rating"/>
                                    </td>
                                    <td>@prettify($trainee->trainable->status)</td>
                                    <td class="text-center">
                                        @can('view', $trainee)
                                            <a href="{{ route('portal.managers.trainees.show', ['trainee' => $trainee,]) }}" class="btn btn-primary btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>

        <section class="row">
            <div class="col-lg-12">
                <x-cards.content class="dashboard-card" title="New {{ prettify(Str::plural(config('settings.aliases.trainer'))) }}" :collection="$trainers">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="index">#</th>
                                <th>Name</th>
                                <th>County</th>
                                <th>Rating</th>
                                <th>Status</th>
                                <th class="actions"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($trainers as $trainer)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $trainer->trainable->name }}</td>
                                    <td>{{ $trainer->trainable->county->name ?? 'Unavailable' }}</td>
                                    <td>
                                      <x-rating-star :rating="$trainer->rating"/>
                                    </td>
                                    <td>@prettify($trainer->trainable->status)</td>
                                    <td class="text-center">
                                        @can('view', $trainer)
                                            <a class="btn btn-primary btn-sm" data-tooltip="tooltip" title="View @prettify(config('settings.aliases.trainer'))" href="{{ route('portal.managers.trainers.show', [
                                                'trainer' => $trainer
                                            ]) }}">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
