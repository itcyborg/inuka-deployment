@extends('layouts.portal')
@section('title', $setting->name)
@push('actions')
    @can('create', \App\Models\SettingValue::class)
        <x-modals.forms.value
            id="setting-value-modal-{{ $setting->id }}"
            class="btn btn-primary btn-sm"
            :setting="$setting"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Setting Values" :collection="$values = $setting->values">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>name</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($values as $value)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>@prettify($value->name)</td>
                                    <td class="text-center">
                                        @can('update', $value)
                                            <x-modals.forms.value
                                                id="value-modal-{{$value->id}}"
                                                class="btn btn-primary btn-sm"
                                                :value="$value"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.value>
                                        @endcan
                                        @can('delete', $setting)
                                            <x-modals.confirmation
                                                id="module-deletion-modal-{{ $value->id }}"
                                                title="Delete Module"
                                                confirmation-title="Value Deletion Confirmation"
                                                action="{{ route('portal.managers.values.destroy', ['settingValue' => $value]) }}"
                                                method="DELETE"
                                                class="btn btn-danger btn-sm"
                                            >
                                                <i class="fas fa-times"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to delete this setting value?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection

