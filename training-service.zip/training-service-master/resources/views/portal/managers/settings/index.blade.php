@extends('layouts.portal')
@section('title', 'Settings List')
@section('content')
    <main id="settings-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Settings" :collection="$settings">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($settings as $setting)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td> @prettify($setting->name) </td>
                                    <td>{{ $setting->description }}</td>
                                    <td class="text-center">
                                        @can('view', $setting)
                                            @if ($setting->type == 'multiple')
                                                <a href="{{ route('portal.managers.settings.show', [ 'setting' => $setting ]) }}" class="btn btn-primary btn-sm">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            @else
                                            @can('update', $setting)
                                                <x-modals.forms.value
                                                    id="value-modal-{{ $setting->values[0]['id'] }}"
                                                    class="btn btn-primary btn-sm"
                                                    :value="$setting->values[0]"
                                                >
                                                    <x-slot name="buttonText">
                                                        <i class="fas fa-edit"></i>
                                                    </x-slot>
                                                </x-modals.forms.value>
                                            @endcan
                                            @endif
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
