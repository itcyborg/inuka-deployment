@extends('layouts.portal')
@section('title', $user->name)
@section('content')
    <main id="tenants-show">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content>
                    <x-profiles.user :user="$user" :permissions="$permissions" :roles="$roles" />
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
