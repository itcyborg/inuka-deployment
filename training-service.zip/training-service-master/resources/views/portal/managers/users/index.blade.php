@extends('layouts.portal')
@section('title', 'User List')
@section('content')
    <main id="users-list">
        <div class="row">
            <div class="col-lg-12">
                <x-cards.content>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        @can('assignPermission', Auth::user())
                            <li class="nav-item" role="presentation">
                                <a class="nav-link {{ request()->query('tab') == 'manager-tab' || !request()->query('tab') ? 'active' : '' }}" id="manager-tab" data-bs-toggle="tab" href="#manager" role="tab"
                                    aria-controls="manager" aria-selected="true">Manager Users</a>
                            </li>
                        @endcan
                        @can('assignPermission', Auth::user())
                            <li class="nav-item" role="presentation">
                                <a class="nav-link {{ request()->query('tab') == 'trainer-tab' ? 'active' : '' }}" id="trainer-tab" data-bs-toggle="tab" href="#trainer" role="tab"
                                    aria-controls="trainer" aria-selected="false">Trainer Users</a>
                            </li>
                        @endcan
                        @can('assignPermission', Auth::user())
                            <li class="nav-item" role="presentation">
                                <a class="nav-link {{ request()->query('tab') == 'trainee-tab' ? 'active' : '' }}" id="trainee-tab" data-bs-toggle="tab" href="#trainee" role="tab"
                                    aria-controls="trainee" aria-selected="false">Trainee Users</a>
                            </li>
                        @endcan
                        @can('assignPermission', Auth::user())
                            <li class="nav-item" role="presentation">
                                <a class="nav-link {{ request()->query('tab') == 'all-tab' ? 'active' : '' }}" id="all-tab" data-bs-toggle="tab" href="#all" role="tab"
                                    aria-controls="all" aria-selected="false">Unassigned Users</a>
                            </li>
                        @endcan
                    </ul>
                    <div class="tab-content">
                        @can('assignPermission', Auth::user())
                            <div class="tab-pane fade {{ request()->query('tab') == 'manager-tab' || !request()->query('tab') ? 'show active' : '' }} " id="manager" role="tabpanel" aria-labelledby="manager-tab">
                                @if($managers->isNotEmpty())
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone Number</th>
                                                <th>Gender</th>
                                                <th>Status</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($managers as $user)
                                                <tr>
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ $user->name }}</td>
                                                    <td>{{ $user->email }}</td>
                                                    <td>{{ $user->telephone }}</td>
                                                    <td>@prettify($user->gender)</td>
                                                    <td>{{ $user->status }}</td>
                                                    <td class="text-center">
                                                        @can('view', $user)
                                                                <a href="{{ route('portal.managers.users.show', [
                                                                            'user' => $user,
                                                                        ]) }}" class="btn btn-primary btn-sm">
                                                                    <i class="fa fa-eye"></i>
                                                                </a>
                                                        @endcan
                                                        @can('activate', $user)
                                                            <x-modals.confirmation
                                                                id="user-activation-modal-{{ $user->id }}"
                                                                title="Activate {{ prettify($user->name) }}"
                                                                confirmation-title="{{ prettify($user->name) }} Activation Confirmation"
                                                                action="{{ route('portal.managers.users.activate', ['user' => $user, 'tab' => 'manager-tab']) }}"
                                                                method="PATCH"
                                                                class="btn btn-success btn-sm"
                                                            >
                                                                <i class="fas fa-check"></i>
                                                                <x-slot name="content">
                                                                    Are you sure you would like to activate this user?
                                                                </x-slot>
                                                            </x-modals.confirmation>
                                                        @endcan
                                                        @can('deactivate', $user)
                                                            @can('create', \App\Models\Comment::class)
                                                                <x-modals.forms.deactivation-reason
                                                                    id="user-deactivation-reason-modal-{{$user->id }}"
                                                                    class="btn btn-danger btn-sm"
                                                                    :user="$user"
                                                                    object="manager-tab"
                                                                >
                                                                    <x-slot name="buttonText">
                                                                        <i class="fa fa-times"></i>
                                                                    </x-slot>
                                                                </x-modals.forms.deactivation-reason>
                                                            @endcan
                                                        @endcan
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="empty-collection">
                                        <h5>Sorry, no TSP users are available</h5>
                                    </div>
                                @endif
                            </div>
                        @endcan
                        @can('assignPermission', Auth::user())
                            <div class="tab-pane fade {{ request()->query('tab') == 'trainer-tab' ? 'show active' : '' }}" id="trainer" role="tabpanel" aria-labelledby="trainer-tab">
                                @if($trainers->isNotEmpty())
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone Number</th>
                                                <th>Gender</th>
                                                <th>Status</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($trainers as $user)
                                                <tr>
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ $user->name }}</td>
                                                    <td>{{ $user->email }}</td>
                                                    <td>{{ $user->telephone }}</td>
                                                    <td>@prettify($user->gender)</td>
                                                    <td>{{ $user->status }}</td>
                                                    <td class="text-center">
                                                        @can('view', $user)
                                                                <a href="{{ route('portal.managers.users.show', [
                                                                            'user' => $user,
                                                                        ]) }}" class="btn btn-primary btn-sm">
                                                                    <i class="fa fa-eye"></i>
                                                                </a>
                                                        @endcan
                                                        @can('activate', $user)
                                                            <x-modals.confirmation
                                                                id="user-activation-modal-{{ $user->id }}"
                                                                title="Activate {{ prettify($user->name) }}"
                                                                confirmation-title="{{ prettify($user->name) }} Activation Confirmation"
                                                                action="{{ route('portal.managers.users.activate', ['user' => $user, 'tab' => 'trainer-tab']) }}"
                                                                method="PATCH"
                                                                class="btn btn-success btn-sm"
                                                            >
                                                                <i class="fas fa-check"></i>
                                                                <x-slot name="content">
                                                                    Are you sure you would like to activate this user?
                                                                </x-slot>
                                                            </x-modals.confirmation>
                                                        @endcan
                                                        @can('deactivate', $user)
                                                            @can('create', \App\Models\Comment::class)
                                                                <x-modals.forms.deactivation-reason id="user-deactivation-reason-modal-{{$user->id }}" class="btn btn-danger btn-sm"
                                                                    :user="$user"
                                                                    object="trainer-tab"
                                                                >
                                                                    <x-slot name="buttonText">
                                                                        <i class="fa fa-times"></i>
                                                                    </x-slot>
                                                                </x-modals.forms.deactivation-reason>
                                                            @endcan
                                                        @endcan
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="empty-collection">
                                        <h5>Sorry, no trainer users are available</h5>
                                    </div>
                                @endif
                            </div>
                        @endcan
                        @can('assignPermission', Auth::user())
                            <div class="tab-pane fade {{ request()->query('tab') == 'trainee-tab' ? 'show active' : '' }}" id="trainee" role="tabpanel" aria-labelledby="trainee-tab">
                                @if($trainees->isNotEmpty())
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone Number</th>
                                                <th>Gender</th>
                                                <th>Status</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($trainees as $user)
                                                <tr>
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ $user->name }}</td>
                                                    <td>{{ $user->email }}</td>
                                                    <td>{{ $user->telephone }}</td>
                                                    <td>@prettify($user->gender)</td>
                                                    <td>{{ $user->status }}</td>
                                                    <td class="text-center">
                                                        @can('view', $user)
                                                                <a href="{{ route('portal.managers.users.show', [
                                                                            'user' => $user,
                                                                        ]) }}" class="btn btn-primary btn-sm">
                                                                    <i class="fa fa-eye"></i>
                                                                </a>
                                                        @endcan
                                                        @can('activate', $user)
                                                            <x-modals.confirmation
                                                                id="user-activation-modal-{{ $user->id }}"
                                                                title="Activate {{ prettify($user->name) }}"
                                                                confirmation-title="{{ prettify($user->name) }} Activation Confirmation"
                                                                action="{{ route('portal.managers.users.activate', ['user' => $user, 'tab' => 'trainee-tab']) }}"
                                                                method="PATCH"
                                                                class="btn btn-success btn-sm"
                                                            >
                                                                <i class="fas fa-check"></i>
                                                                <x-slot name="content">
                                                                    Are you sure you would like to activate this user?
                                                                </x-slot>
                                                            </x-modals.confirmation>
                                                        @endcan
                                                        @can('deactivate', $user)
                                                            @can('create', \App\Models\Comment::class)
                                                                <x-modals.forms.deactivation-reason id="user-deactivation-reason-modal-{{$user->id }}" class="btn btn-danger btn-sm" :user="$user" object="trainee-tab">
                                                                    <x-slot name="buttonText">
                                                                        <i class="fa fa-times"></i>
                                                                    </x-slot>
                                                                </x-modals.forms.deactivation-reason>
                                                            @endcan
                                                        @endcan
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="empty-collection">
                                        <h5>Sorry, no trainee users are available</h5>
                                    </div>
                                @endif
                            </div>
                        @endcan
                        @can('assignPermission', Auth::user())
                            <div class="tab-pane fade {{ request()->query('tab') == 'all-tab' ? 'show active' : '' }}" id="all" role="tabpanel" aria-labelledby="all-tab">
                                @if($all->isNotEmpty())
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone Number</th>
                                                <th>Gender</th>
                                                <th>Status</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all as $user)
                                                <tr>
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ $user->name }}</td>
                                                    <td>{{ $user->email }}</td>
                                                    <td>{{ $user->telephone }}</td>
                                                    <td>@prettify($user->gender)</td>
                                                    <td>{{ $user->status }}</td>
                                                    <td class="text-center">
                                                        @can('view', $user)
                                                            <x-modals.forms.assign-role
                                                                id="assign-user-modal-{{$user->id}}"
                                                                class="btn btn-primary btn-sm"
                                                                :user="$user"
                                                                :roles="$roles"
                                                            >
                                                                <x-slot name="buttonText">
                                                                    <i class="fas fa-edit"></i>
                                                                </x-slot>
                                                            </x-modals.forms.assign-role>
                                                        @endcan
                                                        @can('activate', $user)
                                                            <x-modals.confirmation
                                                                id="user-activation-modal-{{ $user->id }}"
                                                                title="Activate {{ prettify($user->name) }}"
                                                                confirmation-title="{{ prettify($user->name) }} Activation Confirmation"
                                                                action="{{ route('portal.managers.users.activate', ['user' => $user, 'tab' => 'all-tab']) }}"
                                                                method="PATCH"
                                                                class="btn btn-success btn-sm"
                                                            >
                                                                <i class="fas fa-check"></i>
                                                                <x-slot name="content">
                                                                    Are you sure you would like to activate this user?
                                                                </x-slot>
                                                            </x-modals.confirmation>
                                                        @endcan
                                                        @can('deactivate', $user)
                                                            @can('create', \App\Models\Comment::class)
                                                                <x-modals.forms.deactivation-reason id="user-deactivation-reason-modal-{{$user->id }}" class="btn btn-danger btn-sm" :user="$user" object="all-tab">
                                                                    <x-slot name="buttonText">
                                                                        <i class="fa fa-times"></i>
                                                                    </x-slot>
                                                                </x-modals.forms.deactivation-reason>
                                                            @endcan
                                                        @endcan
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <div class="empty-collection">
                                        <h5>Sorry, no unassigned users are available</h5>
                                    </div>
                                @endif
                            </div>
                        @endcan
                    </div>
                </x-cards.content>
            </div>
        </div>
    </main>
@endsection
