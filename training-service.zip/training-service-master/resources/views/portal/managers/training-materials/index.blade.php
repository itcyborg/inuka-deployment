@extends('layouts.portal')
@section('title', 'Training Materials for this module')
@push('actions')
    @can('create', \App\Models\Upload::class)
        <x-modals.forms.training-materials 
            id="training-materials-modal" 
            class="btn btn-primary btn-sm"
            :module="$module"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Training Materials" :collection="$materials">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Module</th>
                                <th>Uploaded By</th>
                                <th>Uploaded At</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($materials as $material)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $material->name }}</td>
                                    <td>{{ $material->uploadable->name }}</td>
                                    <td>{{ $material->owner->name }}</td>
                                    <td>@datetime($material->created_at)</td>
                                    <td class="text-center">
                                        @can('download', $material)
                                            <a title="Download this training material" data-tooltip="tooltip" class="btn btn-success btn-sm" href="{{ route('portal.managers.training-materials.download', [
                                                'upload' => $material
                                            ]) }}">
                                                <i class="fas fa-file-download"></i>
                                            </a>
                                        @endcan        
                                        @can('update', $material)
                                            <x-modals.forms.training-materials 
                                                id="training-materials-modal-{{ $material->id }}" 
                                                class="btn btn-primary btn-sm"
                                                :material="$material"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.training-materials>
                                        @endcan 
                                        @can('delete', $material)
                                            <x-modals.confirmation
                                                id="material-deletion-modal-{{ $material->id }}"
                                                title="Delete Training Material"
                                                confirmation-title="Training Material Deletion Confirmation"
                                                action="{{ route('portal.managers.training-materials.destroy', ['upload' => $material]) }}" 
                                                method="DELETE"
                                                class="btn btn-danger btn-sm" 
                                            >
                                                <i class="fas fa-times"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to delete this training material?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan                                       
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection