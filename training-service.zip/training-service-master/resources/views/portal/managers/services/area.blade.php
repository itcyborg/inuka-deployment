@extends('layouts.portal')
@section('title', $service->name)
@push('actions')
    @can('create', \App\Models\Service::class)
        <x-modals.forms.area
            id="area-modal"
            class="btn btn-primary btn-sm"
            :service="$service"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Service Areas" :collection="$areas = $service->areas">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>name</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($areas as $area)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $area->name }}</td>
                                    <td class="text-center">
                                        @can('view', $area)
                                            <a href="{{ route('portal.managers.areas.show', [
                                                        'area' => $area,
                                                    ]) }}" class="btn btn-primary btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                        @can('update', $area)
                                            <x-modals.forms.area
                                                id="area-modal-{{$area->id}}"
                                                class="btn btn-primary btn-sm"
                                                :area="$area"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.area>
                                        @endcan
                                        @if (!$area->hasTopics())
                                            @can('delete', $area)
                                                <x-modals.confirmation
                                                    id="area-deletion-modal-{{ $area->id }}"
                                                    title="Delete area"
                                                    confirmation-title="Area Deletion Confirmation"
                                                    action="{{ route('portal.managers.areas.destroy', ['area' => $area]) }}"
                                                    method="DELETE"
                                                    class="btn btn-danger btn-sm"
                                                >
                                                    <i class="fas fa-times"></i>
                                                    <x-slot name="content">
                                                        Are you sure you would like to activate this area?
                                                    </x-slot>
                                                </x-modals.confirmation>
                                            @endcan
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection

