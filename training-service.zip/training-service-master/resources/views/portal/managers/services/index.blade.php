@extends('layouts.portal')
@section('title', 'Services List')
@push('actions')
    @can('create', \App\Models\Service::class)
        <x-modals.forms.service-template
            id="create-service-modal"
            class="btn btn-primary btn-sm"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Services" :collection="$services">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>name</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($services as $service)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $service->name }}</td>
                                    <td class="text-center">
                                        @can('view', $service)
                                            <a href="{{ route('portal.managers.services.show', [
                                                        'service' => $service,
                                                    ]) }}" class="btn btn-primary btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                        @can('update', $service)
                                            <x-modals.forms.service-template
                                                id="service-modal-{{$service->id}}"
                                                class="btn btn-primary btn-sm"
                                                :service="$service"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.service-template>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
