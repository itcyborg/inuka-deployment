@extends('layouts.portal')
@section('title', 'Training '.prettify($type))
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Training {{ prettify($type) }}" :collection="$trainingRequests">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>@prettify(config('settings.aliases.trainee'))</th>
                                <th>@prettify(config('settings.aliases.trainer'))</th>
                                <th>Training Need</th>
                                <th>Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($trainingRequests as $trainingRequest)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $trainingRequest->topicTrainee->trainee->trainable->name }}</td>
                                    <td>{{ $trainingRequest->trainer->trainable->name }}</td>
                                    <td>{{ $trainingRequest->topicTrainee->topic->name }}</td>
                                    <td>@prettify($trainingRequest->status)</td>
                                    <td class="text-center">
                                        @can('view', $trainingRequest)
                                            <a class="btn btn-primary btn-sm" data-tooltip="tooltip" title="View Training @prettify($type)" href="{{ route('portal.managers.training-requests.show', [
                                                'training_request' => $trainingRequest
                                            ]) }}">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
