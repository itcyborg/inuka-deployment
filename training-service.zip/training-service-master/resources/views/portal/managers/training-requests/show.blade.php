@extends('layouts.portal')
@section('title', 'Training '.$trainingRequest->type().' Information')
@push('actions')
    @can('publish', $trainingRequest)
        <x-modals.confirmation
            id="training-request-publishing-modal"
            confirmation-title="Training {{ prettify($trainingRequest->type()) }} Publishing Confirmation"
            action="{{ route('portal.managers.training-requests.publish', [
                'training_request' => $trainingRequest,
            ]) }}"
            method="POST"
            class="btn btn-primary btn-sm"
        >
            Publish this Training @prettify($trainingRequest->type())
            <x-slot name="content">
                Are you sure you would like to publish this training {{ $trainingRequest->type() }} ?
            </x-slot>
        </x-modals.confirmation>
    @endcan
    @can('create', [\App\Models\Sow::class, $trainingRequest])
        <x-modals.forms.sow
            id="create-sows-modal"
            class="btn btn-primary btn-sm"
            :training-request="$trainingRequest"
            :effort-level-units="config('settings.effort_level_units')"
        />
    @endcan
    @can('view', $sow = $trainingRequest->sow)
        <a href="{{ route('portal.managers.sows.show', [
            'sow' => $sow
        ]) }}" class="btn btn-primary btn-sm">
            @if($sow->hasManagerSigned())
                View the SOW
            @else
                Sign the SOW
            @endif
        </a>
    @endcan
    {{-- @can('download', $sow )
        <a href="{{ route('portal.managers.sows.download', [
            'sow' => $sow
            ]) }}" class="btn btn-primary btn-sm">
                Download Sow
        </a>
    @endcan --}}
    @can('update', $sow = $trainingRequest->sow)
        <x-modals.forms.sow
            id="update-sows-modal"
            class="btn btn-primary btn-sm"
            :effort-level-units="config('settings.effort_level_units')"
            :sow="$sow"
        />
    @endcan
    @can('create', [\App\Models\Rating::class, $trainingRequest])
    <x-modals.forms.rating
        id="create-ratings-modal"
        action="{{ route('portal.managers.ratings.store', [
            'training_request' => $trainingRequest
        ]) }}"
        class="btn btn-primary btn-sm ms-auto"
        :training_request="$trainingRequest"
        :criteria="$criteria"
        object="trainer"
    />
    @endcan
    @can('view', [ \App\Models\Rating::class, $ratings = $trainingRequest->userRatings($user = Auth::user()) ])
        <x-modals.tables.ratings
            id="rating-show-modal"
            class="btn btn-primary btn-sm ms-auto"
            :ratings="$ratings"
            object="trainer"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="Training {{ prettify($trainingRequest->type()) }} Summary">
                    <x-training-request :training-request="$trainingRequest" :preEvaluations="$preEvaluations" :postEvaluations="$postEvaluations" :trainerRatings="$trainerRatings" :traineeRatings="$traineeRatings" :postEvaluationCriteria="$postEvaluationCriteria"/>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
