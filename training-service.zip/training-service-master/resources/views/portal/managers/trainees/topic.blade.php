@extends('layouts.portal')
@section('title', $topic->name)
@can('viewAny', \App\Models\ModuleTemplate::class) 
    @push('actions')
        <a href="{{ route('portal.managers.module-templates.index') }}" class="btn btn-primary btn-sm">
            Manage Workplan Template
        </a>  
    @endpush
    @if(!$workplanUploads && !$workplanModules)
        @push('status-alerts')
            <div class="alert alert-danger mb-1 alert-dismissible fade show" role="alert">
                Please note that you have not added any training materials or workplan module templates to your workplan template. Click <a href="{{ route('portal.managers.module-templates.index') }}" class="alert-link">here</a> to manage your workplan template.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endpush
    @endif
@endcan
@section('content')
    <main id="tenants-show">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of trainers" :collection="$trainers = $topic->trainers">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Website</th>
                                <th>County</th>
                                <th>Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($trainers as $trainer)
                                <tr>
                                    <td>{{ $trainer->trainable->name }}</td>
                                    <td>{{ $trainer->trainable->email }}</td>
                                    <td>{{ $trainer->website }}</td>
                                    <td>{{ $trainer->trainable->county->name }}</td>
                                    <td>@prettify($trainer->trainable->status)</td>
                                    <td class="text-center">
                                        @can('create', [\App\Models\TrainingRequest::class, $trainee, $topic])
                                            <x-modals.forms.training-request 
                                                id="training-request-creation-modal-{{ $loop->index }}" 
                                                class="btn btn-success btn-sm" 
                                                :topic="$topic" 
                                                :trainer="$trainer" 
                                                :trainee="$trainee"
                                                :managers="$managers" 
                                            />
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
