@extends('layouts.portal')
@section('title', prettify(Str::plural(config('settings.aliases.trainee'))). ' List')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of {{ prettify(Str::plural(config('settings.aliases.trainee'))) }}" :collection="$trainees">
                    <x-datatable id="trainees-table" class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Type</th>
                                <th>Name</th>
                                <th>Business Sector</th>
                                <th>County</th>
                                <th>Rating</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($trainees as $trainee)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>@prettify(Str::singular($trainee->trainable_type)) </td>
                                    <td>@prettify($trainee->trainable->name ?? 'Unavailable') </td>
                                    <td>{{ $trainee->business_sector }}</td>
                                    <td>{{ $trainee->trainable->county->name ?? 'Unavailable' }}</td>
                                    <td>
                                        <x-rating-star :rating="$trainee->rating"/>
                                    </td>
                                    <td>@prettify($trainee->trainable->status ?? 'Unavailable')</td>
                                    <td class="text-center">
                                        @can('view', $trainee)
                                            <a href="{{ route('portal.managers.trainees.show', ['trainee' => $trainee,]) }}" class="btn btn-primary btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                        @can('activate', $trainee)
                                            <x-modals.confirmation
                                                id="trainee-activation-modal-{{ $trainee->id }}"
                                                title="Activate {{ prettify(config('settings.aliases.trainee')) }}"
                                                confirmation-title="{{ prettify(config('settings.aliases.trainee')) }} Activation Confirmation"
                                                action="{{ route('portal.managers.trainees.activate', ['trainee' => $trainee]) }}"
                                                method="PATCH"
                                                class="btn btn-success btn-sm"
                                            >
                                                <i class="fas fa-check"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to activate this trainee?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan
                                        @can('deactivate', $trainee)
                                            <x-modals.confirmation
                                                id="trainee-deactivation-modal-{{ $trainee->id }}"
                                                title="Deactivate {{ prettify(config('settings.aliases.trainee')) }}"
                                                confirmation-title="{{ prettify(config('settings.aliases.trainee')) }} Deactivation Confirmation"
                                                action="{{ route('portal.managers.trainees.deactivate', ['trainee' => $trainee]) }}"
                                                method="PATCH"
                                                class="btn btn-danger btn-sm"
                                            >
                                                <i class="fas fa-times"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to deactivate this trainee?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush
