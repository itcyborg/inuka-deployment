@extends('layouts.portal')
@section('title', $trainee->trainable->name ?? 'Unavailable')
@section('content')
    <main id="tenants-show">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content>
                    <x-profiles.trainee :trainee="$trainee" :topics="$topics" />
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
