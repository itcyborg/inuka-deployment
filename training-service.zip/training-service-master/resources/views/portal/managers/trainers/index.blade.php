@extends('layouts.portal')
@section('title', 'Trainers')
@push('css')
    <x-datatables-styles />
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of {{ prettify(Str::plural(config('settings.aliases.trainer'))) }}" :collection="$trainers">
                    <x-datatable id="trainers-table" class="table">
                        <thead>
                            <tr>
                                <th>@prettify(config('settings.aliases.trainer')) Type</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>County</th>
                                <th>Training Rating</th>
                                <th>Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($trainers as $trainer)
                                <tr>
                                    <td>@prettify(Str::singular($trainer->trainable_type))</td>
                                    <td>{{ $trainer->trainable->name }}</td>
                                    <td>{{ $trainer->trainable->email }}</td>
                                    <td>{{ $trainer->trainable->county->name }}</td>
                                    <td>
                                      <x-rating-star :rating="$trainer->rating"/>
                                    </td>
                                    <td>@prettify($trainer->status)</td>
                                    <td class="text-center">
                                        @can('view', $trainer)
                                            <a class="btn btn-primary btn-sm" data-tooltip="tooltip" title="View @prettify(config('settings.aliases.trainer'))" href="{{ route('portal.managers.trainers.show', [
                                                'trainer' => $trainer
                                            ]) }}">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                        @can('activate', $trainer)
                                            <x-modals.confirmation
                                                id="trainer-activation-modal-{{ $trainer->id }}"
                                                title="Activate {{ prettify(config('settings.aliases.trainer')) }}"
                                                confirmation-title="{{ prettify(config('settings.aliases.trainer')) }} Activation Confirmation"
                                                action="{{ route('portal.managers.trainers.activate', ['trainer' => $trainer]) }}"
                                                method="PATCH"
                                                class="btn btn-success btn-sm"
                                            >
                                                <i class="fas fa-check"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to activate this trainer?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan
                                        @can('deactivate', $trainer)
                                            <x-modals.confirmation
                                                id="trainer-deactivation-modal-{{ $trainer->id }}"
                                                title="Deactivate {{ prettify(config('settings.aliases.trainer')) }}"
                                                confirmation-title="{{ prettify(config('settings.aliases.trainer')) }} Deactivation Confirmation"
                                                action="{{ route('portal.managers.trainers.deactivate', ['trainer' => $trainer]) }}"
                                                method="PATCH"
                                                class="btn btn-danger btn-sm"
                                            >
                                                <i class="fas fa-times"></i>
                                                <x-slot name="content">
                                                    Are you sure you would like to deactivate this trainer?
                                                </x-slot>
                                            </x-modals.confirmation>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </x-datatable>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
@push('js')
    <x-datatables-scripts />
@endpush

