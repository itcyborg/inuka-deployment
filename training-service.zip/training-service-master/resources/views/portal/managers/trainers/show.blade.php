@extends('layouts.portal')
@section('title', $trainer->trainable->name)
@section('content')
@push('actions')
    @can('createPrequalification', [\App\Models\Rating::class, $trainer])
        <x-modals.forms.rating
            id="create-ratings-modal"
            action="{{ route('portal.managers.prequalifications.store', [
                'trainer' => $trainer
            ]) }}"
            button-text="Prequalify this trainer"
            class="btn btn-success btn-sm ms-auto"
            :trainer="$trainer"
            :criteria="$criteria"
            object="trainer"
        />
    @endcan
    @can('viewPrequalification', [ \App\Models\Rating::class, $ratings = $trainer->userRatings($user = Auth::user()) ])
        <x-modals.tables.ratings
            id="rating-show-modal"
            button-text="View trainer prequalification ratings"
            class="btn btn-primary btn-sm ms-auto"
            :ratings="$trainerPreQualificationRatings"
            object="pre-qualification"
        />
    @endcan
    @can('updatePrequalification', [\App\Models\Rating::class, $trainer])
        <x-modals.forms.rating
            id="ratings-modal-update"
            action="{{ route('portal.managers.prequalifications.update', [
                'trainer' => $trainer
            ]) }}"
            class="btn btn-primary btn-sm ms-auto"
            :trainer="$trainer"
            :criteria="$criteria"
            :ratings="$trainer->userRatings($user, true)"
            object="pre-qualification"
        />
    @endcan
@endpush
    <main id="tenants-show">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content>
                    <x-profiles.trainer :trainer="$trainer" />
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
