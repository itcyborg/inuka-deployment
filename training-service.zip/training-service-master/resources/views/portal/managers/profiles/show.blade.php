@extends('layouts.portal')
@section('title', prettify($user->name))
@push('actions')
    @can('updateProfile', $user)
        <x-modals.forms.profile.update
            id="profile-modal-{{ $user->id }}"
            class="btn btn-primary btn-sm ms-auto"
            :user="$user"
            :counties="$counties"
            object="user"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content>
                    <x-profiles.my-profile :user="$user" />
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
