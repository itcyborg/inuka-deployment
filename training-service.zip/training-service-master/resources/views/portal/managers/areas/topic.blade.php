@extends('layouts.portal')
@section('title', $area->name)
@push('actions')
    @can('create', \App\Models\Topic::class)
        <x-modals.forms.topic
            id="topic-modal"
            class="btn btn-primary btn-sm"
            :area="$area"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Area Topics" :collection="$topics = $area->topics">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>name</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($topics as $topic)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $topic->name }}</td>
                                    <td class="text-center">
                                        @can('update', $topic)
                                            <x-modals.forms.topic
                                                id="topic-modal-{{$topic->id}}"
                                                class="btn btn-primary btn-sm"
                                                :topic="$topic"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.topic>
                                        @endcan
                                        @if (!$topic->belongsToTrainers())
                                            @can('delete', $topic)
                                                <x-modals.confirmation
                                                    id="topic-deletion-modal-{{ $topic->id }}"
                                                    title="Delete topic"
                                                    confirmation-title="Topic Deletion Confirmation"
                                                    action="{{ route('portal.managers.topics.destroy', ['topic' => $topic]) }}"
                                                    method="DELETE"
                                                    class="btn btn-danger btn-sm"
                                                >
                                                    <i class="fas fa-times"></i>
                                                    <x-slot name="content">
                                                        Are you sure you would like to activate this topic?
                                                    </x-slot>
                                                </x-modals.confirmation>
                                            @endcan
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection

