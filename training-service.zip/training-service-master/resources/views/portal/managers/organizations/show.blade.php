@extends('layouts.portal')
@section('title', $organization->name.' Information')
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="Organization Summary">
                    <x-profiles.organization 
                        :organization="$organization"
                        :users="$users"
                    />
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
