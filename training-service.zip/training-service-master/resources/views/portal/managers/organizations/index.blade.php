@extends('layouts.portal')
@section('title', 'Group List')
@push('actions')
    @can('create', \App\Models\Organization::class)
        <x-modals.forms.organization
            id="create-organization-modal"
            class="btn btn-primary btn-sm"
            :counties="$counties"
        />
    @endcan
@endpush
@section('content')
    <main id="tenants-list">
        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="List of Organizations" :collection="$organizations">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Public Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Locality</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($organizations as $organization)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $organization->public_id }}</td>
                                    <td>{{ $organization->name }}</td>
                                    <td>{{ $organization->email }}</td>
                                    <td>{{ $organization->telephone }}</td>
                                    <td>{{ $organization->locality }}</td>
                                    <td class="text-center">
                                        @can('view', $organization)
                                            <a href="{{ route('portal.managers.organizations.show', ['organization' => $organization,]) }}" class="btn btn-primary btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                        @can('update', $organization)
                                            <x-modals.forms.organization
                                                id="organization-modal-{{$organization->id}}"
                                                class="btn btn-primary btn-sm"
                                                :organization="$organization"
                                                :counties="$counties"
                                            >
                                                <x-slot name="buttonText">
                                                    <i class="fas fa-edit"></i>
                                                </x-slot>
                                            </x-modals.forms.organization>
                                        @endcan
                                        @if (!$organization->hasUsers() && is_null($organization->trainee))
                                            @can('delete', $organization)
                                                <x-modals.confirmation
                                                    id="Organization-modal-{{ $organization->id }}"
                                                    title="Delete Organizatio"
                                                    confirmation-title="Organization Deletion Confirmation"
                                                    action="{{ route('portal.managers.organizations.destroy', ['organization' => $organization]) }}"
                                                    method="DELETE"
                                                    class="btn btn-danger btn-sm"
                                                >
                                                    <i class="fas fa-times"></i>
                                                    <x-slot name="content">
                                                        Are you sure you would like to activate this organization parameter?
                                                    </x-slot>
                                                </x-modals.confirmation>
                                            @endcan
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
