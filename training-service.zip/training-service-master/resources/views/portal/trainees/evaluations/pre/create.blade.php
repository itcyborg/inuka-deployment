@extends('layouts.portal')
@section('title', 'PRE-Training Evaluation Form')
@section('content')
    <main id="evaluations-create">
        <section class="row">
            <div class="col-lg-12">
                <x-forms.evaluations.pre :trainingRequest="$trainingRequest" />
            </div>
        </section>
    </main>
@endsection
