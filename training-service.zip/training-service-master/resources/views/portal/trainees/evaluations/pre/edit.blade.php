@extends('layouts.portal')
@section('title', 'PRE-Training Evaluation Form')
@section('content')
    <main id="evaluations-edit">
        <section class="row">
            <div class="col-lg-12">
                <x-forms.evaluations.pre :evaluation="$evaluation" :trainingRequest="$evaluation->workplan->trainingRequest" />
            </div>
        </section>
    </main>
@endsection