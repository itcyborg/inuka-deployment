@extends('layouts.portal')
@section('title', 'PRE-Training Evaluation Results')
@push('actions')
    @can('update', $evaluation)
        <a class="btn btn-success btn-sm" href="{{ route('portal.trainees.pre-evaluations.edit', [
              'evaluation' => $evaluation
            ]) }}">Edit Pre-Training Evaluation</a>
    @endcan
@endpush
@section('content')
    <main id="evaluations-show">
        <section class="row">
            <div class="col-lg-12">
                <section class="row">
                    <div class="col-lg-12">
                        <x-cards.content title="General Information">
                            <x-tables.evaluations.pre.general :training-request="$evaluation->workplan->trainingRequest" />
                        </x-cards.content>
                    </div>
                </section>
                <section class="row">
                    <div class="col-lg-12">
                        <x-cards.content title="Details of training service (s) provided" class="py-3 px-4">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <x-tables.evaluations.pre.details 
                                            :modules="$evaluation->workplan->modules" 
                                            :scales="config('settings.evaluations.pre.rating_options')"
                                            :evaluation="$evaluation"
                                            :show="true"
                                        />             
                                    </div>
                                    <div class="col-lg-12 mt-3">
                                        <label class="fw-bold">If you could change anything about the services provided, what would it be?</label> <br>
                                        {{ $evaluation->suggestion ?? null }}
                                    </div>
                                </div>
                            </form>
                        </x-cards.content>
                    </div>
                </section>            
            </div>
        </section>
    </main>
@endsection