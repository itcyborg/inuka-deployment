@extends('layouts.portal')
@section('title', 'POST-Training Evaluation Form')
@section('content')
    <main id="evaluations-edit">
        <section class="row">
            <div class="col-lg-12">
                <x-forms.evaluations.post :evaluation="$evaluation" :trainingRequest="$evaluation->workplan->trainingRequest" :criteria="$criteria" />
            </div>
        </section>
    </main>
@endsection
