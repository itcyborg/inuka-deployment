@extends('layouts.portal')
@section('title', 'POST-Training Evaluation Form')
@section('content')
    <main id="evaluations-create">
        <section class="row">
            <div class="col-lg-12">
                <x-forms.evaluations.post :trainingRequest="$trainingRequest" :criteria="$criteria" />
            </div>
        </section>
    </main>
@endsection
