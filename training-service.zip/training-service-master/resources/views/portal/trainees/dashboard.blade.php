@extends('layouts.portal')
@section('title', 'Dashboard')
@section('content')
    <main id="dashboard">
        <section class="row justify-content-center">
            <div class="col-lg-4">
                <x-cards.info-box title="Potential Trainings" :number="$trainingRequests['requests']->count()" icon-background="bg-green">
                    <x-slot name="icon">
                        <i class="fas fa-id-card-alt"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-4">
                <x-cards.info-box title="Trainings" :number="$trainingRequests['provisions']->count()" icon-background="bg-yellow">
                    <x-slot name="icon">
                        <i class="fas fa-calendar-check"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-4">
                <x-cards.info-box title="Topics of Interest" :number="$topics->count()" icon-background="bg-aqua">
                    <x-slot name="icon">
                        <i class="fa fa-briefcase"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
        </section>

        <section class="row justify-content-center">
            <div class="col-lg-6">
                <x-cards.content title="Overview of Potential Trainings" class="chart" :collection="$trainingRequests['charts']['requests']">
                    <x-charts.doughnuts.training-requests
                        id="requests-summary"
                        :payload="$trainingRequests['charts']['requests']"
                    />
                </x-cards.content>
            </div>
            <div class="col-lg-6">
                <x-cards.content title="Overview of Potential Trainings" class="chart" :collection="$trainingRequests['charts']['provisions']">
                    <x-charts.doughnuts.training-provisions
                        id="provisions-summary"
                        :payload="$trainingRequests['charts']['provisions']"
                    />
                </x-cards.content>
            </div>
        </section>

        <section class="row">
            <div class="col-lg-4">
                <x-cards.info-box title="Pre-Training Evaluations" :progress="$trainingRequests['preEvaluation']" number-suffix="%" background-color="bg-aqua" icon-background="bg-aqua">
                    <x-slot name="icon">
                        <i class="fas fa-hourglass-half"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-4">
                <x-cards.info-box title="Trainings" :progress="$trainingRequests['ongoing']" number-suffix="%" background-color="bg-yellow" icon-background="bg-yellow">
                    <x-slot name="icon">
                        <i class="fas fa-calendar-alt"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
            <div class="col-lg-4">
                <x-cards.info-box title="Completed Trainings" :progress="$trainingRequests['completed']" number-suffix="%" background-color="bg-green" icon-background="bg-green">
                    <x-slot name="icon">
                        <i class="fas fa-check"></i>
                    </x-slot>
                </x-cards.info-box>
            </div>
        </section>

        <section class="row">
            <div class="col-lg-12">
                <x-cards.content title="Latest Potential and Ongoing Trainings" class="dashboard-card" :collection="$trainingRequests['all']">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="index">#</th>
                                <th>@prettify(config('settings.aliases.trainee'))</th>
                                <th>@prettify(config('settings.aliases.trainer'))</th>
                                <th>Training Need</th>
                                <th>Status</th>
                                <th class="actions"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($trainingRequests['all'] as $trainingRequest)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $trainingRequest->topicTrainee->trainee->trainable->name }}</td>
                                    <td>{{ $trainingRequest->trainer->trainable->name }}</td>
                                    <td>{{ $trainingRequest->topicTrainee->topic->name }}</td>
                                    <td>@prettify($trainingRequest->status)</td>
                                    <td class="text-center">
                                        @can('view', $trainingRequest)
                                            <a class="btn btn-primary btn-sm" data-tooltip="tooltip" title="View Training Request" href="{{ route('portal.managers.training-requests.show', [
                                                'training_request' => $trainingRequest
                                            ]) }}">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </x-cards.content>
            </div>
        </section>
    </main>
@endsection
