@extends('layouts.guest')
@section('no-navbar', true)
@section('title', 'Please verify your email address')
@section('content')
    <main id="email-verification-page">
        <section class="row border page-container mx-0">
            <div class="col-lg-6 text-center">
                <img class="img-fluid logo" src="{{ asset( config('settings.logo_path') ) }}" alt="{{ config('app.name') }}">
                <h4 class="fw-light mt-4 mb-5">
                    {{ __('Hey :user, before proceeding, please check your email for a verification link.', [
                        'user' => Auth::user()->name
                    ]) }}
                </h4>
                <div class="row justify-content-center mb-1">
                    <div class="col-lg-6">
                        <div class="card shadow-lg border-0">
                            <a href="{{ route('verification.resend') }}" onclick="event.preventDefault(); document.getElementById('verification-form').submit();" class="link-dark text-decoration-none card-body text-center">
                                <h6 class="mb-0">
                                    {{ __('Click to request for another link') }}
                                </h6>
                            </a>
                            <form id="verification-form" action="{{ route('verification.resend') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="card shadow-lg border-0">
                            <a href="{{ route('home') }}" class="link-dark text-decoration-none card-body text-center">
                                <h6 class="mb-0">
                                    Click to go to the Home Page
                                </h6>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
