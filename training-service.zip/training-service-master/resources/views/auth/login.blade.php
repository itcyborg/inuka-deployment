@extends('layouts.auth')
@section('title', 'Login')
@section('auth.title', 'Login')
@section('auth.content')
    <main id="login">
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="row">
                <div class="col-lg-12 mb-3">
                    <label class="small mb-1" for="email">{{ __('Your E-Mail Address') }}</label>
                    <input class="form-control py-2 @error('email') is-invalid @enderror" name="email" id="email" type="email" placeholder="Enter your email address" value="{{ old('email') }}" required autocomplete="email" autofocus />
                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="small mb-1" for="password">{{ __('Your Password') }}</label>
                    <input class="form-control py-2 @error('password') is-invalid @enderror" name="password"  id="password" type="password" placeholder="Enter your secure password" required autocomplete="current-password"/>
                </div>
                <div class="col-lg-12 mb-3">
                    <div class="custom-control custom-checkbox">
                        <input class="custom-control-input" id="password-remember" name="remember" type="checkbox" {{ old('remember') ? 'checked' : '' }}/>
                        <label class="custom-control-label" for="password-remember">{{ __('Remember Password') }}</label>
                    </div>
                </div>
                <div class="col-lg-12 d-flex align-items-center justify-content-between mt-2 mb-0">
                    @if(Route::has('password.request'))
                        <a class="small" href="{{ route('password.request') }}">
                            {{ __('Forgot Your Password?') }}
                        </a>
                    @endif
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </div>
        </form>
    </main>
@endsection
