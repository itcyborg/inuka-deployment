<div class="row">
    @if($experiences->isNotEmpty())
        <div class="col-lg-12 mb-4">
            <table class="table no-stripes table-sm">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th class="w-50">Description</th>
                        <th>Start Year</th>
                        <th>End Year</th>
                        <th>Location</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($experiences as $index => $experience)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $experience->description }}</td>
                            <td>{{ $experience->start_year }}</td>
                            <td>{{ $experience->end_year }}</td>
                            <td>{{ $experience->location }}</td>
                            <td class="text-center">
                                <button type="button" class="btn btn-sm btn-danger" wire:click="remove({{ $update ? $experience->id : $index }})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
    <div class="col-lg-12">
        <form method="post" wire:submit.prevent="store">
            <div class="row">
                <div class="col-lg-12 mb-2">
                    <label>Description</label>
                    <textarea wire:model.lazy="experience.description" type="text" class="form-control @error('experience.description') is-invalid @enderror" placeholder="A description of what you did" required></textarea>
                    @error('experience.description')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-4 mb-2">
                    <label>Start Year</label>
                    <input wire:model.lazy="experience.start_year" type="number" min="1970" max="{{ date('Y') }}" class="form-control @error('experience.start_year') is-invalid @enderror" placeholder="The year when the engagement started" required>
                    @error('experience.start_year')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-4 mb-2">
                    <label>End Year</label>
                    <input wire:model.lazy="experience.end_year" type="number" min="1970" max="{{ date('Y') }}" class="form-control @error('experience.end_year') is-invalid @enderror" placeholder="The year when the engagement ended" required>
                    @error('experience.end_year')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-4 mb-2">
                    <label>Location</label>
                    <input wire:model.lazy="experience.location" type="text" class="form-control @error('experience.location') is-invalid @enderror" placeholder="e.g Kibera, Kenya" required>
                    @error('experience.location')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-12">
                    <button type="submit" class="btn btn-success btn-sm rounded-0">
                        Click to submit a professional experience
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>