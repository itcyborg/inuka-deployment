<div id="trainee-registration">
    <form id="trainee-registration-form" wire:submit.prevent="submit('{{ $step }}')">
    </form>
    <section id="header" class="row justify-content-center">
        @if(!$update)
            <div class="col-lg-12 mt-1 mb-4 d-flex align-items-center">
                <div class="d-flex me-auto mb-1 brand">
                    <img class="img-fluid me-3 logo" src="{{ asset( config('settings.logo_path') ) }}" alt="">
                    <div class="title-section">
                        <h3 class="mb-1">{{ $steps[$step]['title'] }}</h3>
                        <h6 class="text-muted">{{ $steps[$step]['description'] }}</h6>
                    </div>
                </div>
                <div class="ms-auto navigation">
                    <ul class="list-inline">
                        <li class="list-inline-item">
                            <a href="{{ route('home') }}">
                                <i class="fas fa-home"></i> Home
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="{{ route('login') }}">
                                <i class="fas fa-sign-in-alt"></i> Login
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        @endif
        <div class="col-lg-10 text-center">
            <ul id="progress-bar">
                @foreach($steps as $currStep => $details)
                    <li class="{{ $this->getStepAccessibility($currStep) ? 'completed' : null }} {{ $currStep == $step ? 'active' : null }}" wire:click="navigateTo('{{ $currStep }}')">
                        @if($this->getStepAccessibility($currStep) && $currStep != $step && !$this->update)
                            <i class="fas fa-check"></i>
                        @else
                            <i class="{{ $details['icon'] }}"></i>
                        @endif
                        <strong>{{ $details['title'] }}</strong>
                    </li>
                @endforeach
            </ul>
        </div>
        @if(!$update)
            <div class="col-lg-12">
                <div class="progress mb-1">
                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" role="progressbar" style="width: {{ $steps[$step]['progress'] }}%" aria-valuenow="{{ $steps[$step]['progress'] }}" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        @endif
    </section>
    <section id="body" class="row">
        <div class="col-lg-12">
            @if(session()->has('success'))
                <div wire:loading.remove wire:target="submit, navigateTo" class="alert alert-success mb-1" role="alert">
                    {{ session('success') }}
                </div>
            @endif
            <div class="card content-card p-4 mb-1 border border-top-aqua">
                <div class="card-body">
                    <div wire:loading.flex wire:target="submit, navigateTo" class="loader justify-content-center align-items-center" style="height: 50vh;">
                        <img src="{{ asset('img/loaders/app-2.svg') }}" alt="Loading..">
                    </div>
                    <div wire:loading.remove wire:target="submit, navigateTo">
                        @if($step === 'general')
                            <x-forms.registration.trainees.general
                                :genders="$genders"
                                :counties="$counties"
                                :organizations="$organizations"
                                :roles="$roles"
                            />
                        @elseif($step === 'confirm')
                            <x-forms.registration.trainees.confirm
                                :user="$user"
                                :trainee="$trainee"
                            />
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="footer" class="row mt-1">
        <div class="col-lg-12 d-flex">
            <div wire:loading.remove wire:target="submit, navigateTo" class="mx-auto">
                @if($step != 'general' && !$update)
                    <button type="button" class="btn btn-primary rounded-0" wire:click="previous">
                        Previous
                    </button>
                @endif
                <button form="trainee-registration-form" type="submit" class="btn btn-primary rounded-0">
                    @if($step == 'confirm')
                        Submit
                    @elseif($update)
                        Update your {{ $steps[$step]['title'] }}
                    @else
                        Save and Continue
                    @endif
                </button>
            </div>
        </div>
    </section>
</div>
