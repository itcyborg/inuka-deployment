<div class="row">
    @if($qualifications->isNotEmpty())
        <div class="col-lg-12 mb-4">
            <table class="table no-stripes table-sm">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Certification</th>
                        <th>Institution</th>
                        <th>Location</th>
                        <th>Year</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($qualifications as $index => $qualification)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $qualification->certification }}</td>
                            <td>{{ $qualification->institution }}</td>
                            <td>{{ $qualification->location }}</td>
                            <td>{{ $qualification->year }}</td>
                            <td class="text-center">
                                <button type="button" class="btn btn-sm btn-danger" wire:click="remove({{ $update ? $qualification->id : $index }})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
    <div class="col-lg-12">
        <form id="qualifications-form" method="post" wire:submit.prevent="store">
            <div class="row">
                <div class="col-lg-6 mb-2">
                    <label>Certification</label>
                    <input wire:model.lazy="qualification.certification" type="text" class="form-control @error('qualification.certification') is-invalid @enderror" placeholder="e.g Masters Degree in Economics" required>
                    @error('qualification.certification')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-6 mb-2">
                    <label>Institution</label>
                    <input wire:model.lazy="qualification.institution" type="text" class="form-control @error('qualification.institution') is-invalid @enderror" placeholder="e.g Mashujaa University" required>
                    @error('qualification.institution')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-6 mb-2">
                    <label>Year</label>
                    <input wire:model.lazy="qualification.year" type="number" min="1970" max="{{ date('Y') }}" class="form-control @error('qualification.year') is-invalid @enderror" placeholder="The graduation year" required>
                    @error('qualification.year')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-6 mb-2">
                    <label>Location</label>
                    <input wire:model.lazy="qualification.location" type="text" class="form-control @error('qualification.location') is-invalid @enderror" placeholder="e.g Kibera, Kenya" required>
                    @error('qualification.location')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="col-lg-12">
                    <button form="qualifications-form" type="submit" class="btn btn-success btn-sm rounded-0">
                        Click to submit a qualification
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>