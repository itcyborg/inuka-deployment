@extends('layouts.guest')
@section('no-navbar', true)
@section('title', 'Home')
@section('content')
    <main id="home-page">
        <section class="row border page-container mx-0">
            <div class="col-lg-6 text-center">
                <img class="img-fluid logo" src="{{ asset( config('settings.logo_path') ) }}" alt="{{ config('app.name') }}">
                <h4 class="fw-light mt-4 mb-5">
                    Hello @auth {{ Auth::user()->name }} @endauth, {{ __('Welcome to :app', ['app' => config('app.name')]) }}. <br>
                    This is a temporary landing page. @lang('What would you like to do?')
                </h4>
                <div class="row justify-content-center mb-1">
                    <div class="col-lg-6">
                        <div class="card shadow-lg border-0">
                            @auth
                                @can('view_manager_portal')
                                    <a class="link-dark text-decoration-none card-body text-center" href="{{ route('portal.managers.dashboard') }}">
                                        <h6 class="mb-0">
                                            View the TSP Portal
                                        </h6>
                                    </a>
                                @endcan
                                @can('view_trainer_portal')
                                    <a class="link-dark text-decoration-none card-body text-center" href="{{ route('portal.trainers.dashboard') }}">
                                        <h6 class="mb-0">
                                            View the @prettify(config('settings.aliases.trainer')) Portal
                                        </h6>
                                    </a>
                                @endcan
                                @can('view_trainee_portal')
                                    <a class="link-dark text-decoration-none card-body text-center" href="{{ route('portal.trainees.dashboard') }}">
                                        <h6 class="mb-0">
                                            View the @prettify(config('settings.aliases.trainee')) Portal
                                        </h6>
                                    </a>
                                @endcan
                            @else
                                <a class="link-dark text-decoration-none card-body text-center" href="{{ route('login') }}">
                                    <h6 class="mb-0">
                                        Login into the Application
                                    </h6>
                                </a>
                            @endauth
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center mb-1">
                    <div class="col-lg-6">
                        <div class="card shadow-lg border-0">
                            @auth
                                <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="link-dark text-decoration-none card-body text-center">
                                    <h6 class="mb-0">
                                        {{ __('Logout of the application') }}
                                    </h6>
                                </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            @else
                                <a class="link-dark text-decoration-none card-body text-center" href="{{ route('trainers.create') }}">
                                    <h6 class="mb-0">
                                        Register as a trainer
                                    </h6>
                                </a>
                            @endauth
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
