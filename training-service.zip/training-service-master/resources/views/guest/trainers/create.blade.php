@extends('layouts.guest')
@section('title', 'Register as a trainer')
@section('no-navbar', true)
@prepend('css')
    <livewire:styles />
@endprepend
@section('content')
    <main id="trainer-registration" class="container-fluid px-0">
        <section class="row wizard-container mx-0">
            <div class="col-lg content-section">
                <div class="row justify-content-center">
                    <div class="col-lg-10 pt-4 pb-5 px-5 ">
                        <livewire:forms.trainer-registration />  
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
@prepend('js')
    <livewire:scripts />
@endprepend