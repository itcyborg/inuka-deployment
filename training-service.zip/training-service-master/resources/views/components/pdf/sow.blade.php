<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>STATEMENT OF WORK DOCUMENT</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <style>
            body{
                font-size: 0.8em;
            }
        </style>
    </head>
    <body>
        <table class="table">
            <tbody>
                <tr>
                    <th class="w-25">Sow Number</th>
                    <td>{{ $sow_no }}</td>
                </tr>
                <tr>
                    <th class="w-25">Contract Reference Number</th>
                    <td>{{ $contract_no }}</td>
                </tr>
                <tr>
                    <th class="w-25">@prettify(config('settings.aliases.trainer')) Name</th>
                    <td>{{ $trainer_name }}</td>
                </tr>
                <tr>
                    <th class="w-25">@prettify(config('settings.aliases.trainee')) Name</th>
                    <td>{{ $trainee_name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Course Title</th>
                    <td>
                        {{ $course_name }} within {{ $area_name }} under {{ $service_name }}.
                    </td>
                </tr>
                <tr>
                    <th class="w-25">Period of Perfomance</th>
                    <td>
                        @date($commencement_date) to @date($termination_date)
                    </td>
                </tr>
                <tr>
                    <th class="w-25">Scope of Work</th>
                    <td>

                        Under this Statement of Work, the trainee, <strong>{{ $trainee_name }}</strong>, will be provided training in the <strong>{{ $area_name }}</strong> category. In particular, the @prettify(config('settings.aliases.trainer')) will cover the course <strong>{{ $course_name }}</strong> and will focus on <strong>{{ $service_name }}</strong>. The training is structured into <strong>{{ $module_count }}</strong> modules.
                    </td>
                </tr>
                <tr>
                    <th class="w-25">The Modules</th>
                    <td class="p-0">
                        <table class="table no-borders no-stripes">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Module Name</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Duration</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($modules as $module)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $module->name }}</td>
                                        <td>@datetime($module->start_date)</td>
                                        <td>@datetime($module->end_date)</td>
                                        <td>{{ $module->duration }} Hours</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <th class="w-25">Deliverables</th>
                    <td>
                        {{ $deliverables }}
                    </td>
                </tr>
                <tr>
                    <th class="w-25">Trainer's Fee</th>
                    <td>
                        @currency($fee)
                    </td>
                </tr>
                <tr>
                    <th class="w-25">Fee Arrangement</th>
                    <td>
                        {{ $fee_arrangement }}
                    </td>
                </tr>
                <tr>
                    <th class="w-25">TSP Approval Signature</th>
                    <td class="p-0">
                        <table class="table no-stripes no-borders">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Date of Signature</th>
                                    <th class="text-center w-25">Signature</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>{{ $manager_name }}</th>
                                    <th>@datetime($manager_signature_date)</th>
                                    <th class="w-25 text-center">
                                        <img src="{{ public_path('img/sows/wapi-manager-verified-stamp.png') }}" class="img-fluid signature">
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <th class="w-25">@prettify(config('settings.aliases.trainer')) Acknowledgement Signature</th>
                    <td class="p-0">
                        <table class="table no-stripes no-borders">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Date of Signature</th>
                                    <th class="w-25 text-center">Signature</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>{{ $trainer_name }}</th>
                                    <th>@datetime($trainer_signature_date)</th>
                                    <th class="w-25 text-center">
                                        <img src="{{ public_path('img/sows/wapi-trainer-verified-stamp.png') }}" class="img-fluid signature">
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>
