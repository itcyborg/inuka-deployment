@once
    @push('status-alerts')
        <x-status-alert prephrase="Training {{ $trainingRequest->type() }} status" :status="$trainingRequest->status" />
    @endpush
@endonce
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <a class="nav-link active" id="workplan-tab" data-bs-toggle="tab" href="#workplan" role="tab" aria-controls="workplan" aria-selected="false">Workplan Schedule</a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link" id="general-tab" data-bs-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">Training @prettify($trainingRequest->type()) Information</a>
    </li>
    @can('viewAny', [\App\Models\Evaluation::class, $trainingRequest, 'PRE'])
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="evaluation-tab" data-bs-toggle="tab" href="#pre-evaluation" role="tab" aria-controls="pre-evaluation" aria-selected="false">Pre-Training Evaluation Results</a>
        </li>
    @endcan
    @can('viewAny', [\App\Models\Evaluation::class, $trainingRequest, 'POST'])
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="evaluation-tab" data-bs-toggle="tab" href="#post-evaluation" role="tab" aria-controls="post-evaluation" aria-selected="false">Post-Training Evaluation Results</a>
        </li>
    @endcan
    @can('viewAny', [ \App\Models\Rating::class, $trainingRequest, 'trainers' ])
      <li class="nav-item" role="presentation">
          <a class="nav-link" id="trainer-rating-tab" data-bs-toggle="tab" href="#trainer-ratings" role="tab" aria-controls="trainer-ratings" aria-selected="false">Trainee Ratings By Trainer</a>
      </li>
    @endcan
    @can('viewAny', [ \App\Models\Rating::class, $trainingRequest, 'trainees' ])
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="trainee-rating-tab" data-bs-toggle="tab" href="#trainee-ratings" role="tab" aria-controls="trainee-ratings" aria-selected="false">Trainer Ratings By Trainees</a>
      </li>
    @endcan
</ul>
<div class="tab-content">
    <div class="tab-pane fade show active" id="workplan" role="tabpanel" aria-labelledby="workplan-tab">
        @can('create', [ \App\Models\WorkplanModule::class, $trainingRequest ])
            <div class="d-flex py-1 pe-1">
                <x-modals.forms.workplan-modules
                    id="workplan-modules-modal"
                    class="btn btn-primary btn-sm ms-auto"
                    :workplan="$trainingRequest->workplan"
                >
                    <x-slot name="buttonText">
                        Create a New Module
                    </x-slot>
                </x-modals.forms.workplan-modules>
            </div>
        @endcan
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Module Name</th>
                    @if($trainingRequest->isARequest())
                        <th>Module Description</th>
                    @endif
                    <th>Start Date</th>
                    <th>End Date</th>
                    @if($trainingRequest->isAProvision())
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th class="text-center">Status</th>
                    @endif
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($trainingRequest->workplan->modules as $module)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $module->name }}</td>
                        @if($trainingRequest->isARequest())
                            <td>{{ Str::limit($module->description, 20) }}</td>
                        @endif
                        <td>{{ format_date_time($module->start_date) ?? 'N/A' }}</td>
                        <td>{{ format_date_time($module->end_date) ?? 'N/A' }}</td>
                        @if($trainingRequest->isAProvision())
                            <td>{{ format_date_time($module->actual_start_date) ?? 'N/A' }}</td>
                            <td>{{ format_date_time($module->actual_end_date) ?? 'N/A' }}</td>
                            <td class="text-center">@prettify($module->status)</td>
                        @endif
                        <td class="text-center">
                            @can('start', $module)
                                <x-modals.confirmation
                                    id="workplan-start-modal-{{ $module->id }}"
                                    title="Start Module"
                                    confirmation-title="Module Commencement Confirmation"
                                    action="{{ route('portal.trainers.workplan-modules.start', [
                                        'workplan_module' => $module
                                    ]) }}"
                                    method="POST"
                                    class="btn btn-primary btn-sm"
                                >
                                    <i class="fas fa-hourglass-start"></i>
                                    <x-slot name="content">
                                        Are you sure you would like to start this module?
                                    </x-slot>
                                </x-modals.confirmation>
                            @endcan
                            @can('end', $module)
                                <x-modals.confirmation
                                    id="workplan-end-modal-{{ $module->id }}"
                                    title="End Module"
                                    confirmation-title="Module Termination Confirmation"
                                    action="{{ route('portal.trainers.workplan-modules.end', [
                                        'workplan_module' => $module
                                    ]) }}"
                                    method="POST"
                                    class="btn btn-success btn-sm"
                                >
                                    <i class="fas fa-check"></i>
                                    <x-slot name="content">
                                        Are you sure you would like to end this module?
                                    </x-slot>
                                </x-modals.confirmation>
                            @endcan
                            @can('view', $module)
                                <x-modals.tables.modules
                                    id="module-modal-{{$module->id}}"
                                    class="btn btn-success btn-sm"
                                    :module="$module"
                                >
                                    <x-slot name="buttonText">
                                        <i class="fas fa-eye"></i>
                                    </x-slot>
                                </x-modals.tables.training-materials>
                            @endcan
                            @can('update', $module)
                                <x-modals.forms.workplan-modules
                                    id="workplan-modules-modal-{{$module->id}}"
                                    class="btn btn-primary btn-sm"
                                    :module="$module"
                                >
                                    <x-slot name="buttonText">
                                        <i class="fas fa-edit"></i>
                                    </x-slot>
                                </x-modals.forms.workplan-modules>
                            @endcan
                            @can('delete', $module)
                                <x-modals.confirmation
                                    id="module-deletion-modal-{{ $module->id }}"
                                    title="Delete Module"
                                    confirmation-title="Module Deletion Confirmation"
                                    action="{{ route('portal.managers.workplan-modules.destroy', ['workplan_module' => $module]) }}"
                                    method="DELETE"
                                    class="btn btn-danger btn-sm"
                                >
                                    <i class="fas fa-times"></i>
                                    <x-slot name="content">
                                        Are you sure you would like to delete this module?
                                    </x-slot>
                                </x-modals.confirmation>
                            @endcan
                            @can('viewAnyTrainingMaterials', $module)
                                <x-modals.tables.training-materials
                                    id="training-materials-modal-{{$module->id}}"
                                    class="btn btn-success btn-sm"
                                    :training-materials="$module->trainingMaterials()"
                                >
                                    <x-slot name="buttonText">
                                        <i class="fas fa-file-signature"></i>
                                    </x-slot>
                                </x-modals.tables.training-materials>
                            @endcan
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="tab-pane fade" id="general" role="tabpanel" aria-labelledby="general-tab">
        <table class="table">
            <tbody>
              @can('rejected', $trainingRequest)
                <tr>
                    <th class="w-25">Rejection Reason</th>
                    <td class="text-danger">{{ $trainingRequest->comment->comment }}</td>
                </tr>
              @endcan
                <tr>
                    <th class="w-25">Service</th>
                    <td>{{ $trainingRequest->topicTrainee->topic->area->service->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Area</th>
                    <td>{{ $trainingRequest->topicTrainee->topic->area->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Topic</th>
                    <td>{{ $trainingRequest->topicTrainee->topic->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">@prettify(config('settings.aliases.trainer'))</th>
                    <td>{{ $trainingRequest->trainer->trainable->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">@prettify(config('settings.aliases.trainee'))</th>
                    <td>{{ $trainingRequest->topicTrainee->trainee->trainable->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Designated Manager</th>
                    <td>{{ $trainingRequest->manager->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Date Created</th>
                    <td>@datetime($trainingRequest->created_at)</td>
                </tr>
                <tr>
                    <th class="w-25">Start Date</th>
                    <td>@datetime($trainingRequest->start_date)</td>
                </tr>
                <tr>
                    <th class="w-25">End Date</th>
                    <td>@datetime($trainingRequest->end_date)</td>
                </tr>
            </tbody>
        </table>
    </div>
    @can('viewAny', [\App\Models\Evaluation::class, $trainingRequest, 'PRE'])
        <div class="tab-pane fade" id="pre-evaluation" role="tabpanel" aria-labelledby="pre-evaluation-tab">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Evaluator</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($preEvaluations as $evaluation )
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $evaluation->user->name }}</td>
                            <td>{{ Str::limit($evaluation->user->email, 20) }}</td>
                            <td>{{ $evaluation->user->telephone }}</td>
                            <td class="text-center">@prettify($evaluation->user->status)</td>
                            <td class="text-center">
                                @can('view', $evaluation)
                                    <x-modals.forms.evaluations.pre
                                        id="evaluations-modal-{{ $evaluation->id }}"
                                        class="btn btn-primary btn-sm"
                                        :evaluation="$evaluation"
                                    >
                                        <x-slot name="buttonText">
                                            <i class="fas fa-eye"></i>
                                        </x-slot>
                                    </x-modals.forms.evaluations.pre>
                                @endcan
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endcan
    @can('viewAny', [\App\Models\Evaluation::class, $trainingRequest, 'POST'])
        <div class="tab-pane fade" id="post-evaluation" role="tabpanel" aria-labelledby="post-evaluation-tab">
            <table class="table">
              <thead>
                  <tr>
                      <th>#</th>
                      <th>Evaluator</th>
                      <th>Email</th>
                      <th>Phone Number</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">Actions</th>
                  </tr>
              </thead>
              <tbody>
                  @foreach($postEvaluations as $evaluation )
                      <tr>
                          <td>{{ $loop->iteration }}</td>
                          <td>{{ $evaluation->user->name }}</td>
                          <td>{{ Str::limit($evaluation->user->email, 20) }}</td>
                          <td>{{ $evaluation->user->telephone }}</td>
                          <td class="text-center">@prettify($evaluation->user->status)</td>
                          <td class="text-center">
                              @can('view', $evaluation)
                                <x-modals.forms.evaluations.post
                                    id="evaluations-modal-{{ $evaluation->id }}"
                                    class="btn btn-primary btn-sm"
                                    :evaluation="$evaluation"
                                    :postEvaluationCriteria="$postEvaluationCriteria"
                                >
                                    <x-slot name="buttonText">
                                        <i class="fas fa-eye"></i>
                                    </x-slot>
                                </x-modals.forms.evaluations.post>
                              @endcan
                          </td>
                      </tr>
                  @endforeach
              </tbody>
            </table>
        </div>
    @endcan
    @can('viewAny', [ \App\Models\Rating::class, $trainingRequest, 'trainers' ])
      <div class="tab-pane fade" id="trainer-ratings" role="tabpanel" aria-labelledby="trainer-ratings-tab">
          <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Rater</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                    <tr>
                        <td>#</td>
                        <td>{{ $trainingRequest->trainer->trainable->name }}</td>
                        <td class="text-center">
                          <x-modals.tables.ratings
                              id="rating-show-modal"
                              class="btn btn-primary btn-sm ms-auto"
                              :ratings="$trainerRatings"
                              object="trainer"
                          />
                        </td>
                    </tr>
            </tbody>
          </table>
      </div>
    @endcan
    @can('viewAny', [ \App\Models\Rating::class, $trainingRequest, 'trainees' ])
      <div class="tab-pane fade" id="trainee-ratings" role="tabpanel" aria-labelledby="trainee-ratings-tab">
          <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Rater</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($traineeRatings as $key => $value )
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $key }}</td>
                        <td class="text-center">
                          <x-modals.tables.ratings
                              id="rating-show-modal-{{ $loop->iteration }}"
                              class="btn btn-primary btn-sm ms-auto"
                              :ratings="$value"
                              object="trainee"
                          />
                        </td>
                    </tr>
                @endforeach
            </tbody>
          </table>
      </div>
    @endcan
</div>

