<div class="stat-box {{ $backgroundColor ?? 'bg-white' }}">
    <div class="inner">
        <h3>{{ $number ?? 0 }}</h3>
        <p>{{ $text }}</p>
    </div>
    @isset($icon)
        <div class="stat-box-icon">
            {{ $icon }}
        </div>
    @endisset
    <a href="{{ $footerUrl }}" class="stat-box-footer">{{ $footerText }} <i class="fas fa-arrow-circle-right"></i></a>
</div>