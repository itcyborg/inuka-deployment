<div class="info-box {{ $backgroundColor ?? 'bg-white' }}">
    <span class="info-box-icon {{ $iconBackground }}">
        @isset($icon)
            {{ $icon }}
        @endisset
    </span>
    <div class="info-box-content">
        <span class="info-box-text">{{ $title ?? null }}</span>
        <span class="info-box-number">{{ $number ?? ($progress ?? 0) }} <small>{{ $numberSuffix ?? null }}</small></span>
        @isset($progress)
            <div class="progress">
                <div class="progress-bar" style="width: {{ $progress }}%"></div>
            </div>
        @endisset
    </div>
</div>