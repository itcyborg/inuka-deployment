@props(['title', 'collection', 'borderType'])

<div class="card content-card border-top-{{ $borderType ?? 'aqua' }}">
    @isset($title)
        <div class="card-header">
            <p>{{ $title }}</p>
        </div>
    @endisset
    <div {{ $attributes->merge(['class' => 'card-body']) }}>
        @if(!isset($collection) || (isset($collection) && count($collection)))
            {!! $slot !!}
        @else
            <div class="empty-collection">
                <h5>Sorry, no records are available</h5>
            </div>
        @endif
    </div>
</div>