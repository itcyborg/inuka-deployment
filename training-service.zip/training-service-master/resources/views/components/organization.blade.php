{{-- @once
    @push('status-alerts')
        <x-status-alert prephrase="Training {{ $trainingRequest->type() }} status" :status="$trainingRequest->status" />
    @endpush
@endonce --}}
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <a class="nav-link active" id="organization-tab" data-bs-toggle="tab" href="#organization" role="tab" aria-controls="organization" aria-selected="false">Organization Details</a>
    </li>
</ul>
<div class="tab-content">
    <div class="tab-pane fade show active" id="organization" role="tabpanel" aria-labelledby="organization-tab">
        <table class="table">
            <tbody>
                <tr>
                    <th class="w-25">Public ID</th>
                    <td>{{ $organization->public_id }}</td>
                </tr>
                <tr>
                    <th class="w-25">County</th>
                    <td>{{ $organization->county->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Name</th>
                    <td>{{ $organization->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Email Address</th>
                    <td>{{ $organization->email }}</td>
                </tr>
                <tr>
                    <th class="w-25">Phone Number</th>
                    <td>{{ $organization->telephone }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

