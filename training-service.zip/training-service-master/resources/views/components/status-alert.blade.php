<div class="alert alert-primary text-uppercase fw-bold my-1" role="alert">
    {{ $prephrase ?? null }} : @prettify($status)
</div>