<div>
    @if($fullstars >0 || $halfstar )
        <div class="text-warning">
            @for($i = 0; $i < $fullstars; $i++)
                <i class="fas fa-star" aria-hidden="true"></i>
            @endfor
            @if($halfstar)
                <i class="fas fa-star-half-alt" aria-hidden="true"></i>
            @endif
        </div>
    @else
        Unavailable
    @endif
</div>
