<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal"
    data-bs-target="#{{ $attributes->get('id') }}" required>
    {{ $buttonText  }}
</button>

<!-- Modal -->
<div class="modal fade" id="{{ $attributes->get('id') }}" tabindex="-1"
    aria-labelledby="{{ $attributes->get('id') }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="{{ $attributes->get('id') }}-label">
                    {{ $title }}
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-start p-0">
                <table class="table no-stripes">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Uploaded At</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($trainingMaterials as $material)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $material->name }}</td>
                                <td>@datetime($material->created_at)</td>
                                <td class="text-center">
                                    @can('download', $material)
                                        <a title="Download this training material" data-tooltip="tooltip" class="btn btn-success btn-sm" href="{{ route($downloadRouteName(), [
                                            'upload' => $material
                                        ]) }}">
                                            <i class="fas fa-file-download"></i>
                                        </a>
                                    @endcan     
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>	        
        </div>
    </div>
</div>