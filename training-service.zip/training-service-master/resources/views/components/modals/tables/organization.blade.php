@props(['buttonText', 'title', 'organization', 'object'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal"
    data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? 'View '.prettify($object) }}
</button>

<!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{ $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="{{ $id }}-label">
                    View Organization
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-start p-0">
                <table class="table">
                    <tbody>
                        <tr>
                            <th class="w-25">Public ID</th>
                            <td>{{ $organization->public_id }}</td>
                        </tr>
                        <tr>
                            <th class="w-25">County</th>
                            <td>{{ $organization->county->name }}</td>
                        </tr>
                        <tr>
                            <th class="w-25">Name</th>
                            <td>{{ $organization->name }}</td>
                        </tr>
                        <tr>
                            <th class="w-25">Email Address</th>
                            <td>{{ $organization->email }}</td>
                        </tr>
                        <tr>
                            <th class="w-25">Phone Number</th>
                            <td>{{ $organization->telephone }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
