@props(['buttonText', 'title', 'ratings', 'object'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal"
    data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? 'View '.prettify($object).' Ratings' }}
</button>

<!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{ $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="{{ $id }}-label">
                    View Ratings
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-start p-0">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Criteria</th>
                            <th>Value</th>
                            <th class="w-25">Description</th>
                        </tr>
                    </thead>
                    <thead>
                        @foreach ($ratings as $rating)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $rating->rateable->name }}</td>
                                <td>{{ $rating->rating_percentage }}% ({{ $rating->value }}/ {{ $rating->max_value }})</td>
                                <td>{{ $rating->description }}</td>
                            </tr>
                        @endforeach
                    </thead>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
