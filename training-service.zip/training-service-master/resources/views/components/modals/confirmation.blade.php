@props(['method', 'confirmationTitle'])
@php $method = strtolower($method) @endphp

<button {{ $attributes->except(['id', 'action']) }} 
    data-bs-toggle="modal" 
    data-bs-target="#{{ $attributes->get('id') }}" 
    title="{{ $attributes->get('title') }}"
    data-tooltip="tooltip"
>
    {{ $slot }}
</button>
<div class="modal fade" id="{{ $attributes->get('id') }}" tabindex="-1" aria-labelledby="{{ $attributes->get('id') }}-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="project-modal-label">{{ $confirmationTitle }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-start">
                {{ $content ?? 'Are you sure you would like to proceed?' }}        
            </div>
            <div class="modal-footer">
                @isset($actionTrigger)
                    {{ $actionTrigger }}
                @else
                    @if($method == 'get')
                        <a href="{{ route($attributes->get('action')) }}" class="btn btn-danger btn-sm" form="{{ $attributes->get('id') }}-form">Proceed</a>
                    @else
                        <form id="{{ $attributes->get('id') }}-form" action="{{ $attributes->get('action') }}" method="post">
                            @csrf
                            @if(in_array($method, ['put', 'delete', 'patch']))
                                @method($method)
                            @endif
                        </form>
                        <button type="submit" class="btn btn-danger btn-sm" form="{{ $attributes->get('id') }}-form">Proceed</button>
                    @endif
                @endisset
                <button type="button" class="btn btn-success btn-sm" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>