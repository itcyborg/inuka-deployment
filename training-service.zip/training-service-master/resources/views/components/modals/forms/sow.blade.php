@props(['buttonText', 'title', 'sow', 'trainingRequest'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{  $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? ( isset($sow) ? "Update the SOW" : 'Generate an SOW' ) }}
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{  $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      	<div class="modal-content">
		  <form id="sow-form-{{ $id }}" action="{{ isset($sow) ? route('portal.managers.sows.update', ['sow' => $sow ]) : route('portal.managers.sows.store', ['training_request' => $trainingRequest ?? null]) }}" method="POST">
				@csrf
				@bag($id)
				@isset($sow)
					@method('PATCH')
				@endisset
				<div class="modal-header">
					<h5 class="modal-title" id="{{  $id }}-label">
						{{ $title ?? ( isset($sow) ? "Update the SOW" : 'Generate a new SOW' ) }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
						<div class="col-lg-6 mb-3">
							<label for="">Contract Reference Number</label>
							<input name="contract_no" type="text" class="form-control @error('contract_no', $id) is-invalid @enderror" placeholder="e.g XO3823232323" value="{{ old('contract_no') ?? ( $sow->contract_no ?? ( app()->environment('local') ? 'XO3823232323' : '' ) ) }}" required>
							@error('contract_no', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-6 mb-3">
							<label for="">SOW Number</label>
							<input name="sow_no" type="text" class="form-control @error('sow_no', $id) is-invalid @enderror" placeholder="e.g 23434334" value="{{ old('sow_no') ?? ( $sow->sow_no ?? ( app()->environment('local') ? '23434334' : '' ) ) }}" required>
							@error('sow_no', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
						<div class="col-lg-4 mb-3">
							<label for="">SOW Date</label>
							<input name="sow_date" type="date" class="form-control @error('sow_date', $id) is-invalid @enderror" placeholder="e.g 72" value="{{ old('sow_date') ?? ( (isset($sow->sow_date) ? $sow->sow_date->format('Y-m-d') : null) ?? ( app()->environment('local') ? '2021-01-01' : '' ) ) }}" required>
							@error('sow_date', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-4 mb-3">
							<label for="">Commencement Date</label>
							<input name="commencement_date" type="date" class="form-control @error('commencement_date', $id) is-invalid @enderror" placeholder="e.g 2021-01-05" value="{{ old('commencement_date') ?? ( (isset($sow->commencement_date) ? $sow->commencement_date->format('Y-m-d') : null) ?? ( app()->environment('local') ? '2021-01-05' : '' ) ) }}" required>
							@error('commencement_date', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-4 mb-3">
							<label for="">Termination Date</label>
							<input name="termination_date" type="date" class="form-control @error('termination_date', $id) is-invalid @enderror" placeholder="e.g 2021-01-10" value="{{ old('termination_date') ?? ( (isset($sow->termination_date) ? $sow->termination_date->format('Y-m-d') : null) ?? ( app()->environment('local') ? '2021-01-10' : '' ) ) }}" required>
							@error('termination_date', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
                        <div class="col-lg-12 mb-3">
							<label for="">Fee in KES</label>
							<input name="fee" type="number" class="form-control @error('fee', $id) is-invalid @enderror" placeholder="e.g 1000000" value="{{ old('fee') ?? ( $sow->fee ?? ( app()->environment('local') ? '1000000' : '' ) ) }}" required>
							@error('fee', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label for="">Fee Arrangement</label>
                            <textarea name="fee_arrangement" class="form-control @error('fee_arrangement', $id) is-invalid @enderror" cols="30" rows="10" placeholder="e.g Every 1st of the month" required>{{ old('fee_arrangement') ?? ( $sow->fee_arrangement ?? ( app()->environment('local') ? 'Every 1st of the month' : '' ) ) }}</textarea>
							@error('fee_arrangement', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-6 mb-3">
							<label for="">Effort Level</label>
							<input name="effort_level" type="number" class="form-control @error('effort_level', $id) is-invalid @enderror" placeholder="e.g 10" value="{{ old('effort_level') ?? ( $sow->effort_level ?? ( app()->environment('local') ? '10' : '' ) ) }}" required>
							@error('effort_level', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-6 mb-3">
							<label for="">Effort Level Unit</label>
							<select name="effort_level_unit" class="form-control @error('effort_level_unit', $id) is-invalid @enderror" required>
								@foreach($effortLevelUnits as $unit)
									<option value="{{ $unit }}" {{ (old('effort_level_unit') ?? ( $sow->effort_level_unit ?? ( app()->environment('local') ? 'hours' : '' ))) == $unit }}>@prettify($unit)</option>
								@endforeach
							</select>
							@error('effort_level_unit', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label for="">Deliverables</label>
                            <textarea name="deliverables" class="form-control @error('deliverables', $id) is-invalid @enderror" cols="30" rows="10" placeholder="e.g The {{ prettify(config('settings.aliases.trainer')) }} will be required to provide the following: Progress reports" required>{{ old('deliverables') ?? ( $sow->deliverables ?? ( app()->environment('local') ? 'The '.prettify(config('settings.aliases.trainer')) .' will be required to provide the following: Progress reports' : '' ) ) }}</textarea>
							@error('deliverables', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					<button form="sow-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Submit' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif
