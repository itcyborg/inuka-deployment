 <i class="fas fa-creative-commons-zero    "></i>@props(['buttonText', 'title', 'ratings', 'trainingRequest', 'criteria', 'object'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal"
    data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? (isset($ratings) ? 'Update '.prettify($object).' Ratings' : 'Rate the '.prettify($object)) }}
</button>

<!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1"
    aria-labelledby="{{ $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="ratings-form-{{ $id }}" action="{{ $attributes->get('action') }}" method="POST">
                @csrf
                @bag($id)
                @isset($ratings)
                    @method('PUT')
                @endisset
                <div class="modal-header">
                    <h5 class="modal-title" id="{{ $id }}-label">
                        {{ $title ?? (isset($ratings) ? 'Update the rating' : 'Rate the '. $object) }}
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-start">
                    @foreach ($criteria as $criterion)
                        <div class="row mb-5">
                            <div class="col-lg-12 @error('ratings.'.$criterion['id'].'.value', $id) is-invalid @enderror range-container">
                                <label>Give your rating for: {{ $criterion['name'] }}</label>
                                <input type="range" class="form-range rating-input" min="0" max="10" id="{{ $criterion['id'] }}" name="ratings[{{ $criterion['id'] }}][value]" value="{{ old('ratings.'.$criterion['id'].'.value') ?? ($ratings[ $criterion->id ]['value'] ?? 0) }}" required onchange="updateCount(this)">
                                <div class="slider-count fw-bold text-center mb-4">
                                    <span class="badge bg-primary">0</span>
                                </div>
                                @error('ratings.'.$criterion['id'].'.value', $id)
                                    <div class="text-danger">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            <div class="col-lg-12">
                                <label for="reason" class="label">
                                    Enter a reason for the rating.
                                </label>
                                <textarea cols="600" rows="3" class="form-control @error('ratings.'.$criterion['id'].'.description', $id) is-invalid @enderror" id="{{ $criterion['id'] }}" name="ratings[{{ $criterion['id'] }}][description]" placeholder="Enter Description Here" required>{{ $ratings[ $criterion->id ]['description'] ?? null }}</textarea>
                                @error('ratings.'.$criterion['id'].'.description', $id)
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button form="ratings-form-{{ $id }}" type="submit" class="btn btn-success">
                        {{ $submitText ?? 'Submit' }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@if ($errors->hasBag($id))
    @push('js')
        <script>
            var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
            modal.show();
        </script>
    @endpush
@endif
