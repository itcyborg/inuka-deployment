@props(['buttonText', 'title', 'user', 'counties'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? ( isset($user) ? 'Update Profile Details' : 'Create a Profile Details' ) }}
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{  $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      	<div class="modal-content">
            <form id="values-form-{{ $id }}" action="{{ route('portal.managers.user-profiles.update', [ 'user' => Auth::user() ]) }}" method="POST">
				@csrf
				@bag($id)
				@isset($user)
					@method('PATCH')
				@endisset
				<div class="modal-header">
					<h5 class="modal-title" id="{{  $id }}-label">
						{{ $title ?? "Update profile details" }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
						<div class="col-lg-4 mb-3">
                            <label for="">Name</label>
							<input name="name" type="name" class="form-control" placeholder="e.g user name" value="{{ old('name') ?? ( $user->name ?? ( app()->environment('local') ? 'user name' : '' ) ) }}" required>
							@error('name', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label for="">Email Address</label>
							<input name="email" type="email" class="form-control @error('email', $id) is-invalid @enderror" placeholder="e.g demo@gmail.com" value="{{ old('email') ?? ( $user->email ?? ( app()->environment('local') ? 'newaddress@demo.com' : '' ) ) }}" required>
							@error('email', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label for="">Phone Number</label>
							<input name="telephone" type="phone" class="form-control @error('telephone', $id) is-invalid @enderror" placeholder="e.g demo@gmail.com" value="{{ old('telephone') ?? ( $user->telephone ?? ( app()->environment('local') ? '0722113344' : '' ) ) }}" required>
							@error('telephone', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label>Gender</label>
							<select class="form-select" name="gender" @error('gender', $id) is-invalid @enderror" aria-label="Default select example" required>
                                <option value="" disabled selected>Select Gender</option>
								@foreach(config('settings.user.genders') as $gender)
									<option value="{{ $gender }}" {{ ( old('gender') ?? ($user->gender ?? ( app()->environment('local') ? 'male' : null )) == $gender ? 'selected'  : null ) }}>@prettify($gender)</option>
								@endforeach
                            </select>
                            @error('type', $id)
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label>County</label>
                            <select class="form-select" name="county_id" @error('county_id', $id) is-invalid @enderror" aria-label="Default select example" required>
                                <option value="" disabled selected>Select County</option>
                                @foreach ($counties as $county)
                                    <option value="{{ $county->id }}"
                                        @if ($county->id == $user->county_id)
                                        selected
                                        @endif>
                                        {{ $county->name }}</option>
                                @endforeach
                            </select>
                            @error('type', $id)
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="">Locality</label>
							<input name="locality" type="text" class="form-control @error('locality', $id) is-invalid @enderror" placeholder="e.g Village ABC" value="{{ old('locality') ?? ( $user->locality ?? ( app()->environment('local') ? 'sample locality' : '' ) ) }}" required>
							@error('locality', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label for="">Current Password</label>
							<input name="current_password" type="password" class="form-control @error('current_password', $id) is-invalid @enderror" placeholder="Your current password" value="{{ old('password') }}"autocomplete="current-password">
							@error('current_password', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label for="">New Password</label>
							<input name="password" type="password" class="form-control @error('password', $id) is-invalid @enderror" placeholder="Your new password" value="{{ old('password') }}">
							@error('password', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label for="">Confirm Password</label>
							<input id="password-confirm" type="password" placeholder="Confirm the new password" class="form-control"
                                name="password_confirmation" autocomplete="new-password">
                        </div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					<button form="values-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Submit' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif
