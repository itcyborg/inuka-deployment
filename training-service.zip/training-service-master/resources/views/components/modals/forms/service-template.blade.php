@props(['buttonText', 'title', 'service'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? ( isset($service) ? 'Update service' : 'Create a service' ) }}
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{  $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      	<div class="modal-content">
		  <form id="services-form-{{ $id }}" action="{{ isset($service) ? route('portal.managers.services.update', [ 'service' => $service ]) : route('portal.managers.services.store') }}" method="POST">
				@csrf
				@bag($id)
				@isset($service)
					@method('PATCH')
				@endisset
				<div class="modal-header">
					<h5 class="modal-title" id="{{  $id }}-label">
						{{ $title ?? ( isset($service) ? "Update this service" : 'Create a new service' ) }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
						<div class="col-lg-12 mb-3">
              <label for="">Name</label>
              <br>
							<input name="name" type="text" class="form-control @error('name', $id) is-invalid @enderror" placeholder="e.g Skill Development Services" value="{{ old('name') ?? ( $service->name ?? ( app()->environment('local') ? 'Skill Development Services' : '' ) ) }}" required>
							@error('name', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					<button form="services-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Submit' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif
