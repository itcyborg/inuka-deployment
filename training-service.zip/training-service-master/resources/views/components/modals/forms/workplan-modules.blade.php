@props(['buttonText', 'title', 'module', 'workplan'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{  $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? ( isset($module) ? 'Update module' : 'Create a module' ) }}
</button>
  
  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{ $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      	<div class="modal-content">
		  <form id="modules-form-{{ $id }}" action="{{ isset($module) ? route('portal.managers.workplan-modules.update', [ 'workplan_module' => $module ]) : route('portal.managers.workplan-modules.store', ['workplan' => $workplan ?? null]) }}" method="POST">
				@csrf
				@bag($id)
				@isset($module)
					@method('PATCH')
				@endisset
				<div class="modal-header">
					<h5 class="modal-title" id="{{  $id }}-label">
						{{ $title ?? ( isset($module) ? "Update this module" : 'Create a new module' ) }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
						<div class="col-lg-12 mb-3">
							<label for="">Name</label>
							<input name="name" type="text" class="form-control @error('name', $id) is-invalid @enderror" placeholder="e.g Introduction to learning skills" value="{{ old('name') ?? ( $module->name ?? ( app()->environment('local') ? 'Introduction to learning skills' : '' ) ) }}" required>
							@error('name', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
						<div class="col-lg-6 mb-3">
							<label for="">Start Date</label>
							<input name="start_date" type="datetime-local" class="form-control @error('start_date', $id) is-invalid @enderror" placeholder="e.g 72" value="{{ old('start_date') ?? ( (isset($module) ? $module->start_date->format('Y-m-d\TH:i') : '') ?? ( app()->environment('local') ? '20' : '' ) ) }}" required>
							@error('start_date', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
						<div class="col-lg-6 mb-3">
							<label for="">End Date</label>
							<input name="end_date" type="datetime-local" class="form-control @error('end_date', $id) is-invalid @enderror" placeholder="e.g 72" value="{{ old('end_date') ?? ( (isset($module) ? $module->end_date->format('Y-m-d\TH:i') : '') ?? ( app()->environment('local') ? '20' : '' ) ) }}" required>
							@error('end_date', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
						<div class="col-lg-12 mb-3">
							<label for="">Description</label>
							<textarea name="description" cols="30" rows="10" class="form-control @error('description', $id) is-invalid @enderror" placeholder="i.e The modules description" required>{{ old('description') ?? ( $module->description ?? ( app()->environment('local') ? 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur eius sit omnis, non maxime distinctio odit placeat nulla hic nesciunt, doloremque dignissimos provident molestiae esse? Dicta id pariatur labore asperiores' : '' ) ) }}</textarea>
							@error('description', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>						
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					<button form="modules-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Submit' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif