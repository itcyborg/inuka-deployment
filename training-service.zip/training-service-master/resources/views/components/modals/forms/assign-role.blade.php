@props(['buttonText', 'title', 'user', 'roles'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    Assign Role
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{  $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      	<div class="modal-content">
            <form role="form" action="{{ route('portal.managers.users.assign', [ 'user' => $user ]) }}"
                method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <table class="table no-stripes">
                    <thead>
                        <tr>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($roles as $role)
                            <tr>
                                <td class="pb-0">
                                    <div class="row mb-0">
                                        <div class="col-lg-4 mb-0">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="role" value="{{ $role->name }}">
                                                <label class="form-check-label">
                                                    @prettify($role->name)
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="p-2">
                    <button type="submit" class="btn btn-primary w-100">Assign {{$user->name}} a Role</button>
                </div>
            </form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif
