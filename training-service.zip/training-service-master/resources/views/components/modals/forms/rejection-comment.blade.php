@props(['buttonText', 'title', 'trainingRequest'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? 'Reject this Training Request' }}
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{  $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      	<div class="modal-content">
		  <form id="training-requests-rejection-form-{{ $id }}" action="{{ route('portal.trainers.training-requests.decline', [ 'training_request' => $trainingRequest ]) }}" method="POST">
				@csrf
				<div class="modal-header">
					<h5 class="modal-title" id="{{ $id }}-label">
						{{ $title ?? 'Decline the training request' }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
						<div class="col-lg-12 mb-3">
              				<label for="">Reason</label>
							<input name="comment" type="text" class="form-control @error('comment', $id) is-invalid @enderror" placeholder="e.g I will not be available to facilitate the requested training" value="{{ old('comment') ?? ( app()->environment('local') ? 'I will not be available to facilitate the requested training' : '' ) }}" required>
							@error('comment', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					<button form="training-requests-rejection-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Submit' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif
