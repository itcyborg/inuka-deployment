@props(['buttonText', 'title', 'trainer', 'topic', 'trainee', 'managers' ])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" title="Create a training request" data-tooltip="tooltip" data-bs-toggle="modal" data-bs-target="#{{  $id = $attributes->get('id') }}" required>
    <i class="fab fa-wpforms"></i>
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{ $id }}-label" aria-hidden="true">
    <div class="modal-dialog">
      	<div class="modal-content">
		  <form id="training-requests-creation-form-{{ $id }}" action="{{ route('portal.managers.training-requests.store', [ 'trainer' => $trainer, 'trainee' => $trainee, 'topic' => $topic ]) }}" method="POST">
				@csrf
				@bag($id)
				<div class="modal-header">
					<h5 class="modal-title" id="{{ $id }}-label">
						{{ $title ?? 'Create a training request' }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
						<div class="col-lg-12 mb-3">
							<p>Are you sure you would like to create a training request? Select a training request manager from this list to proceed</p>
							<select name="manager_id" class="form-control @error('manager_id', $id) is-invalid @enderror" required>
								<option value="">Select a manager</option>
								@foreach($managers as $manager)
									<option value="{{ $manager->id }}" {{ old('manager_id') == $manager->id ? 'selected' : ''  }}>{{ $manager->name }}</option>
								@endforeach
							</select>
							@error('manager_id', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
					<button form="training-requests-creation-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Create Request' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@once
		@push('js')
			<script>
				var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
				modal.show();
			</script>
		@endpush
	@endonce
@endif
