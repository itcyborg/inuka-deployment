@props(['buttonText', 'title', 'setting'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? ( isset($setting) ? 'Update setting' : 'Create a setting' ) }}
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{  $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      	<div class="modal-content">
		  <form id="settings-form-{{ $id }}" action="{{ isset($setting) ? route('portal.managers.settings.update', [ 'setting' => $setting ]) : route('portal.managers.settings.store') }}" method="POST">
				@csrf
				@bag($id)
				@isset($setting)
					@method('PATCH')
				@endisset
				<div class="modal-header">
					<h5 class="modal-title" id="{{  $id }}-label">
						{{ $title ?? ( isset($setting) ? "Update this setting" : 'Create a new setting' ) }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
						<div class="col-lg-12 mb-3">
                            <label for="">Name</label>
                            <br>
							<input name="name" type="text" class="form-control @error('name', $id) is-invalid @enderror" placeholder="e.g New Setting" value="{{ old('name') ?? ( $setting->name ?? ( app()->environment('local') ? 'New Setting' : '' ) ) }}" required>
							@error('name', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label for="">Description</label>
                            <br>
							<input name="description" type="text" class="form-control @error('description', $id) is-invalid @enderror" placeholder="e.g Desciption to the new setting" value="{{ old('description') ?? ( $setting->description ?? ( app()->environment('local') ? 'Desciption to the new setting' : '' ) ) }}" required>
							@error('description', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
                        </div>
                        @if(empty($setting))
                            <div class="col-lg-12 mb-3">
                                <label>Setting Type</label>
                                <select class="form-select" name="type" @error('type', $id) is-invalid @enderror" aria-label="Default select example" required>
                                    <option value="" disabled selected>Open this select menu</option>
                                    <option value="single">Single</option>
                                    <option value="multiple">Multiple</option>
                                </select>
                                @error('type', $id)
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        @endif
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					<button form="settings-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Submit' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif
