@props(['buttonText', 'title', 'organization', 'counties'])

<!-- Button trigger modal -->
<button type="button" class="{{ $attributes->get('class') }}" data-bs-toggle="modal" data-bs-target="#{{ $id = $attributes->get('id') }}" required>
    {{ $buttonText ?? ( isset($organization) ? 'Update organization' : 'Create a organization' ) }}
</button>

  <!-- Modal -->
<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-labelledby="{{  $id }}-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      	<div class="modal-content">
		  <form id="organizations-form-{{ $id }}" action="{{ isset($organization) ? route('portal.managers.organizations.update', [ 'organization' => $organization ]) : route('portal.managers.organizations.store') }}" method="POST">
				@csrf
				@bag($id)
				@isset($organization)
					@method('PUT')
				@endisset
				<div class="modal-header">
					<h5 class="modal-title" id="{{  $id }}-label">
						{{ $title ?? ( isset($organization) ? "Update this organization" : 'Create a new organization' ) }}
					</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body text-start">
					<div class="row">
                        <div class="col-lg-6 mb-3">
                            <label for="">Public Id</label>
                            <br>
							<input name="public_id" type="text" class="form-control @error('public_id', $id) is-invalid @enderror" placeholder="e.g 1000" value="{{ old('public_id') ?? ( $organization->public_id ?? ( app()->environment('local') ? '1000' : '' ) ) }}" required>
							@error('public_id', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
						<div class="col-lg-6 mb-3">
                            <label for="">Name</label>
                            <br>
							<input name="name" type="text" class="form-control @error('name', $id) is-invalid @enderror" placeholder="e.g New Organization" value="{{ old('name') ?? ( $organization->name ?? ( app()->environment('local') ? 'New Organization' : '' ) ) }}" required>
							@error('name', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
                        <div class="col-lg-6 mb-3">
                            <label for="">Email Address</label>
                            <br>
							<input name="email" type="text" class="form-control @error('email', $id) is-invalid @enderror" placeholder="e.g organization@demo.com" value="{{ old('email') ?? ( $organization->email ?? ( app()->environment('local') ? 'organization@demo.com' : '' ) ) }}" required>
							@error('email', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
                        <div class="col-lg-6 mb-3">
                            <label for="">Phone Number</label>
                            <br>
							<input name="telephone" type="text" class="form-control @error('telephone', $id) is-invalid @enderror" placeholder="e.g +254722781981" value="{{ old('telephone') ?? ( $organization->telephone ?? ( app()->environment('local') ? '+254722781981' : '' ) ) }}" required>
							@error('telephone', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
                        <div class="col-lg-6 mb-3">
                            <label>County</label>
                            <select class="form-select" name="county_id" @error('county_id', $id) is-invalid @enderror" aria-label="Default select example" required>
                                <option value="">Open this select menu</option>
                                @foreach ($counties as $county)
                                    <option value="{{ $county->id }}" {{ old('county_id') == $county->id ? 'selected' : ''  }}>{{ $county->name }}</option>
                                @endforeach
                            </select>
                            @error('county_id', $id)
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="">Locality</label>
                            <br>
							<input name="locality" type="text" class="form-control @error('locality', $id) is-invalid @enderror" placeholder="e.g Uptown" value="{{ old('locality') ?? ( $organization->locality ?? ( app()->environment('local') ? 'Uptown' : '' ) ) }}" required>
							@error('locality', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
						<div class="col-lg-6 mb-3">
                            <label for="">Business Sector</label>
                            <br>
							<input name="business_sector" type="text" class="form-control @error('business_sector', $id) is-invalid @enderror" placeholder="e.g Department/Business Sector" value="{{ old('business_sector') ?? ( $organization->trainee->business_sector ?? ( app()->environment('local') ? 'Department/Business Sector' : '' ) ) }}" required>
							@error('name', $id)
								<div class="invalid-feedback">
									{{ $message }}
								</div>
							@enderror
						</div>
						<div class="col-lg-12 mb-3">
							<label>Bio</label>
							<textarea cols="600" rows="3" class="form-control @error('bio', $id) is-invalid @enderror" name="bio" placeholder="Enter Group Bio Here" required>{{ $organization->trainee->bio ?? null }}</textarea>
                                @error('bio', $id)
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					<button form="organizations-form-{{ $id }}" type="submit" class="btn btn-success">
						{{ $submitText ?? 'Submit' }}
					</button>
				</div>
			</form>
      	</div>
    </div>
</div>
@if($errors->hasBag($id))
	@push('js')
		<script>
			var modal = new bootstrap.Modal(document.getElementById(`{{ $id }}`));
			modal.show();
		</script>
	@endpush
@endif
