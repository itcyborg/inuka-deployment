@php
    $profile = $trainer->uploadOfType('resume');
@endphp
@once
    @push('status-alerts')
        <x-status-alert prephrase="Trainer Prequalification status" :status="$trainer->status" />
    @endpush
@endonce

<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <a class="nav-link active" id="general-tab" data-bs-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">General Information</a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link" id="professional-tab" data-bs-toggle="tab" href="#professional" role="tab" aria-controls="professional" aria-selected="false">Professional Information</a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link" id="expertise-tab" data-bs-toggle="tab" href="#expertise" role="tab" aria-controls="expertise" aria-selected="false">Areas of Expertise</a>
    </li>
</ul>
<div class="tab-content">
    <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
        <table class="table">
            <tbody>
                <tr>
                    <th class="w-25">Name</th>
                    <td>{{ $trainer->trainable->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Email</th>
                    <td>{{ $trainer->trainable->email }}</td>
                </tr>
                <tr>
                    <th class="w-25">Phone Number</th>
                    <td>{{ $trainer->trainable->telephone }}</td>
                </tr>
                <tr>
                    <th class="w-25">County</th>
                    <td>{{ $trainer->trainable->county->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Website</th>
                    <td>{{ $trainer->website ?? 'None' }}</td>
                </tr>
                <tr>
                    <th class="w-25">Language Profieciencies</th>
                    <td>
                        @foreach($trainer->languages as $language)
                            {{ $language->name }}@if(!$loop->last),@endif
                        @endforeach
                    </td>
                </tr>
                <tr>
                    <th class="w-25">Status</th>
                    <td>@prettify($trainer->trainable->status)</td>
                </tr>
                <tr>
                  <th class="w-25">Rating</th>
                  <td>
                    <x-rating-star :rating="$trainer->rating"/>
                  </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="tab-pane fade" id="professional" role="tabpanel" aria-labelledby="professional-tab">
        <table class="table table-sm">
            <tbody>
                <tr>
                    <th class="w-25">Previous Experience</th>
                    <td>
                        <ul class="list-group rounded-0 bg-transparent">
                            @foreach($trainer->experiences as $experience)
                                <li class="list-group-item bg-transparent border-start-0 border-end-0 border-top-0 px-0 {{ $loop->last ? 'border-bottom-0' : '' }}">
                                    <strong>{{ $experience->description }}</strong><br>
                                    {{ $experience->start_year }} - {{ $experience->end_year }} ({{ $experience->location }})
                                </li>
                            @endforeach
                        </ul>
                    </td>
                </tr>
                <tr>
                    <th class="w-25">Qualifications</th>
                    <td>
                        <ul class="list-group rounded-0">
                            @foreach($trainer->qualifications as $qualification)
                                <li class="list-group-item bg-transparent border-start-0 border-end-0 border-top-0 px-0 {{ $loop->last ? 'border-bottom-0' : '' }}">
                                    <strong>{{ $qualification->certification }} ({{ $qualification->year }})</strong><br>
                                    {{ $qualification->institution }} - {{ $qualification->location }}
                                </li>
                            @endforeach
                        </ul>
                    </td>
                </tr>
                @can('download', $profile)
                    <tr>
                        <th class="w-25">
                            {{ $trainer->isAUser() ? 'Resume' : 'Profile' }}
                        </th>
                        <td>
                            <a href="{{ route('portal.managers.resumes.download', [ 'upload' => $profile ]) }}">
                                Download {{ $trainer->isAUser() ? 'Resume' : 'Profile' }}
                            </a>
                        </td>
                    </tr>
                @endcan
            </tbody>
        </table>
    </div>
    <div class="tab-pane fade" id="expertise" role="tabpanel" aria-labelledby="expertise-tab">
        @if($trainer->topics->isNotEmpty())
            <table class="table">
                <thead>
                    <tr>
                        <th>Topic</th>
                        <th>Area</th>
                        <th>Service</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($trainer->topics as $topic)
                        <tr>
                            <td>{{ $topic->name }}</td>
                            <td>{{ $topic->area->name }}</td>
                            <td>{{ $topic->area->service->name }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <div class="empty-collection">
                <h5>Sorry, no areas of expertise are available</h5>
            </div>
        @endif
    </div>
</div>
