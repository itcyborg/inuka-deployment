    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'active' : '' }}" id="general-tab" data-bs-toggle="tab" href="#general" role="tab"
                aria-controls="general" aria-selected="true">General Information</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link {{ request()->query('tab') == 'expertise-tab' ? 'active' : '' }}" id="expertise-tab" data-bs-toggle="tab" href="#expertise" role="tab"
                aria-controls="expertise" aria-selected="false">Topics of Interest</a>
        </li>
        @can('update', $trainee)
            <li class="nav-item" role="presentation">
                <a class="nav-link {{ request()->query('tab') == 'professional-tab' ? 'active' : '' }}" id="professional-tab" data-bs-toggle="tab" href="#professional" role="tab"
                    aria-controls="professional" aria-selected="false">Assign Topics</a>
            </li>
        @endcan
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'show active' : '' }} " id="general" role="tabpanel" aria-labelledby="general-tab">
            <table class="table">
                <tbody>
                    <tr>
                        <th class="w-25">Name</th>
                        <td>{{ $trainee->trainable->name }}</td>
                    </tr>
                    <tr>
                        <th class="w-25">Email</th>
                        <td>{{ $trainee->trainable->email }}</td>
                    </tr>
                    <tr>
                        <th class="w-25">Phone Number</th>
                        <td>{{ $trainee->trainable->telephone }}</td>
                    </tr>
                    <tr>
                        <th class="w-25">Business Sector</th>
                        <td>{{ $trainee->business_sector }}</td>
                    </tr>
                    <tr>
                        <th class="w-25">Bio</th>
                        <td>{{ $trainee->bio ?? 'None' }}</td>
                    </tr>
                    <tr>
                        <th class="w-25">Status</th>
                        <td>{{ $trainee->trainable->status }}</td>
                    </tr>
                    <tr>
                        <th class="w-25">Rating</th>
                        <td>
                            <x-rating-star :rating="$trainee->rating"/>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="tab-pane fade {{ request()->query('tab') == 'expertise-tab' ? 'show active' : '' }}" id="expertise" role="tabpanel" aria-labelledby="expertise-tab">
            @if($trainee->topics->isNotEmpty())
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Topic</th>
                            <th>Area</th>
                            <th>Service</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($trainee->topics as $topic)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $topic->name }}</td>
                                <td>{{ $topic->area->name }}</td>
                                <td>{{ $topic->area->service->name }}</td>
                                <td class="text-center">
                                    @can('create', [\App\Models\TrainingRequest::class, $trainee, $topic])
                                        <a href="{{ route('portal.managers.trainees.topic', ['trainee' => $trainee, 'topic' => $topic]) }}"
                                            class="btn btn-primary btn-sm">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    @else
                                        @if ($trainingRequest = $topic->currentRequest($trainee))
                                            <a href="{{ route($trainingRequestRoute(), ['training_request' => $trainingRequest]) }}"
                                                class="btn btn-success btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        @endif
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @else
                <div class="empty-collection">
                    <h5>Sorry, no topics are available</h5>
                </div>
            @endif
        </div>

        @can('view', $trainee)
            <div class="tab-pane fade {{ request()->query('tab') == 'professional-tab' ? 'show active' : '' }}" id="professional" role="tabpanel" aria-labelledby="professional-tab">
                <form role="form" action="{{ route('portal.managers.trainees.update', [ 'trainee' => $trainee ]) }}"
                    method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Service</th>
                                <th>Area</th>
                                <th>Topic</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($topics as $topic)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $topic->area->service->name }}</td>
                                    <td>{{ $topic->area->name }}</td>
                                    <td>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="topics[]" value="{{ $topic->id }}" {{ $trainee->topics->find($topic->id) ? 'checked' : '' }}>
                                            <label class="form-check-label">
                                                {{ $topic->name }}
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="p-2">
                        <button type="submit" class="btn btn-primary w-100">Assign/Unassign Topics</button>
                    </div>
                </form>
            </div>
        @endcan
    </div>
