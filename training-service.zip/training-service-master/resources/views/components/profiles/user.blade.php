@once
    @push('status-alerts')
        <x-status-alert prephrase="User status" :status="$user->status" />
    @endpush
@endonce
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <a class="nav-link {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'active' : '' }}" id="general-tab" data-bs-toggle="tab" href="#general" role="tab"
            aria-controls="general" aria-selected="true">General Information</a>
    </li>

    <li class="nav-item" role="presentation">
        <a class="nav-link {{ request()->query('tab') == 'permission-tab' ? 'active' : '' }}" id="role-tab" data-bs-toggle="tab" href="#role" role="tab"
            aria-controls="role" aria-selected="false">User Role</a>
    </li>

    <li class="nav-item" role="presentation">
        <a class="nav-link {{ request()->query('tab') == 'permission-tab' ? 'active' : '' }}" id="permission-tab" data-bs-toggle="tab" href="#permission" role="tab"
            aria-controls="permission" aria-selected="false">User Permissions</a>
    </li>
</ul>
<div class="tab-content">
    <div class="tab-pane fade {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'show active' : '' }} " id="general" role="tabpanel" aria-labelledby="general-tab">
        <table class="table">
            <tbody>
                @if($user->hasStatus('DEACTIVATED'))
                    <tr>
                        <th class="w-25">Deactivation Reason</th>
                        <td class="text-danger">{{ $user->comments->last()->comment }}</td>
                    </tr>
                @endcan
                <tr>
                    <th class="w-25">Name</th>
                    <td>{{ $user->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Email</th>
                    <td>{{ $user->email }}</td>
                </tr>
                <tr>
                    <th class="w-25">Phone Number</th>
                    <td>{{ $user->telephone }}</td>
                </tr>
                <tr>
                    <th class="w-25">Gender</th>
                    <td>{{ $user->gender }}</td>
                </tr>
                <tr>
                    <th class="w-25">Bio</th>
                    <td>{{ $user->bio ?? 'None' }}</td>
                </tr>
                <tr>
                    <th class="w-25">Status</th>
                    <td>{{ $user->status }}</td>
                </tr>
                <tr>
                    <th class="w-25">Rating</th>
                    <td>
                        <x-rating-star :rating="$user->rating"/>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-pane fade {{ request()->query('tab') == 'role-tab' ? 'show active' : '' }} p-4" id="role" role="tabpanel" aria-labelledby="role-tab">
        <form role="form" action="{{ route('portal.managers.users.update', [ 'user' => $user ]) }}"
            method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <table class="table no-stripes">
                <thead>
                    <tr>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($roles as $role)
                        <tr>
                            <td class="pb-0">
                                <div class="row mb-0">
                                    <div class="col-lg-4 mb-0">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="role" value="{{ $role->name }}" {{ $user->roles->find($role->id) ? 'checked' : '' }}>
                                            <label class="form-check-label">
                                                @prettify($role->name)
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="p-2">
                <button type="submit" class="btn btn-primary w-100">Assign/Unassign User Role</button>
            </div>
        </form>
    </div>

    <div class="tab-pane fade {{ request()->query('tab') == 'permission-tab' ? 'show active' : '' }} p-4" id="permission" role="tabpanel" aria-labelledby="role-tab">
        <form role="form" action="{{ route('portal.managers.users.update', [ 'user' => $user ]) }}"
            method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <table class="table no-stripes">
                <thead>
                    <tr>
                        <th class="w-25">Group</th>
                        <th>Permissions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($permissions as $group => $groupPermissions)
                        <tr>
                            <td>@prettify($group)</td>
                            <td class="pb-0">
                                <div class="row mb-0">
                                    @foreach($groupPermissions as $permission)
                                        <div class="col-lg-4 mb-0">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="{{ $permission->id }}" {{ $user->permissions->find($permission->id) ? 'checked' : '' }}>
                                                <label class="form-check-label">
                                                    @prettify($permission->name)
                                                </label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="p-2">
                <button type="submit" class="btn btn-primary w-100">Assign/Unassign Permissions</button>
            </div>
        </form>
    </div>
</div>
