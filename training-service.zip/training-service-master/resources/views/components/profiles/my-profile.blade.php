<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <a class="nav-link {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'active' : '' }}" id="general-tab" data-bs-toggle="tab" href="#general" role="tab"
            aria-controls="general" aria-selected="true">General Information</a>
    </li>
</ul>
<div class="tab-content">
    <div class="tab-pane fade {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'show active' : '' }} " id="general" role="tabpanel" aria-labelledby="general-tab">
        <table class="table">
            <tbody>
                <tr>
                    <th class="w-25">Name</th>
                    <td>{{ $user->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Email</th>
                    <td>{{ $user->email }}</td>
                </tr>
                <tr>
                    <th class="w-25">Phone Number</th>
                    <td>{{ $user->telephone }}</td>
                </tr>
                <tr>
                    <th class="w-25">Gender</th>
                    <td>@prettify($user->gender)</td>
                </tr>
                <tr>
                    <th class="w-25">County</th>
                    <td>{{ $user->county->name ?? 'Unavailable' }}</td>
                </tr>
                <tr>
                    <th class="w-25">Locality</th>
                    <td>{{ $user->locality }}</td>
                </tr>
                <tr>
                    <th class="w-25">Bio</th>
                    <td>{{ $user->bio ?? 'None' }}</td>
                </tr>
                <tr>
                    <th class="w-25">Status</th>
                    <td>{{ $user->status }}</td>
                </tr>
                <tr>
                    <th class="w-25">Rating</th>
                    <td>
                        <x-rating-star :rating="$user->rating"/>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
