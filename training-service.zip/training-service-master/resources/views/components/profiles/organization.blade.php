<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <a class="nav-link {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'active' : '' }}" id="general-tab" data-bs-toggle="tab" href="#general" role="tab"
            aria-controls="general" aria-selected="true">General Information</a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link {{ request()->query('tab') == 'expertise-tab' ? 'active' : '' }}" id="expertise-tab" data-bs-toggle="tab" href="#expertise" role="tab"
            aria-controls="expertise" aria-selected="false">Registered Users</a>
    </li>
    @can('update', $organization)
        <li class="nav-item" role="presentation">
            <a class="nav-link {{ request()->query('tab') == 'professional-tab' ? 'active' : '' }}" id="professional-tab" data-bs-toggle="tab" href="#professional" role="tab"
                aria-controls="professional" aria-selected="false">Add/Remove Users</a>
        </li>
    @endcan
</ul>
<div class="tab-content">
    <div class="tab-pane fade {{ request()->query('tab') == 'general-tab' || !request()->query('tab') ? 'show active' : '' }} " id="general" role="tabpanel" aria-labelledby="general-tab">
        <table class="table">
            <tbody>
                <tr>
                    <th class="w-25">Name</th>
                    <td>{{ $organization->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Public ID</th>
                    <td>{{ $organization->public_id }}</td>
                </tr>
                <tr>
                    <th class="w-25">Email</th>
                    <td>{{ $organization->email }}</td>
                </tr>
                <tr>
                    <th class="w-25">Phone Number</th>
                    <td>{{ $organization->telephone }}</td>
                </tr>
                <tr>
                    <th class="w-25">County</th>
                    <td>{{ $organization->county->name }}</td>
                </tr>
                <tr>
                    <th class="w-25">Locality</th>
                    <td>{{ $organization->locality ?? 'None' }}</td>
                </tr>
                <tr>
                    <th class="w-25">Bio</th>
                    <td>{{ $organization->trainee->bio ?? 'Unavailable' }}</td>
                </tr>
                <tr>
                    <th class="w-25">Business Setor/Department</th>
                    <td>{{ $organization->trainee->business_sector ?? 'Unavailable' }}</td>
                </tr>
                <tr>
                    <th class="w-25">Status</th>
                    <td>{{ $organization->status }}</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tab-pane fade {{ request()->query('tab') == 'expertise-tab' ? 'show active' : '' }}" id="expertise" role="tabpanel" aria-labelledby="expertise-tab">
        @if($organization->users->isNotEmpty())
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>County</th>
                        <th>Gender</th>
                        <th>Locality</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($organization->users as $user)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ $user->telephone }}</td>
                            <td>{{ $user->county->name ?? 'Unavailable' }}</td>
                            <td>{{ $user->gender }}</td>
                            <td>{{ $user->locality }}</td>
                            <td>{{ $user->status }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <div class="empty-collection">
                <h5>Sorry, no trainees are available</h5>
            </div>
        @endif
    </div>

    @can('update', $organization)
        <div class="tab-pane fade {{ request()->query('tab') == 'professional-tab' ? 'show active' : '' }}" id="professional" role="tabpanel" aria-labelledby="professional-tab">
            <form role="form" action="{{ route('portal.managers.organizations.update', [ 'organization' => $organization ]) }}"
                method="POST" enctype="multipart/form-data">
                @csrf
                <input name="form" value="123" hidden>
                @method('PUT')
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Owner Organization</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($users as $user)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->telephone }}</td>
                                <td>{{ $user->organization->name ?? 'Not Assigned' }}</td>
                                <td>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="users[]" value="{{ $user->id }}" {{ $organization->users->find($user->id) ? 'checked' : '' }}>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="p-2">
                    <button type="submit" class="btn btn-primary w-100">Add/Remove Users</button>
                </div>
            </form>
        </div>
    @endcan
</div>
