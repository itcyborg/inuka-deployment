<div class="notification-container">
    <div class="notifications-header dropdown-item">
        <div class="fw-bold title">{{ $title ?? 'Notifications' }}</div>
    </div>
    <div class="notifications-body">
        <div class="list-group">
            @forelse($notifications as $notification)
                @if($message = $getMessage($notification))
                    <a
                        href="{{ route($actionRouteName(), [ 'notification' => $notification ]) }}"
                        {{ $attributes->merge([ 'class' => $unreadClass($notification).' dropdown-item list-group-item text-wrap' ]) }}
                    >
                        <p class="text">{!! $message !!}</p>
                        <span class="timestamp">@dateforhumans($notification->created_at)</span>
                    </a>
                @endisset
                @isset($count)
                    @break($loop->iteration === $count)
                @endisset
            @empty
                <div class="dropdown-item py-3 d-flex align-items-center justify-content-between list-group-item">
                    <p class="m-1">No notifications are available</p>
                </div>
            @endforelse
        </div>
    </div>
    @if($notifications->isNotEmpty())
        <div class="notifications-footer dropdown-item ">
            <a href="{{ route($viewAllRouteName()) }}" class="w-100 text-decoration-none">View All</a>
        </div>
    @endif
</div>
