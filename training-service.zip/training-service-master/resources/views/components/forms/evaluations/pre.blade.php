<section class="row">
    <div class="col-lg-12">
        <x-cards.content title="General Information">
            <x-tables.evaluations.pre.general :training-request="$trainingRequest" />
        </x-cards.content>
    </div>
</section>
<section class="row">
    <div class="col-lg-12">
        <x-cards.content title="Details of training service (s) provided" class="py-3 px-4">
            <form action="{{ isset($evaluation) ? route('portal.trainees.pre-evaluations.update', ['evaluation' => $evaluation]) : route('portal.trainees.pre-evaluations.store', ['training_request' => $trainingRequest]) }}" method="POST">
                @csrf
                @isset($evaluation)
                    @method('PATCH')
                @endisset
                <div class="row">
                    <div class="col-lg-12">
                        <x-tables.evaluations.pre.details
                            :modules="$trainingRequest->workplan->modules"
                            :scales="config('settings.evaluations.pre.rating_options')"
                            :evaluation="$evaluation ?? null"
                        />
                    </div>
                    <div class="col-lg-12 mt-3">
                        <label>If you could change anything about the services provided, what would it be?</label>
                        <textarea cols="600" rows="3" class="form-control @error('suggestion') is-invalid @enderror" id="suggestion" name="suggestion" placeholder="Enter value here" required>{{ old('suggestion') ?? ($evaluation->suggestion ?? (app()->environment('local') ? 'Sample Suggestion' : ''))  }}</textarea>
                        @error('suggestion')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="col-lg-12 my-3">
                        <button type="submit" class="btn btn-success">
                            @isset($evaluation)
                                Update
                            @else
                                Submit
                            @endisset
                        </button>
                    </div>
                </div>
            </form>
        </x-cards.content>
    </div>
</section>
