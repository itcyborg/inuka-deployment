<div class="row">
    @error('trainer.topics')
        <div class="col-lg-12">
            <p class="text-danger">{{ $message }}</p>
        </div>
    @enderror
    @foreach($services as $service)
        <div class="col-lg-12 mb-4">
            <div class="@error('trainer.topics') border border-danger @enderror">
                <table class="table no-stripes">
                    <thead>
                        <tr>
                            <th class="bg-light" colspan="2">{{ $service->name }}</th>
                        </tr>
                        <tr>
                            <th>Area</th>
                            <th>Topics</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($service->areas as $area)
                            <tr>
                                <th class="w-25">{{ $area->name }}</th>
                                <td class="p-0">
                                    <table class="table no-stripes topics">
                                        <tbody>
                                            @foreach($area->topics as $topic)
                                                <tr class="@if($loop->first) border-top-0 @endif @if($loop->last) border-bottom-0 @endif">
                                                    <td class="border-start-0 border-end-0">
                                                        <input wire:model.defer="trainer.curr_topics" class="me-1 mb-1" type="checkbox" value="{{ $topic->id }}">
                                                        {{ $topic->name }}
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>                        
            </div>
        </div>
    @endforeach
</div>