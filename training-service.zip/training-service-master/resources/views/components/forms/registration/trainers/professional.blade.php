<div class="row">
    <div class="col-lg-12">
        <div class="row">
            <div class="col-lg-12 mb-3">
                <label><x-required/> Your Bio</label>
                <textarea wire:model.debounce.500ms="trainer.bio" type="text" class="form-control @error('trainer.bio') is-invalid @enderror" placeholder="Give an overview of your professional abilities" required form="trainer-registration-form"></textarea>
                @error('trainer.bio')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-lg-12 mb-3">
                <label><x-required/> Language Profieciencies</label>
                <div class="section-container border @error('trainer.languages') border-danger @enderror px-3 pt-2 pb-2">
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="text-muted mb-1">Select the languages you can speak</p>
                        </div>
                        @foreach($languages as $language)
                            <div class="col-lg-3">
                                <div class="form-check">
                                    <input wire:model.defer="trainer.curr_languages" class="form-check-input" type="checkbox" value="{{ $language }}" form="trainer-registration-form">
                                    <label class="form-check-label">
                                        {{ $language }}
                                    </label>
                                </div>
                            </div>
                        @endforeach
                        @error('trainer.languages')
                            <small class="text-danger">
                                {{ $message }}
                            </small>
                        @enderror
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mb-3">
                <label>Your Website</label>
                <input wire:model.debounce.500ms="trainer.website" type="text" class="form-control @error('trainer.website') is-invalid @enderror" placeholder="e.g https://hapakenya.com" form="trainer-registration-form">
                @error('trainer.website')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-3">
                <label>Your Previous Professional Experiences</label>
                <div class="section-container border px-3 pt-2 pb-2">
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="text-muted mb-1">List some of the engagaments that you have previously undertaken</p>
                        </div>
                        <div class="col-lg-12">
                            <livewire:forms.experience :trainer="$this->trainer" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-3">
                <label>Your Academic Qualifications</label>
                <div class="section-container border px-3 pt-2 pb-2">
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="text-muted mb-1">List some of your academic qualifications</p>
                        </div>
                        <div class="col-lg-12">
                            <livewire:forms.qualification :trainer="$this->trainer" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
