<div class="row">
    <div class="col-lg-12 mb-3">
        <label><x-required/> Your Name</label>
        <input name="name" wire:model.debounce.500ms="user.name" type="text" class="form-control @error('user.name') is-invalid @enderror" placeholder="e.g Hakuna Matata" required form="trainer-registration-form">
        @error('user.name')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="col-lg-4 mb-3">
        <label><x-required/> Your Email</label>
        <input name="email" wire:model.debounce.500ms="user.email" type="email" class="form-control @error('user.email') is-invalid @enderror" placeholder="e.g hakuna.matata@kenyan.com" required form="trainer-registration-form">
        @error('user.email')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="col-lg-4 mb-3">
        <label><x-required/> Your Phone Number</label>
        <input wire:model.debounce.500ms="user.telephone" type="text" class="form-control @error('user.telephone') is-invalid @enderror" placeholder="e.g +254712345678" required form="trainer-registration-form">
        @error('user.telephone')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="col-lg-4 mb-3">
        <label><x-required/> Your Gender</label>
        <select wire:model.debounce.500ms="user.gender" class="form-control @error('user.gender') is-invalid @enderror" required form="trainer-registration-form">
            <option value="">Choose 1 from the list</option>
            @foreach($genders as $gender)
                <option value="{{ $gender }}">@prettify($gender)</option>
            @endforeach
        </select>
        @error('user.gender')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="col-lg-6 mb-3">
        <label><x-required/> Your County of Residence</label>
        <select wire:model.debounce.500ms="user.county_id" class="form-control @error('user.county_id') is-invalid @enderror" required form="trainer-registration-form">
            <option value="">Choose 1 from the list</option>
            @foreach($counties as $county)
                <option value="{{ $county->id }}">{{ $county->name }}</option>
            @endforeach
        </select>
        @error('user.county_id')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="col-lg-6 mb-3">
        <label><x-required/> Your Locality of Residence</label>
        <input wire:model.debounce.500ms="user.locality" type="text" class="form-control @error('user.locality') is-invalid @enderror" placeholder="e.g Kibera, Nairobi" required form="trainer-registration-form">
        @error('user.locality')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    @if(!isset($password) || (bool) $password)
        <div class="col-lg-6 mb-3">
            <label><x-required/> Your Password</label>
            <input wire:model.debounce.500ms="user.passkey" type="password" class="form-control @error('user.passkey') is-invalid @enderror" placeholder="A secure password" required form="trainer-registration-form">
            @error('user.passkey')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>                
        <div class="col-lg-6 mb-3">
            <label><x-required/> Confirm Your Password</label>
            <input wire:model.debounce.500ms="user.passkey_confirmation" type="password" class="form-control" placeholder="Confirm the password" required form="trainer-registration-form">
        </div>
    @endif
</div>