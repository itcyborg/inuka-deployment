<div class="row">
    <div class="col-lg-12">
        <div class="accordion" id="confirmation">
            <div class="accordion-item">
                <h2 class="accordion-header" id="general-information-header">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#general-information"
                        aria-expanded="true" aria-controls="general-information">
                        General Information
                    </button>
                </h2>
                <div id="general-information" class="accordion-collapse collapse show" aria-labelledby="general-information-header"
                    data-bs-parent="#confirmation">
                    <div class="accordion-body p-0">
                        <table class="table no-stripes">
                            <tbody>
                                <tr>
                                    <th class="w-25 border-start-0">Name</th>
                                    <td class="border-end-0">{{ $user->name }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Email</th>
                                    <td class="border-end-0">{{ $user->email }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Phone Number</th>
                                    <td class="border-end-0">{{ $user->telephone }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Gender</th>
                                    <td class="border-end-0">@prettify($user->gender)</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">County</th>
                                    <td class="border-end-0">{{ $this->county->name }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="professional-information-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#professional-information"
                        aria-expanded="false" aria-controls="professional-information">
                        Professional Information
                    </button>
                </h2>
                <div id="professional-information" class="accordion-collapse collapse" aria-labelledby="professional-information-header"
                    data-bs-parent="#confirmation">
                    <div class="accordion-body p-0">
                        <table class="table no-stripes">
                            <tbody>
                                <tr class="border-top-0">
                                    <th class="w-25 border-start-0">Bio</th>
                                    <td class="border-end-0">{{ $trainer->bio }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Website</th>
                                    <td class="border-end-0">{{ $trainer->website }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Language Profieciencies</th>
                                    <td class="border-end-0">
                                        @forelse($trainer->curr_languages as $language)
                                            {{ $language }} @if(!$loop->last),@endif
                                        @empty
                                            None Provided
                                        @endforelse
                                    </td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Previous Professional Experiences</th>
                                    <td class="border-end-0 py-0 px-2">
                                        @if($this->experiences->isNotEmpty())
                                            <table class="table no-stripes no-borders experiences">
                                                <thead>
                                                    <tr>
                                                        <th class="index">#</th>
                                                        <th>Description</th>
                                                        <th>Start Year</th>
                                                        <th>End Year</th>
                                                        <th>Location</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($this->experiences as $experience)
                                                        <tr>
                                                            <td>{{ $loop->iteration }}</td>
                                                            <td>{{ $experience->description }}</td>
                                                            <td>{{ $experience->start_year }}</td>
                                                            <td>{{ $experience->end_year }}</td>
                                                            <td>{{ $experience->location }}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        @else 
                                            <div class="px-1">
                                                None Provided
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                                <tr class="border-bottom-0">
                                    <th class="border-start-0">Academic Qualifications</th>
                                    <td class="border-end-0 py-0 px-2">
                                        @if($this->qualifications->isNotEmpty())
                                            <table class="table no-stripes no-borders qualifications">
                                                <thead>
                                                    <tr>
                                                        <th class="index">#</th>
                                                        <th>Certification</th>
                                                        <th>Institution</th>
                                                        <th>Location</th>
                                                        <th>Year</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($this->qualifications as $qualification)
                                                        <tr>
                                                            <td>{{ $loop->iteration }}</td>
                                                            <td>{{ $qualification->certification }}</td>
                                                            <td>{{ $qualification->institution }}</td>
                                                            <td>{{ $qualification->location }}</td>
                                                            <td>{{ $qualification->year }}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        @else 
                                            <div class="px-1">
                                                None Provided
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="areas-of-expertise-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#areas-of-expertise"
                        aria-expanded="false" aria-controls="areas-of-expertise">
                        Areas of Expertise
                    </button>
                </h2>
                <div id="areas-of-expertise" class="accordion-collapse collapse" aria-labelledby="areas-of-expertise-header"
                    data-bs-parent="#confirmation">
                    <div class="accordion-body p-0">
                        <table class="table no-stripes no-borders">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th class="w-50">Topic</th>
                                    <th>Area</th>
                                    <th>Service</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($this->topics as $topic)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $topic->name }}</td>
                                        <td>{{ $topic->area->name }}</td>
                                        <td>{{ $topic->area->service->name }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>                        
        </div>
    </div>
</div>