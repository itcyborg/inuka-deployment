<div class="row">
    <div class="col-lg-12">
        <div class="accordion" id="confirmation">
            <div class="accordion-item">
                <h2 class="accordion-header" id="general-information-header">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#general-information"
                        aria-expanded="true" aria-controls="general-information">
                        General Information
                    </button>
                </h2>
                <div id="general-information" class="accordion-collapse collapse show" aria-labelledby="general-information-header"
                    data-bs-parent="#confirmation">
                    <div class="accordion-body p-0">
                        <table class="table no-stripes">
                            <tbody>
                                <tr>
                                    <th class="w-25 border-start-0">Name</th>
                                    <td class="border-end-0">{{ $user->name }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Email</th>
                                    <td class="border-end-0">{{ $user->email }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Phone Number</th>
                                    <td class="border-end-0">{{ $user->telephone }}</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">Gender</th>
                                    <td class="border-end-0">@prettify($user->gender)</td>
                                </tr>
                                <tr>
                                    <th class="border-start-0">County</th>
                                    <td class="border-end-0">{{ $this->county->name }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
