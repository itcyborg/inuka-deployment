<div
	role="alert"
	aria-live="polite"
	aria-atomic="true"
	data-bs-delay="10000"
	class="toast ms-auto"
>
    <div class="toast-header py-3">
    	<img src="{{ asset( config('settings.logo_path') ) }}" class="rounded me-2 img-fluid" alt="{{ config('app.name') }}">
        <strong class="me-auto">{{ config('app.name') }}</strong><br>
        <button type="button" class="btn-close btn-close-primary ms-auto me-2" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body {{ $type }} text-white">
        {{ $message }}
    </div>
</div>
