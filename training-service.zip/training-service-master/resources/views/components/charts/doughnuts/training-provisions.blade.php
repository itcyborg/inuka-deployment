@props(['payload'])

{{-- The template section --}}
<div class="chart-container py-3">
    <canvas id="{{ $id = $attributes->get('id') }}"></canvas>
</div>

{{-- The Js Section of the component --}}
@push('js')
    <script>
        var ctx = document.getElementById(`{{ $id }}`).getContext('2d');
        var requests = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: @json($payload['labels']),
                datasets: [{
                    label: '# of Votes',
                    data: @json($payload['data']),
                    backgroundColor: @json($payload['colors']),
                    borderWidth: 1
                }]
            },
            options: {
                maintainAspectRatio: false
            }
        });
    </script>
@endpush