@push('main-alert')
    <a href="{{ $action ?? '#' }}" class="text-decoration-none">
        <div {{ $attributes->merge(['class' => 'callout callout-primary']) }}>
            <h5 class="fw-bold">{{ $title }}</h5>
            <p>{!! $message !!}</p>
        </div>  
    </a>
@endpush