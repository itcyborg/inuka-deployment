<table class="table table-bordered table-hover">
    <tbody>
        <tr>
            <th class="w-50 text-uppercase">@prettify(config('settings.aliases.trainee')) Name:</th>
            <td>{{ $trainingRequest->topicTrainee->trainee->trainable->name }}</td>
        </tr>
        <tr>
            <th class="w-50 text-uppercase">Training Service(s) Provided:</th>
            <td>{{ $trainingRequest->topicTrainee->topic->name }}</td>
        </tr>
        <tr>
            <th class="w-50 text-uppercase">Name of Training Service(s) @prettify(config('settings.aliases.trainer')):</th>
            <td>{{ $trainingRequest->trainer->trainable->name }}</td>
        </tr>
        <tr>
            <th class="w-50 text-uppercase">Duration of Training services (in hours)</th>
            <td>{{ $trainingRequest->duration  }}</td>
        </tr>
    </tbody>
</table>
