<label class="mb-2 fw-bold">
    @empty($show)
        Indicate whether the modules / activities listed below were beneficial or useful for your role?
        For each of the below, please provide a reason. If you indicated that you “disagree,” could you please
        also provide a suggestion on how to improve learning. If you indicated that you “agree,” please indicate how
        it has helped your business.
    @else
        Here, you indicated whether the modules / activities listed below were beneficial or useful for your role.
        For each of the below, you provided a reason for your choice. 
    @endempty
</label>
<table class="table">
    <thead class="text-uppercase fw-bold">
        <tr>
            <th scope="col">Section</th>
            @foreach ($scales as $scale)
                <th scope="col" class="text-center">
                    @prettify($scale)
                </th>
            @endforeach
            <th>Reason</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($modules as $module)
            <tr>
                <td class="@error("modules.$module->id.scale") border border-danger @enderror">
                    {{ $module->name }} <br>
                    @error("modules.$module->id.scale") 
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </td>
                @foreach ($scales as $scale)
                    <td>
                        <div class="form-check text-center d-flex">
                            <input class="form-check-input mx-auto" type="radio" id="modules_{{ $module->id }}_scale" name="modules[{{ $module->id }}][scale]" value="{{ strtoupper($scale) }}" @if((old("modules.$module->id.scale") ?? ($evaluation->saved_ratings[$module->id]['value'] ?? null)) == strtoupper($scale)) checked @endif @isset($show) disabled @endisset required>
                        </div>
                    </td>
                @endforeach
                <td>
                    @isset($show)
                        {{ $evaluation->saved_ratings[$module->id]['description'] ?? null }}
                    @else
                        <textarea class="form-control @error("modules.$module->id.reason") is-invalid @enderror" name="modules[{{ $module->id }}][reason]" placeholder="The reason for your rating" required>{{ old("modules.$module->id.reason") ?? ($evaluation->saved_ratings[$module->id]['description'] ?? ( app()->environment('local') ? 'Sample Value '.$loop->iteration : '')) }}</textarea>
                        @error("modules.$module->id.reason")
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    @endisset
                </td>
            </tr>
        @endforeach
    </tbody>
</table>