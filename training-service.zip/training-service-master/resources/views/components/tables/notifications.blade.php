@if($notifications->isNotEmpty())
    @once
        @push('actions')
        <div class="d-flex">
            <form action="{{ route("$routePrefix.mark", [ 'status' => 'read' ]) }}" method="POST">
                @csrf @method('PATCH')
                <button class="btn btn-primary btn-sm me-1" type="submit">
                    Mark all as read
                </button>
            </form>
            <form action="{{ route("$routePrefix.mark", [ 'status' => 'unread' ]) }}" method="POST">
                @csrf @method('PATCH')
                <button class="btn btn-primary btn-sm" type="submit">
                    Mark all as unread
                </button>
            </form>
        </div>
        @endpush
    @endonce
@endif

<table class="table table-sm no-stripes no-borders">
    <thead>
        <tr>
            <th>Time</th>
            <th>Notification</th>
            <th class="text-center">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($notifications as $notification)
            <tr class="{{ $notification->unread() ? 'unread-notification' : '' }}">
                <td class="fw-bold">@dateforhumans($notification->created_at)</td>
                <td class="w-75">
                    {!! $notification->data['body']['message'] !!}
                </td>
                <td class="text-center">
                    @can('view_notifications')
                        <a href="{{ route("$routePrefix.action", [ 'notification' => $notification ]) }}" class="btn btn-sm btn-primary">
                            <i class="fas fa-eye"></i>
                        </a>
                    @endcan                                        
                </td>                                    
            </tr>
        @endforeach
    </tbody>
</table>