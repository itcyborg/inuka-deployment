<table class="table no-stripes">
    <tbody>
        <tr>
            <th class="w-25">SOW Number</th>
            <td>{{ $sow->sow_no }}</td>
        </tr>
        <tr>
            <th class="w-25">Contract Reference Number</th>
            <td>{{ $sow->contract_no }}</td>
        </tr>
        <tr>
            <th class="w-25">@prettify(config('settings.aliases.trainer')) Name</th>
            <td>{{ $trainer->trainable->name }}</td>
        </tr>
        <tr>
            <th class="w-25">@prettify(config('settings.aliases.trainee')) Name</th>
            <td>{{ $trainee->trainable->name }}</td>
        </tr>
        <tr>
            <th class="w-25">Engagement Title</th>
            <td>
                {{ $topic->name }} within {{ $topic->area->name }} under {{ $topic->area->service->name }}.
            </td>
        </tr>
        <tr>
            <th class="w-25">Period of Perfomance</th>
            <td>
                @date($sow->commencement_date) to @date($sow->termination_date) ({{ $sow->duration }} Days)
            </td>
        </tr>
        <tr>
            <th class="w-25">Scope of Work</th>
            <td>
                
                Under this Statement of Work, the trainee, <strong>{{ $trainer->trainable->name }}</strong>, will provide training in the <strong>{{ $topic->area->name }}</strong> category. In particular, the @prettify(config('settings.aliases.trainer')) will cover the topic <strong>{{ $topic->name }}</strong> and will focus on <strong>{{ $topic->area->service->name }}</strong>. The training is structured into <strong>{{ $modules->count() }}</strong> modules.
            </td>
        </tr>
        <tr>
            <th class="w-25">The Modules</th>
            <td class="p-0">
                <table class="table no-borders no-stripes">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Module Name</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Duration</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($modules as $module)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $module->name }}</td>
                                <td>@datetime($module->start_date)</td>
                                <td>@datetime($module->end_date)</td>
                                <td>{{ $module->duration }} Hours</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <th class="w-25">Deliverables</th>
            <td>
                {{ $sow->deliverables }}
            </td>
        </tr>
        <tr>
            <th class="w-25">Level of Effort</th>
            <td>
                {{ $sow->effort_level }} {{ $sow->effort_level_unit }}
            </td>
        </tr>
        <tr>
            <th class="w-25">Fee Arrangement</th>
            <td>
                {{ $sow->fee_arrangement }}
            </td>
        </tr>
        <tr>
            <th class="w-25">TSP Approval Signature</th>
            <td class="p-0">
                @if($sow->hasManagerSigned())
                    <table class="table no-stripes no-borders">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Date of Signature</th>
                                <th class="text-center w-25">Signature</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>{{ $sow->manager->name }}</th>
                                <th>@datetime($sow->manager_signature_date)</th>
                                <th class="text-center w-25">
                                    @if($sow->managerSignatureIsValid())
                                        <img src="{{ asset('img/sows/verified-manager.png') }}" alt="{{ $sow->manager_signature }}" class="img-fluid signature">
                                    @else
                                        <h6 class="text-danger">Invalid Signature: Unauthorised Modification of SoW Data</h3>
                                    @endif
                                </th>
                            </tr>
                        </tbody>
                    </table>
                @else
                    <div class="px-4 py-3">
                        <span class="text-danger fw-bold">This SOW has not been signed by the Training Services Provider</span>
                        @can('sign', [ $sow, 'manager' ])
                            <form class="my-1" method="POST" action="{{ route('portal.managers.sows.sign', ['sow' => $sow]) }}">
                                @csrf
                                <button type="submit" class="btn btn-primary btn-sm">
                                    Accept and Sign as a Training Services Provider
                                </button>
                            </form>                            
                        @endcan
                    </div>
                @endif
            </td>
        </tr>
        <tr>
            <th class="w-25">@prettify(config('settings.aliases.trainer')) Acknowledgement Signature</th>
            <td class="p-0">
                @if($sow->hasTrainerSigned())
                    <table class="table no-stripes no-borders">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Date of Signature</th>
                                <th class="w-25 text-center">Signature</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>{{ $sow->trainer->name }}</th>
                                <th>@datetime($sow->trainer_signature_date)</th>
                                <th class="w-25 text-center">
                                    @if($sow->trainerSignatureIsValid())
                                        <img src="{{ asset('img/sows/verified-trainer.png') }}" alt="{{ $sow->trainer_signature }}" class="img-fluid signature">
                                    @else
                                        <h6 class="text-danger">Invalid Signature: Unauthorised Modification of SoW Data</h6>
                                    @endif
                                </th>
                            </tr>
                        </tbody>
                    </table>
                @else
                    <div class="px-4 py-3">
                        <span class="text-danger fw-bold">This SOW has not been signed by the @prettify(config('settings.aliases.trainer'))</span>
                        @can('sign', [ $sow, 'trainer' ])
                            <form class="my-1" method="POST" action="{{ route('portal.trainers.sows.sign', ['sow' => $sow]) }}">
                                @csrf
                                <button type="submit" class="btn btn-primary btn-sm">
                                    Accept and Sign as a @prettify(config('settings.aliases.trainer'))
                                </button>
                            </form>  
                        @endcan
                    </div>
                @endif
            </td>
        </tr>
    </tbody>
</table>