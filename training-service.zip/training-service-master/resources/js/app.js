/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

//  Include the bootstraping js file
require('./bootstrap');

//  Include the guest js file
require('./guest');

//  Include the portal js file
require('./portal');

//  Include the master js file
require('./master');