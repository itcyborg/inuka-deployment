/**
 * ------------------------------------------------------------------------
 * Handle toggling of sidebar navigation
 * ------------------------------------------------------------------------
 */
const sidebar = document.getElementById('sidebar-toggle');
if(sidebar) {
    sidebar.onclick = () => {
        const body = document.getElementsByTagName('body')[0];
          body.classList.toggle('sidebar-toggled');
    };
}


/**
 * ------------------------------------------------------------------------
 * Handle the display of tooltips
 * ------------------------------------------------------------------------
 */
const tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-tooltip="tooltip"]'),
).map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl, {
        boundary: 'window'
    }),
);

/**
 * ------------------------------------------------------------------------
 * Handle change of range slider values
 * ------------------------------------------------------------------------
 */
window.updateCount = (element) => {
    //  Get the closest slider count element
    const countContainer = element
        .closest('div.range-container')
        .querySelector('div.slider-count .badge');

    //  Set the inner html value of the count container
    countContainer.innerHTML = element.value;
}
