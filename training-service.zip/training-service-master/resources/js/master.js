/**
 * ------------------------------------------------------------------------
 * Handle the display of toasts
 * ------------------------------------------------------------------------
 */
const toastElList = [].slice.call(document.querySelectorAll('.toast'))
    .map((toastEl) => new bootstrap.Toast(toastEl).show());
