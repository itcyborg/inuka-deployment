<?php

namespace Database\Factories;

use App\Models\Organization;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrganizationFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Organization::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'public_id' => $this->faker->unique()->randomNumber(6),
            'county_id' => $this->faker->numberBetween(1, 47),
            'name' => $this->faker->name(),
            'email' => $this->faker->unique()->safeEmail,
            'telephone' => $this->faker->unique()->e164PhoneNumber,
            'locality' => $this->faker->streetName,
        ];
    }
}
