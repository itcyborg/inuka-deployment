<?php

namespace Database\Factories;

use App\Models\Qualification;
use Illuminate\Database\Eloquent\Factories\Factory;

class QualificationFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Qualification::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'certification' => $this->faker->randomElement([
                'CISCO', 'CPA', 'CISA', 'CCNA', 'CCNP', 'PMP'
            ]),
            'institution' => $this->faker->randomElement([
                'University of Nairobi', 'Strathmore University', 
                'Daystar university', 'KCA University', 'Kenya Methodist University'
            ]),
            'location' => $this->faker->randomElement([
                'Buruburu, Nairobi', 
                'Umoja, Nairobi',
                'Bombolulu, Mombasa',
                'Miritini, Mombasa',
                'Karen, Nairobi'
            ]),
            'year' => $this->faker->numberBetween(2010, 2019),
        ];
    }
}
