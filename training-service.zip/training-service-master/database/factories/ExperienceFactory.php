<?php

namespace Database\Factories;

use App\Models\Experience;
use Illuminate\Database\Eloquent\Factories\Factory;

class ExperienceFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Experience::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'description' => $this->faker->text,
            'start_year' => $startDate = $this->faker->numberBetween(2010, 2019),
            'end_year' => $startDate + 1,
            'location' => $this->faker->randomElement([
                'Buruburu, Nairobi',
                'Umoja, Nairobi',
                'Bombolulu, Mombasa',
                'Miritini, Mombasa',
                'Karen, Nairobi',
                'Kasarani, Nairobi'
            ])
        ];
    }
}
