<?php

use App\Models\County;
use App\Models\Organization;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->tinyInteger('staff_id');
            $table->string('username');
            $table->string('name');
            $table->string('email')->unique();
            $table->string('telephone')->unique();
            $table->tinyInteger('branch')->nullable();
            $table->string('password')->nullable();
            $table->string('mpassword')->nullable();
            $table->tinyInteger('twofa')->nullable();
            $table->string('twofa_secret')->nullable();
            $table->string('api_name')->nullable();
            $table->string('api_key')->nullable();
            $table->tinyInteger('type')->nullable();
            $table->tinyInteger('active')->default(1);
            $table->text('notes')->nullable();
            $table->tinyInteger('reset')->default(0);
            $table->tinyInteger('deleted')->default(0);
            $table->string('default_system')->nullable();
            $table->string('allowed_systems')->nullable();
            $table->string('roles')->nullable();
            $table->enum('gender', config('settings.user.genders'));
            $table->string('locality')->nullable();
            $table->enum('status', config('settings.user.status'))->default('ACTIVE');
            $table->foreignIdFor(Organization::class)->nullable()->constrained();
            $table->foreignIdFor(County::class)->nullable()->constrained();
            $table->timestamp('email_verified_at')->nullable();
            $table->rememberToken();
            $table->timestamps();

            // $table->id();
            // $table->uuid('uuid')->unique();
            // $table->foreignIdFor(Organization::class)->nullable()->constrained();
            // $table->foreignIdFor(County::class)->nullable()->constrained();
            // $table->string('name');
            // $table->string('email')->unique();
            // $table->string('telephone')->unique();
            // $table->timestamp('email_verified_at')->nullable();
            // $table->string('password')->nullable();
            // $table->enum('gender', config('settings.user.genders'));
            // $table->string('locality')->nullable();
            // $table->enum('status', config('settings.user.status'))->default('ACTIVE');
            // $table->rememberToken();
            // $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
