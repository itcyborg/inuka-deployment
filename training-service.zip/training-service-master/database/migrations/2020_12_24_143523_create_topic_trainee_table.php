<?php

use App\Models\Topic;
use App\Models\Trainee;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTopicTraineeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function up()
    {
        Schema::create('topic_trainee', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(Topic::class)->constrained()->onDelete('cascade');
            $table->foreignIdFor(Trainee::class)->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('topic_trainee');
    }
}
