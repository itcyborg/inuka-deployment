<?php

use App\Models\Trainee;
use App\Models\Trainer;
use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSowsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sows', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignIdFor(TrainingRequest::class)->constrained();
            $table->foreignId('manager_id')->nullable()->constrained('users');
            $table->foreignId('trainer_id')->nullable()->constrained('users');

            $table->string('contract_no')->unique();
            $table->string('sow_no')->unique();
            $table->double('fee');
            $table->text('fee_arrangement');
            $table->float('effort_level', 8, 2);
            $table->string('effort_level_unit');
            $table->text('deliverables');

            $table->date('sow_date');
            $table->date('commencement_date');
            $table->date('termination_date');

            $table->text('trainer_signature')->nullable();
            $table->timestamp('trainer_signature_date')->nullable();
            $table->text('manager_signature')->nullable();
            $table->timestamp('manager_signature_date')->nullable();
            $table->boolean('is_valid')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sows');
    }
}
