<?php

use App\Models\County;
use App\Models\Organization;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTrainersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function up()
    {
        Schema::create('trainers', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->morphs('trainable');
            $table->string('bio', 1000);
            $table->string('website');
            $table->float('rating', 12, 8)->nullable();
            $table->float('pre_qualification_rating', 12, 8)->nullable();
            $table->enum('status', config('settings.trainer.status'))->default('AWAITING_PREQUALIFICATION');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('trainers');
    }
}
