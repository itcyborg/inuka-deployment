<?php

use App\Models\TopicTrainee;
use App\Models\Trainer;
use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTrainingRequestsTable extends Migration
{
    /**
     * Run the migrations.
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     *
     * @return void
     */
    public function up()
    {
        Schema::create('training_requests', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('topic_trainee_id')->constrained('topic_trainee');
            $table->foreignIdFor(Trainer::class)->constrained();
            $table->foreignIdFor(User::class, 'manager_id')->constrained('users');
            $table->timestamp('approved_at')->nullable();
            $table->timestamp('responded_at')->nullable();
            $table->enum('status', array_merge(
                config('settings.training_request.status.requests'),
                config('settings.training_request.status.provisions')
            ))->default('AWAITING_PUBLISHING');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('training_requests');
    }
}
