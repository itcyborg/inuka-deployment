<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //  Call the various seeders
        $this->call(PermissionSeeder::class);
        $this->call(SettingSeeder::class);
        $this->call(CountrySeeder::class);
        $this->call(UserSeeder::class);
        // $this->call(ServiceSeeder::class);
        // $this->call(TrainerSeeder::class);
        // $this->call(TraineeSeeder::class);
        // $this->call(ModuleTemplateSeeder::class);
        // $this->call(TrainingRequestSeeder::class);
        // $this->call(RatingParameterSeeder::class);
        // $this->call(CommentSeeder::class);
    }
}
