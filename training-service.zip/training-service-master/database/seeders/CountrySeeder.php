<?php

namespace Database\Seeders;

use App\Models\Country;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;

class CountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Get the countries.
        $countries = json_decode(file_get_contents(
            database_path('data/json/countries.json')
        ));

        //  Loop through each of the countries
        foreach ($countries as $country) {
            //  Get the counties
            $counties = $country->counties;
            $country = Country::create([
                'name' => $country->name,
                'uuid' => (string) Str::uuid()
            ]);

            //  Get the counties that belong to the county
            foreach ($counties as $county) {
                $country->counties()->create([
                    'name' => $county,
                    'uuid' => (string) Str::uuid()
                ]);
            }
        }
    }
}
