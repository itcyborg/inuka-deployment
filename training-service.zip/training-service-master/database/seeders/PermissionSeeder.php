<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        //  Get the predefined roles and permissions from the included .json file
        $roles = json_decode(file_get_contents(database_path('data/json/permissions.json')));

        //  Loop through the .json object and get each key value pair.
        //  For the first level, the key is the role name and the value is an object of roles.
        foreach ($roles as $name => $models) {
            //  Create a new role
            $role = Role::updateOrCreate(['name' => $name]);

            //  Loop through all the models
            foreach($models as $model => $permissions) {
                //  Create permissions
                foreach ($permissions as $permission) {
                    //  Create or update a permission
                    $permission = Permission::updateOrCreate([
                        'name' => $permission,
                        'model_name' => $model
                    ]);

                    //  Assign the permission to the role
                    $role->givePermissionTo($permission);
                }
            }
        }
    }
}
