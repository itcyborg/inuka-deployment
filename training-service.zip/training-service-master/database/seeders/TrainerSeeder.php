<?php

namespace Database\Seeders;

use App\Models\Experience;
use App\Models\Language;
use App\Models\Organization;
use App\Models\Qualification;
use App\Models\Topic;
use App\Models\Trainer;
use App\Models\Upload;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class TrainerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Clean the public directory
        File::cleanDirectory('storage/app/public');
        Storage::makeDirectory('public/files');

        //  Get the trainers.
        $trainers = json_decode(file_get_contents(
            database_path('data/json/trainers.json')
        ));

        //  Get all trainers
        foreach($trainers as $curTrainer) {
            //  Determine if the organization is defined
            $organization = $curTrainer->organization ?? null;
            if($organization) {
                $organization = Organization::factory()->create((array) $organization);
            }

            //  Create a user
            $user = Arr::except((array) $curTrainer->user, ['roles', 'trainer_status']);
            $user = User::factory()->create(array_merge($user, [
                'organization_id' => $organization->id ?? null,
                'roles' => "6",
            ]));

            //  Assign Default Permissions
            $user->assignDefaultPermissions((array) $curTrainer->user->roles);

            //  Create a trainer
            $trainer = Trainer::factory()->create([
                'trainable_id' => $user->id,
                'trainable_type' => 'users',
                'status' => $curTrainer->user->trainer_status,
            ]);

            //  Add topics to the trainer profile
            $topics = Topic::whereIn('name', (array) $curTrainer->topics)->get();
            $trainer->topics()->sync( $topics->pluck('id')->toArray() );

            //  Create languagues that belong to a trainer
            Language::factory()->count(2)->create([
                'trainer_id' => $trainer->id
            ]);

            //  Create Experiences that belong to a trainer
            Experience::factory()->count(3)->create([
                'trainer_id' => $trainer->id
            ]);

            //  Create Qualification that belong to a trainer
            Qualification::factory()->count(3)->create([
                'trainer_id' => $trainer->id
            ]);

            //  Create Qualification that belong to a trainer
            Upload::factory()->create([
                'uploadable_id' => $trainer->id,
                'uploadable_type' => 'trainers',
                'user_id' => $user->id,
                'name' => 'My Resume',
                'type' => 'resume'
            ]);
        }
    }
}
