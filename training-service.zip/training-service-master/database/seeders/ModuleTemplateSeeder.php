<?php

namespace Database\Seeders;

use App\Models\ModuleTemplate;
use Illuminate\Database\Seeder;

class ModuleTemplateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Get the countries.
        $modules = json_decode(file_get_contents(
            database_path('data/json/module-templates.json')
        ));

        //  Create each module
        foreach($modules as $module) {
            ModuleTemplate::create((array) $module);
        }
    }
}
