<?php

namespace Database\Seeders;

use App\Models\Service;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;

class ServiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Get the services from the included .json file
        $services = json_decode(file_get_contents(
            database_path('data/json/services.json')
        ));

        //  Loop through all the services
        foreach ($services as $currService) {
            //  Create a service
            $service = Service::create([
                'name' => $currService->name,
            ]);

            //  Create areas
            foreach ($currService->areas as $currArea) {
                $area = $service->areas()->create([
                    'name' => $currArea->name,
                ]);

                //  Create topics
                foreach ($currArea->topics as $topic) {
                    $area->topics()->create([
                        'name' => $topic,
                    ]);
                }
            }
        }
    }
}
