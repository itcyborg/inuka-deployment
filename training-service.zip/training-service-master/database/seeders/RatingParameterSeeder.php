<?php

namespace Database\Seeders;

use App\Models\RatingParameter;
use Illuminate\Database\Seeder;

class RatingParameterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Get the rating parameters from the included .json file
        $ratingParameters = json_decode(file_get_contents(
            database_path('data/json/rating-parameters.json')
        ));

        //  Loop through all the ratingParameters
        foreach ($ratingParameters as $parameter) {
            //  Create a rating parameter
            $ratingParameter = RatingParameter::create((array) $parameter);
        }
    }
}
