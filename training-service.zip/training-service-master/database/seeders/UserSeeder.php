<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::transaction(function(){
            //  Create Inuka Africa admin user
            $user = User::create([
                'staff_id' => 1141,
                'username' => 'Daniel Muli',
                'name' => 'HRM Developer',
                'email' => 'hrmis@gmail.com',
                'telephone' => '0725465570',
                'branch' => 1,
                'mpassword' => '',
                'twofa' => 'YRFZCKUJYPVUE2UZ',
                'twofa_secret' => '',
                'api_name' => '',
                'api_key' => '',
                'type' => 2,
                'active' => 1,
                'notes' => 'Inuka Admin',
                'reset' => 0,
                'deleted' => 0,
                'default_system' => 'hrmdev',
                'allowed_systems' => 'hrmdev',
                'email_verified_at' => now(),
                'password' => Hash::make('password'),
                'status' => 'ACTIVE',
                'roles' => "1",
            ])->assignDefaultPermissions('manager_key_user');
        });
    }
}
