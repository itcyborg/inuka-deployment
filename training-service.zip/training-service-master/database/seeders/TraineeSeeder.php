<?php

namespace Database\Seeders;

use App\Models\Organization;
use App\Models\Topic;
use App\Models\Trainee;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Arr;

class TraineeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Get the trainees.
        $trainees = json_decode(file_get_contents(
            database_path('data/json/trainees.json')
        ));

        //  Loop through all trainees
        foreach($trainees as $curTrainee) {
            //  Create the organization
            $organization = Arr::except((array) $curTrainee->organization, ['trainee_status']);
            $organization = Organization::factory()->create($organization);
            
            //  Create a bunch of users
            foreach($curTrainee->users as $curUser) {
                //  Create a user
                $user = Arr::except((array) $curUser, ['roles', 'trainee_status']);
                $user = User::factory()->create(array_merge($user, [
                    'organization_id' => $organization->id,
                    'roles' => "8"
                ]));

                //  Assign Default Permissions
                $user->assignDefaultPermissions((array) $curUser->roles);
            }

            //  Create a trainee
            $trainee = Trainee::factory()->create([
                'trainable_id' => $organization->id,
                'trainable_type' => 'organizations',
                'status' => $curTrainee->organization->trainee_status
            ]);

            //  Add topics to the trainee profile
            $topics = Topic::whereIn('name', (array) $curTrainee->topics)->get();
            $trainee->topics()->sync($topics->pluck('id')->toArray());
        }
    }
}