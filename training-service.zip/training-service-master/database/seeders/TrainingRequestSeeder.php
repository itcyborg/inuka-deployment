<?php

namespace Database\Seeders;

use App\Models\Organization;
use App\Models\Topic;
use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Database\Seeder;

class TrainingRequestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Get the training requests.
        $trainingRequests = json_decode(file_get_contents(
            database_path('data/json/training-requests.json')
        ));

        //  Loop through all training requests
        foreach($trainingRequests as $trainingRequest) {
            //  Get the topic
            $topic = Topic::where('name', $trainingRequest->topic)->first();
            $trainer = User::where('name', $trainingRequest->trainer)->first()->trainer;
            $trainee = Organization::where('name', $trainingRequest->trainee)->first()->trainee;
            $manager = User::where('name', $trainingRequest->manager)->first();

            //  Get the topic trainee record from the pivot table
            $pivot = $trainee->topicTrainees()->where('topic_id', $topic->id)->firstOrFail();

            //  Create a training request
            $trainingRequest = TrainingRequest::create([
                'topic_trainee_id' => $pivot->id, 
                'trainer_id' => $trainer->id,
                'status' => $trainingRequest->status,
                'manager_id' => $manager->id, 
            ]);
    
            //  Inherit workplan from basic template
            $trainingRequest->inheritWorkplanFromTemplate(); 
        }
    }
}
