(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["/js/portal"],{

/***/ "./resources/js/portal.js":
/*!********************************!*\
  !*** ./resources/js/portal.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * ------------------------------------------------------------------------
 * Handle the display of toasts
 * ------------------------------------------------------------------------
 */
var toastElList = [].slice.call(document.querySelectorAll('.toast')); // eslint-disable-next-line no-undef

toastElList.map(function (toastEl) {
  return new bootstrap.Toast(toastEl).show();
});
/**
 * ------------------------------------------------------------------------
 * Handle toggling of sidebar navigation
 * ------------------------------------------------------------------------
 */

document.getElementById('sidebar-toggle').onclick = function () {
  var body = document.getElementsByTagName('body')[0];
  body.classList.toggle('sidebar-toggled');
};
/**
 * ------------------------------------------------------------------------
 * Handle the display of tooltips
 * ------------------------------------------------------------------------
 */


var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
tooltipTriggerList.map( // eslint-disable-next-line no-undef
function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl);
});

/***/ }),

/***/ 3:
/*!**************************************!*\
  !*** multi ./resources/js/portal.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\Gichira Kaburu\Documents\Amprest\Dev\tmp\resources\js\portal.js */"./resources/js/portal.js");


/***/ })

},[[3,"/js/manifest"]]]);
//# sourceMappingURL=portal.js.map