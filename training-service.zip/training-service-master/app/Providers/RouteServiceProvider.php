<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * This is used by Laravel authentication to redirect users after login.
     *
     * @var string
     */
    public const HOME = '/portal';

    /**
     * The controller namespace for the application.
     *
     * When present, controller route declarations will automatically be prefixed with this namespace.
     *
     * @var string|null
     */
    // protected $namespace = 'App\\Http\\Controllers';

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @return void
     */
    public function boot()
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::prefix('api')
                ->middleware(['api', 'auth:sanctum'])
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->group(base_path('routes/web.php'));

            Route::name('portal.')
                ->prefix('portal')
                ->middleware(['web', 'auth', 'verified'])
                ->group(base_path('routes/portal.php'));

            Route::name('portal.managers.')
                ->prefix('managers')
                ->middleware(['web', 'auth', 'verified', 'permission:view_manager_portal', 'unauthorized'])
                ->group(base_path('routes/manager.php'));

            Route::name('portal.trainers.')
                ->prefix('trainers')
                ->middleware(['web', 'auth', 'verified', 'permission:view_trainer_portal', 'unauthorized'])
                ->group(base_path('routes/trainer.php'));

            Route::name('portal.trainees.')
                ->prefix('trainees')
                ->middleware(['web', 'auth', 'verified', 'permission:view_trainee_portal', 'unauthorized'])
                ->group(base_path('routes/trainee.php'));
        });
    }

    /**
     * Configure the rate limiters for the application.
     *
     * @return void
     */
    protected function configureRateLimiting()
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by(optional($request->user())->id ?: $request->ip());
        });
    }
}
