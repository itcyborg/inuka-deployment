<?php

namespace App\Providers;

use App\Models\ModuleTemplate;
use App\Models\Organization;
use App\Models\Evaluation;
use App\Models\RatingParameter;
use App\Models\Trainee;
use App\Models\Trainer;
use App\Models\TrainingRequest;
use App\Models\User;
use App\Models\WorkPlanModule;
use App\Services\DashboardService;
use App\Services\SettingService;
use App\Services\ValidationService;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //  Register the dashboard service
        $this->app->singleton(DashboardService::class, function ($app) {
            return new DashboardService;
        });

        //  Register the settings service
        $this->app->bind(SettingService::class, function ($app) {
            return new SettingService;
        });

        //  Register the validation service
        $this->app->singleton(ValidationService::class, function ($app) {
            return new ValidationService;
        });
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        //  Define the morph map
        Relation::morphMap([
            'organizations' => Organization::class,
            'trainers' => Trainer::class,
            'trainees' => Trainee::class,
            'users' => User::class,
            'module-templates' => ModuleTemplate::class,
            'work_plan_module' => WorkPlanModule::class,
            'training_requests' =>TrainingRequest::class,
            'evaluations' => Evaluation::class,
            'rating-parameters' => RatingParameter::class
        ]);

        //  Use bootstrap paginator
        Paginator::useBootstrap();
    }
}
