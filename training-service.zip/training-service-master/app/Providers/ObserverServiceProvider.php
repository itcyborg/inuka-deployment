<?php

namespace App\Providers;

use App\Models\SettingValue;
use App\Models\User;
use App\Observers\SettingValueObserver;
use App\Observers\UserObserver;
use Illuminate\Support\ServiceProvider;

class ObserverServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        User::observe(UserObserver::class);
        SettingValue::observe(SettingValueObserver::class);
    }
}
