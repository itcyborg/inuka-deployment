<?php

namespace App\Providers;

use App\View\Composers\NotificationComposer;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //  Register composers
        View::composer('*', NotificationComposer::class);

        //  Format strings to currency
        Blade::directive('currency', function ($expression) {
            return "<?php echo currency($expression); ?>";
        });

        //  Format strings with underscores into perfect strings
        Blade::directive('prettify', function ($expression) {
            return "<?php echo prettify($expression); ?>";
        });

        //  Format date
        Blade::directive('date', function ($expression) {
            return "<?php echo format_date($expression); ?>";
        });

        //  Format date time
        Blade::directive('datetime', function ($expression) {
            return "<?php echo format_date_time($expression); ?>";
        });

        //  Format date time
        Blade::directive('dateforhumans', function ($expression) {
            return "<?php echo format_humans($expression); ?>";
        });

        //  Format numbers
        Blade::directive('numeric', function ($expression) {
            return "<?php
                echo numeric($expression);
            ?>";
        });

        //  Define the bag directive
        Blade::directive('bag', function ($expression) {
            return "<?php
                echo bag($expression);
            ?>";
        });
    }
}
