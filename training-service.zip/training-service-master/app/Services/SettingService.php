<?php

namespace App\Services;

use App\Models\Setting;

class SettingService
{
    /**
     * This is the key that will be used to search the settings.
     *
     * @var
     */
    public $settings;

    /**
     * Initialize the setting class
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function __construct()
    {
        $this->settings = Setting::cache();
    }

    /**
     * Get the setting values for a certain setting from the
     * database
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function get(string $key)
    {
        //  Get only one setting
        $setting = $this->settings->where('key', $key)->first();

        //  If no setting has been defined return null
        if(!$setting) return null;

        //  Get the setting values
        $values = $setting->values;

        //   Detect if the setting is a multiple or single setting
        return $setting->isType('single')
            ? $values->first()->name ?? null
            : $values->pluck('name')->toArray();
    }
}
