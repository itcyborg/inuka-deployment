<?php

namespace App\Services;

use App\Models\ModuleTemplate;
use App\Models\Service;
use App\Models\Topic;
use App\Models\Trainee;
use App\Models\Trainer;
use App\Models\TrainingRequest;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;

class DashboardService
{
    /**
     * Return manager dashboard data
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getManagerData(): array
    {
        //  Get a list of trainers and trainees
        $trainers = Trainer::with('trainable')->get();
        $trainees = Trainee::with('trainable')->get();

        //  Get a list of sevices, topics and modules
        $services = Service::all();
        $topics = Topic::all();
        $modules = ModuleTemplate::all();

        //  Lazy load training request data
        $trainingRequests = TrainingRequest::with([
            'topicTrainee.topic', 'topicTrainee.trainee.trainable',
            'trainer.trainable'
        ])->latest()->get();

        //  Return the payload
        return [
            'trainers' => $trainers,
            'trainees' => $trainees,
            'topics' => $topics,
            'modules' => $modules,
            'services' => $services,
            'trainingRequests' => $this->getTrainingRequestData($trainingRequests),
        ];
    }

    /**
     * Return trainer dashboard data
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainerData(): array
    {
        //  Get the authenticated user
        $user = Auth::user();

        $trainer = $user->getTrainerProfile();

        //  Get topics that belong to a trainer
        $topics = $trainer->topics;

        //  Lazy load training request data
        $trainingRequests = $trainer->trainingRequests()->with([
            'topicTrainee.topic', 'topicTrainee.trainee.trainable',
            'trainer.trainable'
        ])->latest()
            ->whereNotIn('status', config('settings.training_request.status.exclude.trainer'))
            ->get();

        //  Return the payload
        return [
            'topics' => $topics,
            'trainingRequests' => $this->getTrainingRequestData($trainingRequests),
        ];
    }

    /**
     * Return trainee dashboard data
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTraineeData(): array
    {
        //  Get the authenticated user
        $user = Auth::user();
        $trainee = $user->getTraineeProfile();

        //  Get topics that belong to a trainee
        $topics = $trainee->topics;

        //  Lazy load training request data
        $trainingRequests = $trainee->trainingRequests()->with([
            'topicTrainee.topic', 'topicTrainee.trainee.trainable',
            'trainer.trainable'
        ])->latest()
            ->whereNotIn('status', config('settings.training_request.status.exclude.trainee'))
            ->get();

        //  Return the payload
        return [
            'topics' => $topics,
            'trainingRequests' => $this->getTrainingRequestData($trainingRequests),
        ];
    }

    /**
     * Return manager dashboard training request data
     *
     * @param Collection $trainingRequests
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainingRequestData(Collection $trainingRequests): array
    {
        //  Get all training requests
        $requests = $this->getTrainingRequests($trainingRequests);

        //  Get all training provisions
        $provisions = $this->getTrainingProvisions($trainingRequests);

        //  Generate training request chart payload
        $requestChartPayload = $this->getRequestChartPayload($requests);

        //  Generate training provision chart payload
        $provisionChartPayload = $this->getProvisionChartPayload($provisions);

        //  Return the unapproved, ongoing and completed stats
        $unapproved = $trainingRequests->where('status', 'AWAITING_TRAINER_APPROVAL');
        $ongoing = $trainingRequests->where('status', 'ONGOING');
        $completed = $trainingRequests->where('status', 'COMPLETED');
        $preEvaluation = $trainingRequests->where('status', 'AWAITING_PRE-TRAINING_EVALUATION');

        // To Avoid Divide by Zero Error (Unfortunately had to take the longest route possible until a better solution is found)

        // Create null value
        $newPreEvaluationValue = '';

        // check if provisions is empty
        if ($provisions->isNotEmpty()) {
            // check whether preevaluation count or requests' count returns 0
            if ($preEvaluation->count() == 0 || $requests->count() == 0) {
                // return 0
                $newPreEvaluationValue = 0;
            } else {
                // else carry out the division
                $preEvaluation->count() / $requests->count() * 100;
            }
        } else {
            $newPreEvaluationValue = 0;
        }

        //  Structure the training request array payload
        return [
            'all' => $trainingRequests,
            'requests' => $requests,
            'provisions' => $provisions,
            'unapproved' => $requests->isNotEmpty() ? ($unapproved->count() / $requests->count() * 100) : 0,
            'preEvaluation' => $newPreEvaluationValue,
            'ongoing' => $provisions->isNotEmpty() ? $ongoing->count() / $provisions->count() * 100 : 0,
            'completed' => $provisions->isNotEmpty() ? $completed->count() / $provisions->count() * 100 : 0,
            'charts' => [
                'requests' => [
                    'labels' => $requestChartPayload->pluck('status')->toArray(),
                    'data' => $requestChartPayload->pluck('count')->toArray(),
                    'colors' => $requestChartPayload->pluck('color')->toArray(),
                ],
                'provisions' => [
                    'labels' => $provisionChartPayload->pluck('status')->toArray(),
                    'data' => $provisionChartPayload->pluck('count')->toArray(),
                    'colors' => $provisionChartPayload->pluck('color')->toArray(),
                ],
            ]
        ];
    }

    /**
     * Return a list of all training requests from a collection
     *
     * @param Collection $trainingRequests
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainingRequests(Collection $trainingRequests): Collection
    {
        return $trainingRequests->filter(function($trainingRequest){
            return $trainingRequest->hasStatus( config('settings.training_request.status.requests') );
        });
    }

    /**
     * Return a list of all training requests from a collection
     *
     * @param Collection $trainingRequests
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainingProvisions(Collection $trainingRequests): Collection
    {
        return $trainingRequests->filter(function($trainingRequest){
            return $trainingRequest->hasStatus( config('settings.training_request.status.provisions') );
        });
    }

    /**
     * Return training requests structured in a chart js renderble way
     *
     * @param Collection $requests
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getRequestChartPayload(Collection $requests): Collection
    {
        //  Build request chart payload
        return $this->buildChartPayload($requests, 'request');
    }

    /**
     * Return training provisions structured in a chart js renderble way
     *
     * @param Collection $provisions
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getProvisionChartPayload(Collection $provisions): Collection
    {
        //  Build provision chart payload
        return $this->buildChartPayload($provisions, 'provision');
    }

    /**
     * Build chart payload
     *
     * @param Collection $trainingRequests
     * @param string $type
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function buildChartPayload(Collection $trainingRequests, string $type): Collection
    {
        return $this->groupTrainingRequestsBy($trainingRequests, 'status')
            ->map(function($trainingRequests, $status) use ($type){
                return [
                    'status' => prettify($status),
                    'count' => $trainingRequests->count(),
                    'color' => config("chart.colors.training_request.$type.$status")
                ];
            });
    }

    /**
     * Group training requests by a certain attribute
     *
     * @param Collection $requests
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function groupTrainingRequestsBy(Collection $trainingRequests, string $attribute)
    {
        //  Group the request payload by the attribute
        return $trainingRequests->groupBy(function($trainingRequest) use ($attribute){
            return $trainingRequest->getRawOriginal( $attribute );
        });
    }
}
