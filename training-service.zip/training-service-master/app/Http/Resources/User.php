<?php

namespace App\Http\Resources;

use App\Http\Resources\Organization as OrganizationResource;
use Illuminate\Http\Resources\Json\JsonResource;

class User extends JsonResource
{
    /**
     * Initialize var to store action
     *
     * @var string 
     */
    public string $action;

    /**
     * Create a new user resource instance
     *
     * @param mixed $resource
     * @param string $action
     * @return array
     */
    public function __construct($resource, string $action = '')
    {
        //  Pass the constructor instance to the parent
        parent::__construct($resource);

        //  Set the action
        $this->action = $action ?: 'created';
    }

    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        //  Load the user's organization and trainee data
        $this->load('organization');

        //  Build the payload
        return [
            'message' => trans("alerts.success.api.trainee.user.$this->action"),
            'data' => [
                'id' => $this->uuid,
                'name' => $this->name,
                'email' => $this->email,
                'created_at' => $this->created_at,
                'organization' => new OrganizationResource($this->organization)
            ]
        ];
    }
}
