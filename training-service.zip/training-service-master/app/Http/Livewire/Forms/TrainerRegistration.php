<?php

namespace App\Http\Livewire\Forms;

use App\Events\TrainerRegistered;
use App\Models\County;
use App\Models\Service;
use App\Models\Topic;
use App\Models\Trainer;
use App\Models\User;
use App\Services\ValidationService;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Livewire\Component;

class TrainerRegistration extends Component
{
    /**
     * The form's current step
     *
     * @var string
     */
    public string $step;

    /**
     * Varible stores title names
     *
     * @var array
     */
    public array $steps;

    /**
     * The form update
     *
     * @var bool
     */
    public bool $update = false;

    /**
     * Register the validation service
     *
     * @var
     */
    private ?ValidationService $validations = null;

    /**
     * The object to store the new user
     *
     * @var User
     */
    public User $user;

    /**
     * The object to store the new trainer
     *
     * @var Trainer
     */
    public ?Trainer $trainer = null;

    /**
     * Get all genders
     *
     * @var array
     */
    public array $genders;

    /**
     * Get all counties
     *
     * @var Collection
     */
    public Collection $counties;

    /**
     * Get all languages
     *
     * @var array
     */
    public array $languages;

    /**
     * Get all services
     *
     * @var Collection
     */
    public Collection $services;

    /**
     * Modify the validation attributes
     *
     * @var array
     */
    protected $validationAttributes = [
        'passkey' => 'password'
    ];

    /**
     * Modify the messages
     *
     * @var array
     */
    protected $messages = [
        'trainer.topics.required' => 'Please provide your areas of expertise.',
    ];

    /**
     * Mount the component
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function mount()
    {
        //  Determine if the form is an update form
        $this->update = (bool) $this->trainer;

        //  Define the steps to be used
        $this->setNavigationSteps();

        //  Get the current step
        $this->step = $this->getStep();

        //  Get the basic trainer bio data
        $this->user = $this->getUserData();

        //  Get the trainer's professional information
        $this->trainer = $this->getTrainerData();

        //  Get the genders
        $this->genders = config('settings.user.genders');

        //  Get the counties
        $this->counties = County::oldest('name')->get();

        //  Get the supported languages
        $this->languages = config('settings.languages');

        //  Get the services
        $this->services = Service::with('areas.topics')->get();
    }

    /**
     * Register an updated hook
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function updated($propertyName)
    {
        if(!in_array($propertyName, ['user.passkey'])) {
            $this->validateOnly($propertyName);
        }
    }

    /**
     * Return the validation rules
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function rules(): array
    {
        //  Get the validation rules from the validation service
        $this->validations = new ValidationService;

        //  Get the user rules
        $user = $this->update ? $this->trainer->trainable : null;
        $userRules = $this->validations->user('user.', $user);
        $userRules = array_merge($userRules, $this->update ? [] : [
            'user.passkey' => $userRules['user.password'],
            'user.passkey_confirmation' => ['string'],
        ]);

        //  Get the trainer rules
        $trainerRules = array_merge($this->validations->trainer('trainer.'), [
            'trainer.curr_topics' => ['array', 'required'],
            'trainer.curr_languages' => ['array', 'required'],
        ]);

        //  Merge all validations
        $rules = array_merge($userRules,  $trainerRules);

        //  Refine and return the rules
        return Arr::except($rules, [
            'user.password', 'user.password_confirmation'
        ]);
    }

    /**
     * Define the steps to be navigated in the form
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function setNavigationSteps(): void
    {
        //  Set the steps
        $steps = [
            'general' => [
                'title' => 'Account Information',
                'description' => 'Tell us a bit about yourself',
                'progress' => 25,
                'icon' => 'fas fa-user',
            ],
            'professional' => [
                'title' => 'Professional Information',
                'description' => 'Provide information about your skill set and qualifications',
                'progress' => 50,
                'icon' => 'fas fa-user-tie'
            ],
            'expertise' => [
                'title' => 'Areas of Expertise',
                'description' => 'Let us know what you can provide training on',
                'progress' => 75,
                'icon' => 'fas fa-toolbox'
            ],
        ];

        //  Conditionally add the confirm step
        if(!$this->update) {
            $steps['confirm'] = [
                'title' => 'Confirmation',
                'description' => 'Confirm if the information you have provided is correct',
                'progress' => 100,
                'icon' => 'fas fa-clipboard-check'
            ];
        }

        //  Set the steps array
        $this->steps = $steps;

        //  Check if form is an update
        $steps = $this->update ? array_keys($this->steps) : [ 'general' ];

        // Ensure the defined steps are accessible
        foreach($steps as $step) $this->setStepAccessibility($step);
    }


    /**
     * Set the step
     *
     * @param string $step
     * @return string
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function setStep(string $step)
    {
        //  Set the next step name in the session
        session()->put('step', $step);

        //  Set the step to the second step
        $this->step = $step;
    }

    /**
     * Make a step accessible
     *
     * @param string $step
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function setStepAccessibility(string $step): void
    {
        //  Set the accessible step
        session()->push('accessible_steps', $step);
    }

    /**
     * Get the initial step
     *
     * @return string
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStep(): string
    {
        //  Determine the step from the session
        return session()->get('step') ?? 'general';
    }

     /**
     * Determine if a step is accessible
     *
     * @param string $step
     * @return bool
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStepAccessibility(string $step): bool
    {
        return in_array($step, session()->get('accessible_steps'));
    }

    /**
     * Get the user's data
     *
     * @return User
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getUserData(): User
    {
        //  Determine the user data from the session
        if(session()->has('general.user')) {
            return session('general.user');
        }

        //  Get the trainer from
        if($this->trainer) {
            return $this->trainer->trainable;
        }

        //  Else constuct the trainer object
        $user = User::make();

        //  Return the user
        if(app()->environment('local')) {
            //  Force full the user model
            $user->fill([
                'name' => 'John Doe',
                'email' => 'johndoe@demo.ro.te',
                'telephone' => '22722190131',
                'gender' => 'male',
                'county_id' => 47,
                'locality' => 'Nairobi, Kenya',
            ]);

            //  Add a password field
            $user->passkey = 'password';

            //  Add password confirmation
            $user->passkey_confirmation = 'password';
        }

        //  Return the user
        return $user;
    }

    /**
     * Get the trainer's data
     *
     * @return Trainer
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainerData(): Trainer
    {
        //  Determine the user data from the session
        if(session()->has('professional.trainer')) {
            return session()->get('professional.trainer');
        }

        //  Get the trainer from
        $trainer = $this->trainer ?: Trainer::make()->fill($this->getTrainerBasicData());

        //  Append language information
        $trainer->curr_languages = $this->getTrainerLanguages($trainer);

        //  Append Topic information
        $trainer->curr_topics =  $this->getTrainerTopics($trainer);

        //  Finally return the trainer
        return $trainer;
    }

    /**
     * Get the trainer's basic Information
     *
     * @param Trainer
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainerBasicData(): array
    {
        return app()->environment('local') ? [
            'bio' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veritatis necessitatibus officiis quaerat nulla voluptatibus esse ipsa? Sapiente, nulla? Nam maiores laudantium mollitia consequatur veniam quibusdam sequi illo ut quae cumque.',
            'website' => 'www.test.coi.rke',
        ] : [];
    }

    /**
     * Get the trainer's language data
     *
     * @param Trainer
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainerLanguages(Trainer $trainer): array
    {
        //  Get the trainer languages
        $languages = $trainer->languages;

        //  Dynamically determine the language object
        return $languages->isNotEmpty()
            ? $languages->pluck('name')->toArray()
            : (app()->environment('local') ? ['English', 'Kiswahili'] : []);
    }

    /**
     * Get the trainer's topic data
     *
     * @param Trainer
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainerTopics(Trainer $trainer): array
    {
        //  Get the trainer topics
        $topics = $trainer->topics;

        //  Dynamically determine the language object
        $topics = $topics->isNotEmpty()
            ? $topics->pluck('id')->toArray()
            : (app()->environment('local') ? [ 1, 2, 10, 20, 38, 25, 5, 4, 31 ] : []);

        //  Convert the values to strings
        return array_map(function($topic){
            return strval($topic);
        }, $topics);
    }

    /**
     * Get the trainer's county name through a computed property
     *
     * @return County
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getCountyProperty(): County
    {
        return $this->counties->where('id', $this->user->county_id)->first();
    }

    /**
     * Get the trainer's experience data through a computed property
     *
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getExperiencesProperty(): Collection
    {
        return collect(
            session()->get('professional.experiences') ?? []
        );
    }

    /**
     * Get the trainer's qualifications through a computed property
     *
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getQualificationsProperty(): Collection
    {
        return collect(
            session()->get('professional.qualifications') ?? []
        );
    }

    /**
     * Get the trainer's areas of expertise through a computed property
     *
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTopicsProperty(): Collection
    {
        return Topic::with('area.service')
            ->whereIn('id', $this->trainer->curr_topics)
            ->get();
    }

    /**
     * Compute the submit method
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submit($step)
    {
        $method = 'submit'.ucfirst($step);
        $this->{$method}();
    }

    /**
     * Submit the first step
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submitGeneral()
    {
        //  Get the user rules
        $rules = Arr::where($this->rules(), function ($value, $key) {
            return Str::startsWith($key, 'user.');
        });

        //  Validate the request
        $this->validate($rules);

        //  If the request is an update, update the user
        if($this->update) {
            //  Update the user object
            $this->trainer->trainable->update( $this->user->toArray() );

            //  Flash a success message in the session
            session()->flash('success', trans('alerts.success.trainer.updated.account'));

            //  Prevent further execution
            return;
        }

        // Else add the user data to the session
        session()->put('general.user', $this->user);

        //  Then Make the next step accessible
        $this->setStepAccessibility('professional');

        //  Set the next step
        $this->setStep('professional');
    }

    /**
     * Submit the second step
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submitProfessional()
    {
        //  Get the user rules
        $rules = Arr::where($this->rules(), function ($value, $key) {
            return Str::startsWith($key, 'trainer.');
        });

        //  Validate the request
        $this->validate(Arr::except($rules, ['trainer.curr_topics']));

        //  If the request is an update, update the user
        if($this->update) {
            //  Launch a DB transaction
            DB::transaction(function(){
                //  Get the languages selected
                $languages = $this->trainer->curr_languages;

                //  Delete old languages
                $this->trainer->languages()->delete();

                //  Create update or create a new language list
                collect($languages)->each(function($language){
                    $this->trainer->languages()->create([
                        'trainer_id' => $this->trainer->id,
                        'name' => $language
                    ]);
                });

                //  Exclude some elements
                $data = Arr::only($this->trainer->toArray(), $this->trainer->getFillable());

                //  Update the trainer object in the DB
                $this->trainer->fresh()->update($data);
            });

            //  Flash a success message in the session
            session()->flash('success', trans('alerts.success.trainer.updated.professional'));

            //  Prevent further excecution
            return;
        }

        //  Add the trainer data to the session
        session()->put('professional.trainer', $this->trainer);

        //  Make the next step accessible
        $this->setStepAccessibility('expertise');

        //  Navigate to the next step
        $this->setStep('expertise');
    }

    /**
     * Submit the third step
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submitExpertise()
    {
        //  Get the topic rules
        $rules = Arr::where($this->rules(), function ($value, $key) {
            return Str::startsWith($key, 'trainer.');
        });

        //  Validate the request
        $this->validate(Arr::only($rules, ['trainer.curr_topics']));

        //  If the request is an update, update the user topics in the database
        if($this->update) {
            //  Sync the defined topics
            $this->trainer->topics()->sync($this->trainer->curr_topics);

            //  Flash a success message in the session
            session()->flash('success', trans('alerts.success.trainer.updated.expertise'));

            //  Prevent further excecution
            return;
        }

        //  Add the trainer data to the session
        session()->put('professional.trainer', $this->trainer);

        //  Make the next step accessible
        $this->setStepAccessibility('confirm');

        //  Set the next step
        $this->setStep('confirm');
    }

    /**
     * Submit the fourth step
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submitConfirm()
    {
        //  Create an empty user object
        $user = User::make();

        //  Launch a database transaction
        DB::transaction(function() use (&$user){

            //  Create a new user
            $user = $user->create(array_merge($this->user->toArray(), [
                'password' => Hash::make($this->user->passkey)
            ]));

            //  Assign default permissions to user
            $user->assignDefaultPermissions([
                'trainer_key_user'
            ]);

            //  Create a trainer
            $trainer = $user->trainer()->create( $this->trainer->toArray() );

            //  Add topics to the user
            $trainer->topics()->sync( $this->trainer->curr_topics );

            //  Add the trainer's languages
            collect($this->trainer->curr_languages)->each(function($language) use ($trainer){
                $trainer->languages()->create(['name' => $language]);
            });

            //  Add a trainer's experiences
            $this->experiences->each(function($experience) use ($trainer){
                $trainer->experiences()->create($experience->toArray());
            });

            //  Add a trainer's qualifications
            $this->qualifications->each(function($qualification) use ($trainer){
                $trainer->qualifications()->create($qualification->toArray());
            });

            //  Launch a trainer added event
            event(new TrainerRegistered($trainer));
        });

        //  Clear the session data
        session()->flush();

        //  Login the new user
        Auth::login($user);

        //  Flash a success message into the session
        session()->flash('success', trans('alerts.success.trainer.registered'));

        //  Finally clear the session and redirect
        return redirect()->route('portal.trainers.dashboard');
    }

    /**
     * Navigate to a step
     *
     * @param string $step
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function navigateTo(string $step): void
    {
        //  Detemine if the step can be accessed before setting is
        if($this->getStepAccessibility($step)) {
            $this->setStep($step);
        }
    }

    /**
     * Get the previous step
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function previous()
    {
        //  Get the index of the step
        $step = $this->step;

        //  Get the array keys
        $keys = array_keys($this->steps);

        //  Get the current index
        $index = array_search($step, $keys);

        //  Ensure that negative indexes cannot be accessed
        if($index > 0) {
            //  Recalculate the index
            $index--;

            //  Set the new step
            $this->navigateTo($keys[$index]);
        }
    }

    /**
     * Render the component
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function render()
    {
        //  Render the view
        return view('livewire.forms.trainer-registration');
    }
}
