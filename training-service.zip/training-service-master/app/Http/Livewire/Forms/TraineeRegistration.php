<?php

namespace App\Http\Livewire\Forms;

use Livewire\Component;
use App\Models\County;
use App\Models\Organization;
use App\Models\Role;
use App\Models\Service;
use App\Models\Topic;
use App\Models\Trainee;
use App\Models\User;
use App\Services\ValidationService;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class TraineeRegistration extends Component
{
    /**
     * The form's current step
     *
     * @var string
     */
    public string $step;

    /**
     * Varible stores title names
     *
     * @var array
     */
    public array $steps;

    /**
     * The form update
     *
     * @var bool
     */
    public bool $update = false;

    /**
     * Register the validation service
     *
     * @var
     */
    private ?ValidationService $validations = null;

    /**
     * The object to store the new user
     *
     * @var User
     */
    public User $user;

    /**
     * The object to store the new trainee
     *
     * @var Trainee
     */
    public ?Trainee $trainee = null;

    /**
     * Get all genders
     *
     * @var array
     */
    public array $genders;

    /**
     * Get all counties
     *
     * @var Collection
     */
    public Collection $counties;

    /**
     * Get all languages
     *
     * @var array
     */
    public array $languages;

    /**
     * Get all services
     *
     * @var Collection
     */
    public Collection $services;

    /**
     * Get all organizations
     *
     * @var Collection
     */
    public Collection $organizations;

    /**
     * Get all roles
     *
     * @var Collection
     */
    public Collection $roles;

    /**
     * Modify the validation attributes
     *
     * @var array
     */
    protected $validationAttributes = [
        'passkey' => 'password'
    ];

    /**
     * Modify the messages
     *
     * @var array
     */
    protected $messages = [
        'trainee.topics.required' => 'Please provide your areas of expertise.',
    ];

    /**
     * Mount the component
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function mount()
    {
        //  Determine if the form is an update form
        $this->update = (bool) $this->trainee;

        //  Define the steps to be used
        $this->setNavigationSteps();

        //  Get the current step
        $this->step = $this->getStep();

        //  Get the basic trainee bio data
        $this->user = $this->getUserData();

        //  Get the trainee's professional information
        $this->trainee = $this->getTraineeData();

        //  Get the genders
        $this->genders = config('settings.user.genders');

        //  Get the counties
        $this->counties = County::oldest('name')->get();

        //  Get the supported languages
        $this->languages = config('settings.languages');

        //  Get the services
        $this->services = Service::with('areas.topics')->get();

        // Get the organizations
        $this->organizations = Organization::oldest('name')->get();

        // Get trainee type roles
        $this->roles = Role::get();
    }

    /**
     * Register an updated hook
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function updated($propertyName)
    {
        if(!in_array($propertyName, ['user.passkey'])) {
            $this->validateOnly($propertyName);
        }
    }

    /**
     * Return the validation rules
     *
     * @return array
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function rules(): array
    {
        //  Get the validation rules from the validation service
        $this->validations = new ValidationService;

        //  Get the user rules
        $user = $this->update ? $this->trainee->trainable : null;
        $userRules = $this->validations->user('user.', $user);
        $userRules = array_merge($userRules, $this->update ? [] : [
            'user.passkey' => $userRules['user.password'],
            'user.passkey_confirmation' => ['string'],
        ]);

        //  Merge all validations
        $rules = array_merge($userRules);

        //  Refine and return the rules
        return Arr::except($rules, [
            'user.password', 'user.password_confirmation'
        ]);
    }

    /**
     * Define the steps to be navigated in the form
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function setNavigationSteps(): void
    {
        //  Set the steps
        $steps = [
            'general' => [
                'title' => 'Account Information',
                'description' => 'Tell us a bit about yourself',
                'progress' => 25,
                'icon' => 'fas fa-user',
            ],
        ];

        //  Conditionally add the confirm step
        if(!$this->update) {
            $steps['confirm'] = [
                'title' => 'Confirmation',
                'description' => 'Confirm if the information you have provided is correct',
                'progress' => 100,
                'icon' => 'fas fa-clipboard-check'
            ];
        }

        //  Set the steps array
        $this->steps = $steps;

        //  Check if form is an update
        $steps = $this->update ? array_keys($this->steps) : [ 'general' ];

        // Ensure the defined steps are accessible
        foreach($steps as $step) $this->setStepAccessibility($step);
    }


    /**
     * Set the step
     *
     * @param string $step
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function setStep(string $step)
    {
        //  Set the next step name in the session
        session()->put('step', $step);

        //  Set the step to the second step
        $this->step = $step;
    }

    /**
     * Make a step accessible
     *
     * @param string $step
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function setStepAccessibility(string $step): void
    {
        //  Set the accessible step
        session()->push('accessible_steps', $step);
    }

    /**
     * Get the initial step
     *
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStep(): string
    {
        //  Determine the step from the session
        return session()->get('step') ?? 'general';
    }

     /**
     * Determine if a step is accessible
     *
     * @param string $step
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStepAccessibility(string $step): bool
    {
        return in_array($step, session()->get('accessible_steps'));
    }

    /**
     * Get the user's data
     *
     * @return User
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getUserData(): User
    {
        //  Determine the user data from the session
        if(session()->has('general.user')) {
            return session('general.user');
        }

        //  Get the trainee from
        if($this->trainee) {
            return $this->trainee->trainable;
        }

        //  Else constuct the trainee object
        $user = User::make();

        //  Return the user
        if(app()->environment('local')) {
            //  Force full the user model
            $user->fill([
                'name' => 'New Trainee ',
                'email' => 'newtrainee@inuka.co.ke',
                'telephone' => '245711222333',
                'gender' => 'male',
                'county_id' => 47,
                'locality' => 'Nairobi, Kenya',
            ]);

            //  Add a password field
            $user->passkey = 'password';

            //  Add password confirmation
            $user->passkey_confirmation = 'password';
        }

        //  Return the user
        return $user;
    }

    /**
     * Get the trainee's data
     *
     * @return Trainee
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTraineeData(): Trainee
    {
        //  Determine the user data from the session
        if(session()->has('professional.trainee')) {
            return session()->get('professional.trainee');
        }

        //  Get the trainee from
        $trainee = $this->trainee ?: Trainee::make();

        //  Finally return the trainee
        return $trainee;
    }

    /**
     * Get the trainee's county name through a computed property
     *
     * @return County
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getCountyProperty(): County
    {
        return $this->counties->where('id', $this->user->county_id)->first();
    }

    /**
     * Compute the submit method
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submit($step)
    {
        $method = 'submit'.ucfirst($step);
        $this->{$method}();
    }

    /**
     * Submit the first step
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submitGeneral()
    {
        //  Get the user rules
        $rules = Arr::where($this->rules(), function ($value, $key) {
            return Str::startsWith($key, 'user.');
        });

        //  Validate the request
        $this->validate($rules);

        //  If the request is an update, update the user
        if($this->update) {
            //  Update the user object
            $this->trainee->trainable->update( $this->user->toArray() );

            //  Flash a success message in the session
            session()->flash('success', trans('alerts.success.trainee.updated.account'));

            //  Prevent further execution
            return;
        }

        // Else add the user data to the session
        session()->put('general.user', $this->user);

        //  Make the next step accessible
        $this->setStepAccessibility('confirm');

        //  Set the next step
        $this->setStep('confirm');
    }

    /**
     * Submit the second step
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function submitConfirm()
    {
        //  Create an empty user object
        $user = User::make();

        //  Launch a database transaction
        DB::transaction(function() use (&$user){

            //  Create a new user
            $user = $user->create(array_merge($this->user->toArray(), [
                'password' => Hash::make($this->user->passkey)
            ]));

            //  Assign default permissions to user
            $user->assignDefaultPermissions([
                'trainee_key_user'
            ]);

            //  Create a trainee
            $trainee = $user->trainee()->create( $this->trainee->toArray() );


            //  Add the trainee's languages
            collect($this->trainee->curr_languages)->each(function($language) use ($trainee){
                $trainee->languages()->create(['name' => $language]);
            });

            //  Launch a trainee added event
            event(new TraineeRegistered($trainee));
        });

        //  Clear the session data
        session()->flush();

        //  Login the new user
        Auth::login($user);

        //  Flash a success message into the session
        session()->flash('success', trans('alerts.success.trainee.registered'));

        //  Finally clear the session and redirect
        return redirect()->route('portal.trainees.dashboard');
    }

    /**
     * Navigate to a step
     *
     * @param string $step
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function navigateTo(string $step): void
    {
        //  Detemine if the step can be accessed before setting is
        if($this->getStepAccessibility($step)) {
            $this->setStep($step);
        }
    }

    /**
     * Get the previous step
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function previous()
    {
        //  Get the index of the step
        $step = $this->step;

        //  Get the array keys
        $keys = array_keys($this->steps);

        //  Get the current index
        $index = array_search($step, $keys);

        //  Ensure that negative indexes cannot be accessed
        if($index > 0) {
            //  Recalculate the index
            $index--;

            //  Set the new step
            $this->navigateTo($keys[$index]);
        }
    }

    /**
     * Render the component
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function render()
    {
        //  Render the view
        return view('livewire.forms.trainee-registration');
    }
}
