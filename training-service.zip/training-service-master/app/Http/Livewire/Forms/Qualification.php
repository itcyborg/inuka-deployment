<?php

namespace App\Http\Livewire\Forms;

use App\Models\Qualification as QualificationModel;
use App\Models\Trainer;
use App\Services\ValidationService;
use Illuminate\Support\Collection;
use Livewire\Component;

class Qualification extends Component
{
    /**
     * The form update
     *
     * @var bool
     */
    public bool $update = false;

    /**
     * The object to store the new trainer
     *
     * @var Trainer
     */
    public ?Trainer $trainer = null;

    /**
     * The object to store the new qualification
     *
     * @var QualificationModel
     */
    public QualificationModel $qualification;

    /**
     * The object to store the qualifications
     *
     * @var Collection
     */
    public Collection $qualifications;

    /**
     * Mount the component
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function mount()
    {
        //  Determine if the form is an update form
        $this->update = (bool) $this->trainer->qualifications->isNotEmpty();

        //  Determine the qualification
        $this->qualification = QualificationModel::make();

        //  Dynamically determine if test data is to be set
        if(app()->environment('local')) {
            $this->qualification->fill([
                'certification' => 'CISCO',
                'institution' => 'Nairobi Institute',
                'location' => 'Nairobi, Kenya',
                'year' => 2019,
            ]);
        }
    }

    /**
     * Return the validation rules
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function rules(): array
    {
        //  Get the validation rules from the validation service
        $this->validations = new ValidationService;

        //  Merge all validations
        return $this->validations->qualification('qualification.');
    }

    /**
     * Get the trainer's qualification data
     *
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getQualifications(): Collection
    {
        //  Determine the session values
        if(session()->has('professional.qualifications')) {
            return collect(session()->get('professional.qualifications'));
        }

        //  Return the qualifications
        return $this->trainer->qualifications()->get() ?? collect([]);
    }

    /**
     * Save the qualification information in the session
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(): void
    {
        //  Get the validated data
        $data = $this->validate();

        //  Create an qualification object and fill the validated data
        $this->qualification = $this->qualification->fill($data);

        //  Check if the request is an update
        if($this->update) {
            $this->qualification->trainer_id = $this->trainer->id;
            $this->qualification->save();
        } else {
            session()->push('professional.qualifications', $this->qualification);
        }

        //  Reset the qualification instance
        $this->qualification = QualificationModel::make();
    }

    /**
     * Remove the qualification information from the session
     *
     * @param int $index
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function remove(int $index): void
    {
        //  Check if the request is an update
        if($this->update) {
            QualificationModel::destroy($index);
            return;
        }

        //  Remove the element from the session
        session()->forget("professional.experiences.$index");
    }

    /**
     * Render the component
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function render()
    {
        //  Get the trainer's qualification information
        $this->qualifications = $this->getQualifications();

        //  Render the component view
        return view('livewire.forms.qualification');
    }
}
