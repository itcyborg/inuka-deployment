<?php

namespace App\Http\Livewire\Forms;

use App\Models\Experience as ExperienceModel;
use App\Models\Trainer;
use App\Services\ValidationService;
use Illuminate\Support\Collection;
use Livewire\Component;

class Experience extends Component
{
    /**
     * The form update
     *
     * @var bool
     */
    public bool $update = false;

    /**
     * The object to store the new trainer
     *
     * @var Trainer
     */
    public ?Trainer $trainer = null;

    /**
     * The object to store the new experiece
     *
     * @var ExperienceModel
     */
    public ExperienceModel $experience;

    /**
     * The object to store the experiences
     *
     * @var Collection
     */
    public Collection $experiences;

    /**
     * Mount the component
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function mount()
    {
        //  Determine if the form is an update form
        $this->update = (bool) $this->trainer->experiences->isNotEmpty();

        //  Determine the experience
        $this->experience = ExperienceModel::make();

        //  Dynamically determine if test data is to be set
        if(app()->environment('local')) {
            $this->experience->fill([
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus suscipit m',
                'start_year' => 2019,
                'end_year' => 2020,
                'location' => 'Mombasa, Kenya'
            ]);
        }
    }

    /**
     * Return the validation rules
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function rules(): array
    {
        //  Get the validation rules from the validation service
        $this->validations = new ValidationService;

        //  Merge all validations
        return $this->validations->experience('experience.');
    }

    /**
     * Get the trainer's experience data
     *
     * @return Collection
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getExperiences(): Collection
    {
        //  Determine the session values
        if(session()->has('professional.experiences')) {
            return collect(session()->get('professional.experiences'));
        }

        //  Return the experiences
        return $this->trainer->experiences()->get() ?? collect([]);
    }

    /**
     * Save the experience information in the session
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(): void
    {
        //  Get the validated data
        $data = $this->validate();

        //  Create an experience object and fill the validated data
        $this->experience = $this->experience->fill($data);

        //  Check if the request is an update
        if($this->update) {
            $this->experience->trainer_id = $this->trainer->id;
            $this->experience->save();
        } else {
            session()->push('professional.experiences', $this->experience);
        }

        //  Reset the experience instance
        $this->experience = ExperienceModel::make();
    }

    /**
     * Remove the experience information from the session
     *
     * @param int $index
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function remove(int $index): void
    {
        //  Check if the request is an update
        if($this->update) {
            ExperienceModel::destroy($index);
            return;
        }

        //  Remove the element from the session
        session()->forget("professional.experiences.$index");
    }

    /**
     * Render the component
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function render()
    {
        //  Get the trainer's experience information
        $this->experiences = $this->getExperiences();

        //  Render the component view
        return view('livewire.forms.experience');
    }
}
