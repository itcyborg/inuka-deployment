<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Http\Resources\User as UserResource;
use App\Models\User;
use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    /**
     * Store a newly created user in storage.
     *
     * @param UserRequest $request
     * @return Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(UserRequest $request): Response
    {
        try {
            // Authorize the request
            $this->authorize('create', User::class);

            // Get the validated data from the request
            $data = $request->validated();

            // Create an empty user object
            $user = User::make();

            // Create the user
            DB::transaction(function () use ($data, &$user) {
                //  Create a new user
                $user = $user->create($data);

                //  Assign Default Permissions
                $user->assignDefaultPermissions($data['roles']);
            });

            //  Build a user resource instance
            $payload = new UserResource($user);
            $status = 200;
            
        } catch (Exception $e) {
            $payload = $e->getMessage();
            $status = in_array($e->getCode(), range(400, 600))
                ? $e->getCode()
                : 404;
        } finally {
            return response($payload, $status);
        }
    }

    /**
     * Update the specified user in storage.
     *
     * @param UserRequest $request
     * @param User $user
     * @return Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(UserRequest $request, User $user): Response
    {
        try {
            // Authorize the request
            $this->authorize('update', $user);

            // Get the validated data from the request
            $data = $request->validated();

            // Update the user
            DB::transaction(function () use ($data, $user) {
                $user->update($data);

                //  Assign Default Permissions
                if(isset($data['roles'])) {
                    $user->assignDefaultPermissions($data['roles']);
                }
            });

            // Return the results.
            $payload = new UserResource($user, 'updated');
            $status = 200;
            
        } catch (Exception $e) {
            $payload = $e->getMessage();
            $status = in_array($e->getCode(), range(400, 600))
                ? $e->getCode()
                : 404;
        } finally {
            return response($payload, $status);
        }
    }

    /**
     * Remove the specified user from storage.
     *
     * @param User $user
     * @return Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function destroy(User $user): Response
    {
        try {
            // Authorize the request
            $this->authorize('delete', $user);

            // Delete the user
            DB::transaction(function () use ($user) {
                $user->delete();
            });

            // Return the results.
            $payload = [
                'message' => trans('alerts.success.user.api.deleted')
            ];
            $status = 200;
        } catch (Exception $e) {
            $payload = $e->getMessage();
            $status = in_array($e->getCode(), range(400, 600))
                ? $e->getCode()
                : 404;
        } finally {
            return response($payload, $status);
        }
    }
}