<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\TraineeRequest;
use App\Models\Organization;
use App\Http\Resources\Trainee as TraineeResource;
use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class TraineeController extends Controller
{
    /**
     * Store a newly created organization in storage.
     *
     * @param TraineeRequest $request
     * @return Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(TraineeRequest $request): Response
    {
        //  Store the data into the database
        try {
            //  Authorize the request
            $this->authorize('create', Trainee::class);

            //  Get the validated data from the request
            $data = $request->validated();

            //  Create an empty organization object
            $organization = Organization::make();

            //  Create an empty trainee object
            $trainee = null;

            //  Create the organization
            DB::transaction(function () use ($data, &$organization, &$trainee) {
                //  Get the fillables
                $fiilables = $organization->getFillable();

                //  Create the trainee organization
                $organization = $organization->create(
                    Arr::only($data, $fiilables)
                );
                
                //  Create trainee data
                $trainee = $organization->trainee()->create(
                    array_merge(Arr::except($data, $fiilables), [
                        'status' => 'AVAILABLE'
                    ])
                ); 
            });

            // Return the results and a message.
            $payload = new TraineeResource($trainee);
            $status = 200;

        } catch (Exception $e) {
            $payload = $e->getMessage();
            $status = in_array($e->getCode(), range(400, 600))
                ? $e->getCode()
                : 404;
        } finally {
            return response($payload, $status);
        }
    }

    /**
     * Update the specified organization in storage.
     *
     * @param TraineeRequest $request
     * @param Organization $organization
     * @return Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(TraineeRequest $request, Organization $organization): Response
    {
        try {
            //  Get the trainee
            $trainee = $organization->trainee;

            //  Authorize the request
            $this->authorize('update', $trainee);

            //  Get the validated data from the request
            $data = $request->validated();

            //  Update the organization
            DB::transaction(function () use ($data, $organization) {
                //  Get the fillables
                $fiilables = $organization->getFillable();

                //  Update the trainee organization
                $organization->update(Arr::only($data, $fiilables));
                 
                //  Update trainee data
                $organization->trainee()->update(Arr::except($data, $fiilables)); 
            });

            // Return the results.
            $payload = new TraineeResource($trainee, 'updated');
            $status = 200;

        } catch (Exception $e) {
            $payload = $e->getMessage();
            $status = in_array($e->getCode(), range(400, 600))
                ? $e->getCode()
                : 404;
        } finally {
            return response($payload, $status);
        }
    }
}