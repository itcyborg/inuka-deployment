<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Foundation\Auth\RedirectsUsers;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use Symfony\Component\HttpFoundation\RedirectResponse;

class SocialAuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Social Auth Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses traits
    | to conveniently provide its functionality to your applications.
    |
    */
    use RedirectsUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //  Register controller middlewares
        $this->middleware(['guest', 'valid.providers']);
    }

    /**
     * Redirect the user to the provider authentication page.
     *
     * @param $provider
     * @return RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function redirectToProvider($provider): RedirectResponse
    {
        return Socialite::driver($provider)->redirect();
    }

    /**
     * Obtain the user information from the provider.
     *
     * @param $provider
     *
     * @return Application|RedirectResponse|Response|Redirector
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleProviderCallback($provider)
    {
        // Get the user from the provider api
        $social = Socialite::driver($provider)->user();

        // Get the social email. If the email does not exit inform the user
        // that they cannot login in using the provider.
        if (!$email = $social->getEmail()) {
            return redirect()->route('login')->with([
                'error' => trans('auth.socialite.failed', [
                    'provider' => $provider
                ])
            ]);
        }

        // Check if the user exists in the database. If they don't
        // redirect to login and throw an error
        if (!$user = User::where('email', $email)->first()) {
            return redirect()->route('login')->with([
                'error' => trans('auth.socialite.unregistered', [
                    'provider' => $provider
                ])
            ]);
        }

        // Update social auth credentials
        $user->updateSocialCredentials($social, $provider);

        // Finally login the user
        Auth::login($user);

        // Redirect to the appropriate url after registration/authentication
        return request()->wantsJson()
            ? new Response('', 201)
            : redirect($this->redirectPath());
    }
}
