<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AppController extends Controller
{    
    /**
     * Handle redirection of users
     * 
     * @return Application|Factory|View
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function home()
    {
        //  Default redirect path.
        $path = RouteServiceProvider::HOME;

         //  Check if the user is authenticated
         if (Auth::check()) {
            //  Get the authenticated user.
            $user = Auth::user();
 
            //  Handle the redirection to the manager dashboard
            if($user->hasPermissionTo('view_manager_portal')) {
                $path = route('portal.managers.dashboard');
            }
             
            //  Handle the redirection to the trainer dashboard
            if($user->hasPermissionTo('view_trainer_portal')) {
                $path = route('portal.trainers.dashboard');
            }
 
             //  Handle the redirection to the trainee dashboard
            if($user->hasPermissionTo('view_trainee_portal')) {
                $path = route('portal.trainees.dashboard');
            }
        }
 
        //  Return the defined path
        return redirect($path);
    }

    /**
     * Display the unauthorized page
     * 
     * @return Application|Factory|View
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function unauthorized(): View
    {
        //  Return the unauthorized page  
        return view('portal.unauthorized');
    }
}
