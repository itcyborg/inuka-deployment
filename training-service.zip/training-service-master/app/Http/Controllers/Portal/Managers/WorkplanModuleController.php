<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Http\Requests\WorkplanModuleRequest;
use App\Models\Upload;
use App\Models\WorkPlan;
use App\Models\WorkPlanModule;
use Illuminate\Support\Facades\DB;

class WorkplanModuleController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  WorkplanModuleRequest  $request
     * @param  WorkPlan  $workPlan
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(WorkplanModuleRequest $request, WorkPlan $workplan)
    {
        //  Authorize the request
        // $this->authorize('create', [ WorkPlanModule::class, $workplan->trainingRequest ]);

        //  Get the validated data
        $data = $request->validated();

        //  Launch a database transaction
        DB::transaction(function() use ($workplan, $data){
            $workplan->modules()->create($data);            
        });

        //  Redirect back to the previous page and flash a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.workplan-module.created')
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  WorkplanModuleRequest  $request
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(WorkplanModuleRequest $request, WorkplanModule $workplanModule)
    {
        //  Authorize the request
        $this->authorize('update', $workplanModule);

        //  Get the validated data
        $data = $request->validated();

        //  Launch a database transaction
        DB::transaction(function() use ($workplanModule, $data){
            $workplanModule->update($data);            
        });

        //  Redirect back to the previous page and flash a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.workplan-module.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function destroy(WorkplanModule $workplanModule)
    {
        //  Authorize the request
        // $this->authorize('delete', $workplanModule);

        //  Launch a database transaction
        DB::transaction(function() use ($workplanModule){
            //  Delete the workplan module
            $workplanModule->delete();
        });

        //  Redirect back to the previous page and flash a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.workplan-module.deleted')
        ]);
    }
}
