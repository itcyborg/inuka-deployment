<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Http\Requests\OrganizationRequest;
use App\Models\County;
use App\Models\Organization;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use App\Http\Resources\Trainee as TraineeResource;
use Exception;

class OrganizationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index()
    {
        $this->authorize('viewAny', Organization::class);

        /**
         * Get all the services
         */
        $organizations = Organization::with('trainee')->latest('updated_at')->get();

        /**
         * Get all counties
         */
        $counties = County::all();

        /**
         * Return the results
         */
        return view('portal.managers.organizations.index', compact('organizations', 'counties'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(OrganizationRequest $request)
    {
        //  Authorize the request
        $this->authorize('create', Organization::class);

        //  Get the validated data from the request
        $data = $request->validated();

        //  Create an empty organization object
        $organization = Organization::make();

        //  Create an empty trainee object
        $trainee = null;

        //  Create the organization
        DB::transaction(function () use ($data, &$organization, &$trainee) {
            //  Get the fillables
            $fillables = $organization->getFillable();

            $bio = $data['bio'];

            $business_sector = $data['business_sector'];

            //  Create the trainee organization
            $organization = $organization->create(
                Arr::only($data, $fillables)
            );

            //  Create trainee data
            $trainee = $organization->trainee()->create(
                array_merge(Arr::except($data, $fillables, $bio), [
                    'status' => 'AVAILABLE',
                    'bio' => $bio,
                    'business_sector' => $business_sector
                ])
            );
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.organization.created')
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Organization $organization)
    {
        /**First, authorization check for user */
        $this->authorize('view', $organization);

        /**Eager load organization relationships */
        $organization->load(['users.county', 'county']);

        /** get all users */
        $unassignedUser = User::whereNull('organization_id')->role('trainee_key_user')->get();

        // Get all organization users
        $groupUsers = $organization->users;
        
        $users = $groupUsers->merge($unassignedUser);

        // Return response to view
        return view('portal.managers.organizations.show', compact('organization', 'users'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Organization $organization)
    {
        //  Launch a database transaction
        DB::transaction(function() use ($request, $organization){

            $data = $request->except(['_token', '_bag', '_method', 'form']);
            
            // pluck all old organization users id and pass them to array
            $old_users_array = $organization->users->pluck('id')->toArray();

            if ($request->users) {
                // get all new users id to array
                $new_users_array = $data['users'];

                //get the differentiated user ids
                $unassignedUsers = array_diff($old_users_array, $new_users_array);

                // loop through each of the unassigned users and null the organization id
                foreach ($unassignedUsers as $user) {
                    $user = User::where('id', $user)->first();
                    
                    $user->update([
                        'organization_id' => null
                    ]);
                }

                //  Create a bunch of users
                foreach($new_users_array as $curUser) {                    
                    // Get the specific user object
                    $user = User::where('id', $curUser)->first();
                    
                    $user->update([
                        'organization_id' => $organization->id
                    ]);
                }
            } else {
                //
                if ($request->has('form') && !is_null($request->form)) {
                    // loop through each of the unassigned users and null the organization id
                    $user = User::where('id', $old_users_array[0])->first();
                    
                    $user->update([
                        'organization_id' => null
                    ]);
                }

                //Update the organization data
                $organization->update($request->all());
    
                //  Get the fillables
                $fillables = $organization->getFillable();
    
                //  Update trainee data
                $organization->trainee()->update(Arr::except($data, $fillables));
            }

        });


        /**
         * Once updated,
         * Return response with message and data
         */
        return redirect()->back()->with([
            'success' => trans('alerts.success.organization.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Organization $organization)
    {
        //  Authorize the request
        $this->authorize('delete', $organization);

        //  Delete the service
        $organization->delete();

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.organization.deleted')
        ]);
    }
}
