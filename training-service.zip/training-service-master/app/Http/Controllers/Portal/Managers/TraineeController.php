<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Http\Requests\TraineeRequest;
use App\Models\ModuleTemplate;
use App\Models\Service;
use App\Models\Topic;
use App\Models\Trainee;
use App\Models\TrainingRequest;
use App\Models\Upload;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class TraineeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index(Trainee $trainee)
    {
        /**First, authorization check for user */
        $this->authorize('viewAny', Trainee::class);

        /**
         * Get all the trainees
         * will eager load relationships
         */
        $trainees = Trainee::with(['county', 'trainable'])->latest()->get();
        
        /**
         * Return the results to trainees index view
         */
        return view('portal.managers.trainees.index', compact('trainees'));
    }

    /**
     * Do away with the store method for managers (Only view and update)
     */

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Trainee $trainee)
    {
        /**First, authorization check for user */
        $this->authorize('view', $trainee);

        /**
         * Get specific trainee with relationships
         */
        $trainee = $trainee->load(['trainable', 'trainingRequests.topicTrainee', 'topics.area.service', 'ratings']);

        //fetch all topics eager loaded with area, services and training Request
        $topics = Topic::with(['area.service', 'trainingRequests.topicTrainee' => function($query) use ($trainee){
            $query->where('trainee_id', $trainee->id);
        }])->get();


        // Return response to view
        return view('portal.managers.trainees.show', compact('trainee', 'topics'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(Request $request, Trainee $trainee)
    {
        //  Launch a database transaction
        DB::transaction(function() use ($request, $trainee){
            // Assign multiple topics to a trainee
            $trainee->topics()->sync($request->topics);
        });

        //  Every action should return with a notification to the user
        return redirect()->route('portal.managers.trainees.show', [
            'trainee' => $trainee,
            'tab' => 'expertise-tab'
        ])->with([
            'success' => trans('alerts.success.trainee.topic')
        ]);;
    }

    /**
     * Activate the specified trainee.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\Trainee  $trainee
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function activate(Request $request, Trainee $trainee): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('activate', $trainee);

        //  Deactivate the trainable model
        $trainee->trainable->update([
            'status' => 'ACTIVE'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.trainee.activated')
        ]);
    }

    /**
     * Deactivate the specified trainee.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\Trainee  $trainee
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function deactivate(Request $request, Trainee $trainee): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('deactivate', $trainee);

        //  Deactivate the trainable model
        $trainee->trainable->update([
            'status' => 'DEACTIVATED'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.trainee.deactivated')
        ]);
    }

    /**
     * Deactivate the specified trainee.
     *
     * @param  \App\Models\Trainee  $trainee
     * @param  \App\Models\Topic  $topic
     * @return View
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function topic(Trainee $trainee, Topic $topic): View
    {
        /**First, authorization check for user */
        $this->authorize('create', [ TrainingRequest::class, $trainee, $topic ]);

        /**
         * Get specific topic with relationships
         */
        $topic = $topic->load([
            'area', 'trainers.trainable.county',
            'trainingRequests.topicTrainee'
        ]);

        //  Load training request managers
        $managers = User::permission('manage_training_requests')->get();

        //  Check if the module templates have any uploaded material
        $workplanUploads = Upload::where('uploadable_type', 'module-templates')->exists();
        $workplanModules = ModuleTemplate::exists();

        /**
         * Return response to view
         */
        return view('portal.managers.trainees.topic', compact(
            'trainee', 'topic', 'managers', 'workplanUploads', 'workplanModules'
        ));
    }
}
