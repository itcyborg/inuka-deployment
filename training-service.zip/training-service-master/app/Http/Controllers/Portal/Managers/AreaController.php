<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Models\Area;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AreaRequest;
use App\Models\Service;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AreaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index()
    {
        /**
         * Get all the areas
         */
        $areas = Area::all();

        /**
         * Return the results
         */
        return view('portal.managers.areas.index', compact('areas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Service $service
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function store(AreaRequest $request, Service $service)

    {
        //  Authorize the request
        $this->authorize('create', Area::class);

        //  Get the validated date
        $data = $request->validated();

        //  Launch a database transaction
        DB::transaction(function() use ($data, $service){
            $area = $service->areas()->create($data);
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.area.created')
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Area $area)
    {
        /**First, authorization check for user */
        $this->authorize('view', $area);

        /**
         * Get specific area with relationships
         */
        $area = $area->load(['topics']);

        // Return response to view
        return view('portal.managers.areas.topic', compact('area'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(AreaRequest $request, Area $area)
    {
        //Authorize User
        $this->authorize('update', $area);

        //validate data
        $data = $request->validated();

        // Update the area data
        $area->update($data);

        //Return response with message and data
        return redirect()->back()->with([
            'success' => trans('alerts.success.area.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Area $area)
    {
        //  Authorize the request
        $this->authorize('delete', $area);

        //  Delete the area
        $area->delete();

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.area-template.deleted')
        ]);
    }
}
