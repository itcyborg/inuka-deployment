<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Http\Requests\RatingParameterRequest;
use App\Models\RatingParameter;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RatingParameterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index()
    {
        $this->authorize('viewAny', RatingParameter::class);
        /**
         * Get all the services
         */
        $ratingParameters = RatingParameter::latest('updated_at')->get();

        /**
         * Get all entities
         */
        $entities = config('settings.rating_parameters.entities');

        /**
         * Get all types
         */
        $types = config('settings.rating_parameters.types');

        /**
         * Return the results
         */
        return view('portal.managers.rating-parameters.index', compact('ratingParameters'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function store(RatingParameterRequest $request)
    {
        //  Authorize the request
        $this->authorize('create', RatingParameter::class);

        //  Get the validated date
        $data = $request->validated();

        // Initiate db transaction
        DB::transaction(function() use ($data){

            // create new rating parameter
            $ratingParameter = RatingParameter::create($data);
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.rating-parameter.created')
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(RatingParameter $ratingParameter)
    {
        /**First, authorization check for user */
        $this->authorize('view', $ratingParameter);

        // Return response to view
        return view('portal.managers.services.area', compact('service'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(RatingParameterRequest $request, RatingParameter $parameter)
    {

        //Update the RatingParameter dat
        $parameter->update($request->all());

        // Once updated return response with message and data
        return redirect()->back()->with([
            'success' => trans('alerts.success.rating-parameter.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //  Authorize the request
        // $this->authorize('delete', $parameter);

        $parameter = RatingParameter::where('uuid', $id)->first();

        DB::transaction(function() use ($parameter){
            //  Delete the service
            $parameter->delete();
        });


        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.rating-parameter.deleted')
        ]);
    }

    /**
     * Activate the specified service.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\RatingParameter $ratingParameter
     * @return \Illuminate\Http\RedirectResponse
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function activate(Request $request, RatingParameter $ratingParameter): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('activate', $ratingParameter);

        //  Deactivate the trainable model
        $ratingParameter->trainable->update([
            'status' => 'active'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.rating-parameter.activated')
        ]);
    }

    /**
     * Deactivate the specified service.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\RatingParameter  $ratingParameter
     * @return \Illuminate\Http\RedirectResponse
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function deactivate(Request $request, RatingParameter $ratingParameter): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('deactivate', $ratingParameter);

        //  Deactivate the trainable model
        $ratingParameter->trainable->update([
            'status' => 'inactive'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.rating-parameter.deactivated')
        ]);
    }
}
