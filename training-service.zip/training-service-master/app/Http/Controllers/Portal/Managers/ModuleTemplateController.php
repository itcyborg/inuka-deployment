<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Http\Requests\ModuleTempleteRequest;
use App\Models\ModuleTemplate;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ModuleTemplateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index()
    {
        //  Authorize the request
        $this->authorize('viewAny', ModuleTemplate::class);

        //  Get all the draft workplan modules
        $modules = ModuleTemplate::all();

        //  Return view to display all workplan modules
        return view('portal.managers.module-templates.index', [
            'modules' => $modules
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  ModuleTemplateRequest $request
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(ModuleTempleteRequest $request): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('create', ModuleTemplate::class);

        //  Get the validated date
        $data = $request->validated();

        //  Create the module
        $module = ModuleTemplate::make();
        DB::transaction(function() use (&$module, $data) {
            $module = $module->create($data);
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.module-template.created')
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  ModuleTemplateRequest $request
     * @param  \App\Models\ModuleTemplate  $module
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(ModuleTempleteRequest $request, ModuleTemplate $moduleTemplate)
    {
        //  Authorize the request
        $this->authorize('update', $moduleTemplate);

        //  Get the validated date
        $data = $request->validated();

        //  launch a database transaction
        DB::transaction(function() use ($moduleTemplate, $data) {
            $moduleTemplate->update($data);
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.module-template.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ModuleTemplate  $moduleTemplate
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function destroy(ModuleTemplate $moduleTemplate)
    {
        //  Authorize the request
        $this->authorize('delete', $moduleTemplate);

        //  Delete the module
        $moduleTemplate->delete();

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.module-template.deleted')
        ]);
    }
}
