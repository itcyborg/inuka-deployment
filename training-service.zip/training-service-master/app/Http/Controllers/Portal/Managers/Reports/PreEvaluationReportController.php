<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\Evaluation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PreEvaluationReportController extends Controller
{
    /**
     * Generate all pre-evaluation reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generatePreEvaluationReport', Evaluation::class);

        $preEvaluations = Evaluation::where('type', 'PRE')->get();

        return view('portal.managers.reports.pre-evaluation', [
            'preEvaluations' => $preEvaluations
        ]);
    }
}
