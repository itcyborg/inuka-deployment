<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\TrainingRequest;

class TrainingRequestReportController extends Controller
{
    /**
     * Generate all training request reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateTrainingRequestReports', TrainingRequest::class);
        
        // get all ratings with relationships
        $trainingRequests = TrainingRequest::requests()->get();

        return view('portal.managers.reports.training-request', [
            'trainingRequests' => $trainingRequests
        ]);
    }
}
