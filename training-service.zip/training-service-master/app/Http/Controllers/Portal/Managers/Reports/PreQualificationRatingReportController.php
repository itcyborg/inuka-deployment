<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\Rating;

class PreQualificationRatingReportController extends Controller
{
    /**
     * Generate all pre-qualification rating reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generatePreQualificationRatingReports', Rating::class);

        // get all ratings with relationships
        $ratings = Rating::with(['user', 'rateable', 'entity'])->get();

        $preQualificationRatings = $ratings->where('type', 'pre-qualification');

        return view('portal.managers.reports.pre-qualification-ratings', [
            'preQualificationRatings' => $preQualificationRatings
        ]);
    }
}
