<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\Evaluation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostEvaluationReportController extends Controller
{
    /**
     * Generate all post-evaluation reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generatePostEvaluationReport', Evaluation::class);

        $postEvaluations = Evaluation::where('type', 'POST')->get();

        return view('portal.managers.reports.post-evaluation', [
            'postEvaluations' => $postEvaluations
        ]);
    }
}
