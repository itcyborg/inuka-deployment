<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\Sow;

class SOWReportController extends Controller
{
    /**
     * Get all sows.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateSowReports', Sow::class);

        // get all trainee type ratings with relationships
        $sows = Sow::all();

        return view('portal.managers.reports.sow', [
            'sows' => $sows
        ]);
    }
}
