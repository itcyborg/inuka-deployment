<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\Rating;

class TrainerRatingReportController extends Controller
{
    /**
     * Generate all trainer rating reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateTrainerRatingReports', Rating::class);

        // get all trainer type ratings with relationships
        $ratings = Rating::with(['user', 'rateable'])->get();

        $trainerRatings = $ratings->where('type', 'trainer');

        return view('portal.managers.reports.trainer-ratings', [
            'trainerRatings' => $trainerRatings
        ]);
    }
}
