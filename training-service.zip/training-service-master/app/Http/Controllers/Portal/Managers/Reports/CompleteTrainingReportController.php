<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\TrainingRequest;

class CompleteTrainingReportController extends Controller
{
    /**
     * Generate all training request reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateCompleteTrainingReports', TrainingRequest::class);

        // get all ratings with relationships
        $completeTrainings = TrainingRequest::where('status', 'COMPLETED')->get();

        return view('portal.managers.reports.complete-training', [
            'completeTrainings' => $completeTrainings
        ]);
    }
}
