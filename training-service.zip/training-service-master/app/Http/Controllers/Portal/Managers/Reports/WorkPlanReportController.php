<?php

namespace App\Http\Controllers\Portal\Managers\Reports;

use App\Http\Controllers\Controller;
use App\Models\WorkPlan;
use App\Models\WorkPlanModule;

class WorkPlanReportController extends Controller
{
    /**
     * Get all workplan.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateWorkPlanReports', WorkPlanModule::class);

        // get all work plans
        $workPlans = WorkPlan::with([
            'trainingRequest.topicTrainee.trainee.trainable',
            'modules', 'trainingRequest.topicTrainee.topic'
        ])->get();

        return view('portal.managers.reports.workplan', [
            'workPlans' => $workPlans
        ]);
    }
}
