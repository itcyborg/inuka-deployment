<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Http\Requests\TrainingMaterialRequest;
use App\Models\ModuleTemplate;
use App\Models\Upload;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TrainingMaterialController extends Controller
{
    /**
     * Display a listing of a module template's training materials.
     *
     * @param  \App\Models\ModuleTemplate  $moduleTemplate
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index(ModuleTemplate $moduleTemplate)
    {
        //  Authorize the request
        $this->authorize('viewAny', Upload::class);

        //  Get the training materials
        $materials = $moduleTemplate->uploads()
            ->with(['uploadable', 'owner'])
            ->type('training-material')
            ->latest()->get();

        //  Return a view with a list of all training materials
        return view('portal.managers.training-materials.index', [
            'materials' => $materials,
            'module' => $moduleTemplate
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  TrainingMaterialRequest  $request
     * @param \App\Models\ModuleTemplate
     * @return \Illuminate\Http\Response
     */
    public function store(TrainingMaterialRequest $request, ModuleTemplate $moduleTemplate)
    {
        //  Authorize the request
        $this->authorize('create', Upload::class);

        //  Get the validated data from the request
        $data = $request->validated();

        //  Initialize a database transaction
        DB::transaction(function() use ($moduleTemplate, $data){
            $moduleTemplate->uploads()->create($data);
        });

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.training-material.created')
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  TrainingMaterialRequest  $request
     * @param  \App\Models\Upload  $upload
     * @return \Illuminate\Http\Response
     */
    public function update(TrainingMaterialRequest $request, Upload $upload)
    {
        //  Authorize the request
        $this->authorize('update', $upload);

        //  Get the validated data from the request
        $data = $request->validated();

        //  Initialize a database transaction
        DB::transaction(function() use ($upload, $data){
            $upload->update($data);
        });

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.training-material.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Upload  $upload
     * @return \Illuminate\Http\Response
     */
    public function destroy(Upload $upload)
    {
        //  Authorize the request
        $this->authorize('delete', $upload);

        //  Initialize a database transaction
        DB::transaction(function() use ($upload){
            $upload->delete();
        });

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.training-material.deleted')
        ]);
    }

    /**
     * Download the specified upload.
     *
     * @param \App\Models\Upload
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function download(Upload $upload)
    {
        //  Check if the user is authorized
        $this->authorize('download', $upload);    

        //  Download the document
        return response()->download(public_path($upload->path));    
    }
}