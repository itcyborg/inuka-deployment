<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Services\DashboardService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\View\View;

class AppController extends Controller
{
    /**
     * Display the managers' dashboard
     * 
     * @param DashboardService $dashboardService
     * @return Application|Factory|View
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function dashboard(DashboardService $dashboardService)
    {
        //  Authorize the request
        $this->authorize('view_manager_portal');

        //  Return the dashboard and all the relevant data
        return view('portal.managers.dashboard', $dashboardService->getManagerData());
    }

    /**
     * Display the unauthorized page
     * @return Application|Factory|View
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function unauthorized(): View
    {
        //  Authorize the request
        $this->authorize('view_manager_portal');

        //  Return the unauthorized page  
        return view('portal.managers.unauthorized');
    }
}
