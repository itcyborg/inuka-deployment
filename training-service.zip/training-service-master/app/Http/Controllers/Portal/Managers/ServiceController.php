<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Models\Service;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ServiceRequest;
use App\Models\Area;
use App\Models\Topic;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Validator;

class ServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index()
    {
        $this->authorize('viewAny', Service::class);
        /**
         * Get all the services
         */
        $services = Service::all();

        /**
         * Return the results
         */
        return view('portal.managers.services.index', compact('services'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function store(ServiceRequest $request)
    {
        //  Authorize the request
        $this->authorize('create', Service::class);

        //  Get the validated date
        $data = $request->validated();

        $service = Service::create($data);

        $service->save();

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.service.created')
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Service $service)
    {
        /**First, authorization check for user */
        $this->authorize('view', $service);

        /**
         * Get specific service with relationships
         */
        $service = $service->load(['areas.topics']);

        // Return response to view
        return view('portal.managers.services.area', compact('service'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(Request $request, $id)
    {
        //Get service data using $id
        $service = Service::find($id);

        //Update the service dat
        $service->update($request->all());

        /**
         * Once updated,
         * Return response with message and data
         */
        return redirect()->back()->with([
            'success' => trans('alerts.success.service.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Service $service)
    {
        //  Authorize the request
        $this->authorize('delete', $service);

        //  Delete the service
        $service->delete();

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.service-template.deleted')
        ]);
    }

    /**
     * Activate the specified service.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\Service $service
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function activate(Request $request, Service $service): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('activate', $service);

        //  Deactivate the trainable model
        $service->trainable->update([
            'status' => 'active'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.trainers.activated')
        ]);
    }

    /**
     * Deactivate the specified service.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\Service  $service
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function deactivate(Request $request, Service $service): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('deactivate', $service);

        //  Deactivate the trainable model
        $service->trainable->update([
            'status' => 'inactive'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.trainers.deactivated')
        ]);
    }

    public function area(Service $service, Area $area)
    {
        /**First, authorization check for user */
        $this->authorize('view', $area);

        /**
         * Get specific area with relationships
         */
        $area = $service->load(['areas']);

        /**
         * Return response to view
         */
        return view('portal.managers.services.area', compact('area'));
    }
}
