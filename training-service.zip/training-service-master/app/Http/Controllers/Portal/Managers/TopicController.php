<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Models\Topic;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\TopicRequest;
use App\Models\Area;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class TopicController extends Controller

{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index()
    {
        // Get all the topics
        $topics = Topic::get();

        /**
         * Return the results
         */
        return view('portal.managers.topics.index', compact('topics'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Area $area
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function store(TopicRequest $request, Area $area)
    {
        //  Authorize the request
        $this->authorize('create', Topic::class);

        //  Get the validated date
        $data = $request->validated();

        //  Launch a database transaction
        DB::transaction(function() use ($data, $area){
            $topic = $area->topics()->create($data);
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.topic.created')
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Topic $topic)
    {
        /**First, authorization check for user */
        $this->authorize('view', $topic);

        /**
         * Get specific topic with relationships
         */
        $topic = $topic->load(['topic']);

        /**
         * Return response to view
         */
        return view('portal.managers.topics.show', compact('topic'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(TopicRequest $request, Topic $topic)
    {
        //Authorize User
        $this->authorize('update', $topic);

        //validate data
        $data = $request->validated();

        // Update the topic data
        $topic->update($data);

        //Return response with message and data
        return redirect()->back()->with([
            'success' => trans('alerts.success.topic.updated')
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Topic $topic)
    {
        //  Authorize the request
        $this->authorize('delete', $topic);

        // dd($topic);

        //  Delete the topic
        $topic->delete();

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.topic-template.deleted')
        ]);
    }
}
