<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Events\TrainingRequestCreated;
use App\Http\Controllers\Controller;
use App\Http\Requests\TrainingRequest as TrainingRequestRequest;
use App\Models\Evaluation;
use App\Models\RatingParameter;
use App\Models\Topic;
use App\Models\Trainee;
use App\Models\Trainer;
use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class TrainingRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index(): View
    {
        //  Authorize the request
        $this->authorize('viewAny', TrainingRequest::class);

        //  Determine the type of training request that will be loaded
        $type = request()->query('type') == 'provisions' ? 'provisions' : 'requests';

        //  Get all the training requests
        $trainingRequests = TrainingRequest::with([
            'trainer', 'topicTrainee.topic', 'topicTrainee.trainee'
            ])->type($type)
            ->latest('updated_at')
            ->get();

        //  Return a list of all raised training requests
        return view('portal.managers.training-requests.index', [
            'trainingRequests' => $trainingRequests,
            'type' => $type
        ]);
    }

    /**
     * Store a newly created training request in storage.
     *
     * @param  TrainingRequestRequest  $request
     * @param  Trainer  $trainer
     * @param  Trainee  $trainee
     * @param  Topic  $topic
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(TrainingRequestRequest $request, Trainer $trainer, Trainee $trainee, Topic $topic)
    {
        //  Authorize this request
        $this->authorize('create', [ TrainingRequest::class, $trainee, $topic ]);

        //  Get the data from the request
        $data = $request->validated();

        //  Create an empty training request object
        $trainingRequest = TrainingRequest::make();

        //  Launch a database transaction
        DB::transaction(function() use ($data, &$trainingRequest){
            //  Create a training request
            $trainingRequest = $trainingRequest->create($data);

            //  Inherit workplan from basic template
            $trainingRequest->inheritWorkplanFromTemplate();
        });

        //  Redirect to the show page
        return redirect()->route('portal.managers.training-requests.show', [
            'training_request' => $trainingRequest
        ])->with([
            'success' => trans('alerts.success.training-request.created')
        ]);
    }

    /**
     * Display the specified training request.
     *
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(TrainingRequest $trainingRequest)
    {
        //  Authorize the request
        $this->authorize('view', $trainingRequest);

        //  Lazy eager load relations
        $trainingRequest->load([
            'sow', 'workplan.modules' => function($query){
                $query->oldest('start_date');
            },
            'workplan.modules.uploads',
            'workplan.modules.moduleTemplate.uploads',
            'topicTrainee.topic.area.service', 'trainer.trainable',
            'topicTrainee.trainee.trainable',
            'workplan.evaluations.workplan.trainingRequest',
            'workplan.evaluations.ratings','ratings.user',
        ]);

        //Fetch all evaluation of type 'PRE'
        $preEvaluations = $trainingRequest->workplan->evaluations->where('type', 'PRE')->all();

        //Fetch all evaluation of type 'POST'
        $postEvaluations = $trainingRequest->workplan->evaluations->where('type', 'POST')->all();

        $trainerRatings = $trainingRequest->ratings
        ->where('user_id', $trainingRequest->trainer->trainable->id)
        ->where('parent_id', $trainingRequest->id)
        ->all();

        //fetch all ratings that are of rateable type 'trainer' (They are ratings performed by trainees)

        $traineeRatings = $trainingRequest->ratings
        ->where('rateable_type', 'trainers')
        ->where('user_id', '!=', $trainingRequest->manager_id)
        ->groupBy(function($item, $key) {
            return User::find($item['user_id'])->name;
        });

        //  Load saved ratings
        $trainingRequest->workplan->evaluations->map(function($evaluation){
            return $evaluation->loadSavedRatings();
        });

        //  get all rating parameters of entity trainee and
        //  type rating
        $criteria = RatingParameter::where([
            ['entity', 'trainer'], ['type', 'rating']
        ])->get();

        //  get all rating parameters of entity trainee and
        //  type rating
        $postEvaluationCriteria = RatingParameter::where([
            ['entity', 'workplan'], ['type', 'post-evaluation']
        ])->get();

        //  Return a view with all the trainer information
        return view('portal.managers.training-requests.show', [
            'trainingRequest' => $trainingRequest,
            'criteria' => $criteria,
            'postEvaluationCriteria' => $postEvaluationCriteria,
            'postEvaluations' => $postEvaluations,
            'preEvaluations' => $preEvaluations,
            'traineeRatings' => $traineeRatings,
            'trainerRatings' => $trainerRatings,
        ]);
    }

    /**
     * Publish the specified training request.
     *
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function publish(Request $request, TrainingRequest $trainingRequest)
    {
        //  Authorize the request
        $this->authorize('publish', $trainingRequest);

        //  Launch a database transaction
        DB::transaction(function() use ($trainingRequest){
            //  Update the training request to the status 'AWAITING_TRAINER_APPROVAL'
            $trainingRequest->setStatus('AWAITING_TRAINER_APPROVAL');

            //  Throw an event
            event(new TrainingRequestCreated($trainingRequest));
        });

        //  Redirect to the show page
        return redirect()->route('portal.managers.training-requests.index')->with([
            'success' => trans('alerts.success.training-request.published')
        ]);
    }

    public function results(Evaluation $Evaluation)
    {
        //  Authorize the request
        $this->authorize('view', $Evaluation);

        //  Lazy eager load relations
        $Evaluation->load([
            'user', 'workplan', 'rateable'
        ]);

        //  Return a view with all the trainer information
        return view('portal.managers.training-requests.evaluation', [
            'Evaluation' => $Evaluation,
        ]);
    }
}
