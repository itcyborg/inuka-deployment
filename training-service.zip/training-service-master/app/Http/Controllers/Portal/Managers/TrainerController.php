<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Http\Controllers\Controller;
use App\Models\RatingParameter;
use App\Models\Trainer;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class TrainerController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index(): View
    {
        //  Authorize the request
        $this->authorize('viewAny', Trainer::class);

        //  Get all the trainers
        $trainers = Trainer::with(['trainable.county'])->latest()->get();

        return view('portal.managers.trainers.index', [
            'trainers' => $trainers
        ]);
    }

    /**
     * Display the specified trainer.
     *
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Trainer $trainer): View
    {
        //  Authorize the request
        $this->authorize('view', $trainer);

        //  Lazy eager load the trainer relations
        $trainer = $trainer->load([
            'trainable.organization',
            'trainable.county', 'uploads',
            'topics.area.service', 'languages',
            'qualifications' => function($query){
                return $query->latest('year');
            }, 'experiences' => function($query){
                return $query->latest('start_year');
            },'ratings'
        ]);

        $trainerPreQualificationRatings = $trainer->ratings
        ->where('type', 'pre-qualification')
        ->where('user_id', Auth::user()->id);

        $trainer->hasAnOrganization();

        //  get all rating parameters of entity trainee and
        //  type rating
        $criteria = RatingParameter::where([
            ['entity', 'trainer'], ['type', 'pre-qualification']
        ])->get();

        //  Return a view with all the trainer information
        return view('portal.managers.trainers.show', [
            'trainer' => $trainer,
            'criteria' => $criteria,
            'trainerPreQualificationRatings' => $trainerPreQualificationRatings
        ]);
    }

    /**
     * Activate the specified trainer.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function activate(Request $request, Trainer $trainer): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('activate', $trainer);

        //  Deactivate the trainable model
        $trainer->trainable->update([
            'status' => 'ACTIVE'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.trainer.activated')
        ]);
    }

    /**
     * Deactivate the specified trainer.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\RedirectResponse
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function deactivate(Request $request, Trainer $trainer): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('deactivate', $trainer);

        //  Deactivate the trainable model
        $trainer->trainable->update([
            'status' => 'DEACTIVATED'
        ]);

        //  Redirect with a success message
        return redirect()->back()->with([
            'success' => trans('alerts.success.trainer.deactivated')
        ]);
    }
}
