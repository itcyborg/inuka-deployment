<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Events\TrainerPrequalificationComplete;
use App\Events\TrainerPrequalificationSubmitted;
use App\Http\Controllers\Controller;
use App\Http\Requests\RatingRequest;
use App\Models\Rating;
use App\Models\RatingParameter;
use App\Models\Trainer;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PrequalificationController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(RatingRequest $request, Trainer $trainer)
    {
        //  Authorize the request
        $this->authorize('createPrequalification', [ Rating::class, $trainer ]);

        //  Get the validated data
        $data = $request->validated();

        //  Store Ratings.
        DB::transaction(function() use ($data, $trainer){
            //  Get the authentication ID
            $user = Auth::user();

            // get the rating parameter

            //  loop through each rating
            foreach ($data['ratings'] as $paramaterId => $details) {
                $user->ratings()->create([
                    'rateable_id' => $paramaterId,
                    'rateable_type' => 'rating-parameters',
                    'entity_type' => 'trainers',
                    'entity_id' => $trainer->id,
                    'type' => 'pre-qualification',
                    'value' => $details['value'],
                    'max_value' => RatingParameter::where('id', $paramaterId)->pluck('max_rating')->first(),
                    'description' => $details['description'],
                ]);
            }

            //  Store the trainer pre-qualification rating in the db
            $trainer->storeAveragePreQualificationRating();

            // Run a manager pre-qualification submission event
            event(new TrainerPrequalificationSubmitted($trainer));

            //  Check if the trainer prequalification is complete and throw a
            //  completion event
            if ($trainer->prequalificationIsComplete()) {
                event(new TrainerPrequalificationComplete($trainer));
            }
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.pre-qualification.created')
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(RatingRequest $request, Trainer $trainer)
    {
        //  Authorize the request
        $this->authorize('updatePrequalification', [ Rating::class, $trainer ]);

        //  Get the validated data
        $data = $request->validated();

        //  Store Ratings.
        DB::transaction(function() use ($data, $trainer){
            //  Get the authentication ID
            $user = Auth::user();

            //  loop through each rating
            foreach ($data['ratings'] as $paramaterId => $details) {
                $user->ratings()->updateOrCreate([
                    'user_id' => $user->id,
                    'rateable_id' => $paramaterId,
                    'rateable_type' => 'rating-parameters',
                    'entity_type' => 'trainers',
                    'entity_id' => $trainer->id,
                    'type' => 'pre-qualification',
                ],[
                    'value' => $details['value'],
                    'description' => $details['description'],
                ]);
            }

            //  Store the trainer pre-qualification rating in the db
            $trainer->storeAveragePreQualificationRating();
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.rating.manager.updated')
        ]);
    }
}
