<?php

namespace App\Http\Controllers\Portal\Managers;

use App\Events\UserActivatedEvent;
use App\Events\UserDeactivatedEvent;
use App\Http\Controllers\Controller;
use App\Http\Requests\CommentRequest;
use App\Models\Trainer;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index(): View
    {
        //  Authorize the request
        $this->authorize('viewAny', User::class);

        $unassignedUsers = User::withCount('roles')->has('roles', 0)->get();

        // Get all roles
        $roles = Role::all();

        //  Get manager users
        $managers = User::permission('view_manager_portal')->get();

        //  Get trainer users
        $trainers = User::permission('view_trainer_portal')->get();

        //  Get trainee users
        $trainees = User::permission('view_trainee_portal')->get();

        return view('portal.managers.users.index', [
            'managers' => $managers,
            'trainers' => $trainers,
            'trainees' => $trainees,
            'all' => $unassignedUsers,
            'roles' => $roles
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(User $user)
    {
        /**First, authorization check for user */
        $this->authorize('view', $user);

        /**
         * Get specific user with relationships
         */
        $user = $user->load(['uploads', 'permissions', 'roles']);

        //  Create an empty roles array
        $systemRoles = collect(config('settings.roles'))
            ->flatten()->unique()
            ->toArray();

        $roles = Role::all();

        //  Get the user's roles
        $role = $user->roles->whereIn('name', $systemRoles)->first();

        //Get all system permissions
        $permissions = $role->permissions->groupBy('model_name');

        // Return response to view
        return view('portal.managers.users.show', compact('user', 'permissions', 'role', 'roles'));
    }

    /**
     * Assign user a role
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function assignRole(Request $request, User $user)
    {
        //  Launch a database transaction
        DB::transaction(function() use ($request, $user){
            // assign a user aa role
            $user->assignDefaultPermissions($request->role);

            if ($request->role == 'trainer_key_user') {
                //  Create a trainer
                Trainer::create([
                    'trainable_id' => $user->id,
                    'trainable_type' => 'users',
                ]);
            }
        });

        //  Every action should return with a notification to the user
        return redirect()->route('portal.managers.users.show', ['user' => $user])->with([
            'success' => trans('alerts.success.user.roles')
        ]);
    }

    /**
     * Update the specified user permissions.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(Request $request, User $user)
    {
        //  Launch a database transaction
        DB::transaction(function() use ($request, $user){
            if ($request->role) {
                // assign a user aa role
                $user->assignDefaultPermissions($request->role);

                if ($request->role == 'trainer_key_user') {
                    //  Create a trainer
                    Trainer::create([
                        'trainable_id' => $user->id,
                        'trainable_type' => 'users',
                    ]);
                }
            }
            
            // Assign multiple roles to a user
            $user->permissions()->sync($request->permissions);
        });

        //  Every action should return with a notification to the user
        return redirect()->route('portal.managers.users.show', ['user' => $user])->with([
            'success' => trans('alerts.success.user.permissions')
        ]);
    }

    /**
     * Activate the specified trainer.
     *
     * @param \Illuminate\Http\Request
     * @return \Illuminate\Http\RedirectResponse
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function activate(Request $request, User $user): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('activate', $user);

        // Define the tab from request
        $tab = $request->tab;

        // initiate a DB trnsaction
        DB::transaction(function() use ($request, $user){
            //  Activate the user model
            $user->setStatus('ACTIVE');

            // trigger user activation event to send user a notification
            event(new UserActivatedEvent($user));
        });

        //  Redirect with a success message
        return redirect()->route('portal.managers.users.index', ['tab' => $tab])->with([
            'success' => trans('alerts.success.user.activated')
        ]);
    }

    /**
     * Deactivate the specified trainer.
     *
     * @param \Illuminate\Http\Request
     * @return \Illuminate\Http\RedirectResponse
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function deactivate(CommentRequest $request, User $user): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('deactivate', $user);

        // Define the tab from request
        $tab = $request->tab;

        $data = $request->validated();

        // initiate a DB transaction
        DB::transaction(function() use ($request, $data, $user){
            //  Deactivate the user model
            $user->setStatus('DEACTIVATED');

            // Define comment variable
            $reason = $request->comment;

            // save comment through user-comment relationship
            $user->comments()->create($data);

            // trigger user deactivation event to send user a notification
            event(new UserDeactivatedEvent($user, $reason));
        });


        //  Redirect with a success message
        return redirect()->route('portal.managers.users.index', ['tab' => $tab])->with([
            'success' => trans('alerts.success.user.deactivated')
        ]);
    }
}
