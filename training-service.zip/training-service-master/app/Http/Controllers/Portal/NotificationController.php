<?php

namespace App\Controllers\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class NotificationController extends Controller
{
    /**
     * Variable to store the notification view name
     * 
     * @var string
     */
    protected string $view = '';

    /**
     * Display a listing of all notifications in the application.
     * 
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     * @return View
     */
    public function index(): View
    {
        //  Return a view with paginated notifications
        return view($this->view, [
            'notifications' => Auth::user()->notifications()->paginate(10)
        ]);
    }

    /**
     * Mark a notification as read and redirect to the specified 
     * action
     * 
     * @param \Illuminate\Notifications\DatabaseNotification $notification
     * @return \Illuminate\Http\RedirectResponse
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function action(DatabaseNotification $notification): RedirectResponse
    {
        //  Find a notification of and mark it as read.
        if($notification->unread()) $notification->markAsRead();

        //  Get the notification data object, then derive the action route if it exists.
        $route = ($notification->data['body']['action']) ?? url()->previous();

        //  Redirect to the action route if it exists
        return redirect($route);
    }

    /**
     * Mark all user notifications as read/unread
     *
     * @param Request $request 
     * @param string $state 
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function mark(Request $request, string $state): RedirectResponse
    {
        //  Get all notifications for a user in a specific organization
        $user = Auth::user();

        //  Change all notifications to read or unread depending on
        //  the request that has been sent out.
        switch ($state) {
            case 'read':
                $user->load(['notifications' => function($query){
                    $query->unread();              
                }])->notifications->markAsRead();
                break;

            case 'unread':
                $user->load(['notifications' => function($query){
                    $query->read();              
                }])->notifications->markAsUnread();
                break;
            
            default:
                abort(500);
                break;
        }

        //  Redirect with a sucess message
        return redirect()->back()->with([
            'success' => trans("alerts.success.notification.$state")
        ]);
    }
}