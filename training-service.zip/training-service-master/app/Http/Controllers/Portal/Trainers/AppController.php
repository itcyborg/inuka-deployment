<?php

namespace App\Http\Controllers\Portal\Trainers;

use App\Http\Controllers\Controller;
use App\Services\DashboardService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AppController extends Controller
{
    /**
     * Display the managers' dashboard
     * 
     * @param DashboardService $dashboardService
     * @return Application|Factory|View
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function dashboard(DashboardService $dashboardService)
    {
        //  Authorize the request
        $this->authorize('view_trainer_portal');

        $authUser = Auth::user();

        $user = $authUser->load(['trainer.trainable']);

        if(!$user->trainer->hasQualifications())
        {
            return redirect()->route('portal.trainers.profiles.edit');
        }

        //  Return the dashboard and all the relevant data
        return view('portal.trainers.dashboard', $dashboardService->getTrainerData());
    }
}
