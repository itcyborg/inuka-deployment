<?php

namespace App\Http\Controllers\Portal\Trainers\Reports;

use App\Http\Controllers\Controller;
use App\Models\WorkPlan;

class WorkPlanReportController extends Controller
{
    /**
     * Get all workplan.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateWorkPlanReports', WorkPlanModule::class);

        // get all work plans
        $workPlans = WorkPlan::with(['trainingRequest.topicTrainee.trainee.trainable', 'modules', 'trainingRequest.topicTrainee.topic.area.service'])->get();

        return view('portal.trainers.reports.workplan', [
            'workPlans' => $workPlans
        ]);
    }
}
