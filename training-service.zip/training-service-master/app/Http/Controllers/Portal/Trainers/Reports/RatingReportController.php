<?php

namespace App\Http\Controllers\Portal\Trainers\Reports;

use App\Http\Controllers\Controller;
use App\Models\Rating;

class RatingReportController extends Controller
{
    /**
     * Generate different types of rating reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generatePreQualificationRatingReports', Rating::class);

        // get all ratings with relationships
        $ratings = Rating::with(['user', 'rateable', 'entity.trainable'])->get();

        // Get pre-qualification type of ratings
        $preQualificationRatings = $ratings->where('type', 'pre-qualification');

        // Get trainee type of ratings
        $traineeRatings = $ratings->where('type', 'trainee');

        // Get trainer type of ratings
        $trainerRatings = $ratings->where('type', 'trainer');

        return view('portal.trainers.reports.ratings', [
            'preQualificationRatings' => $preQualificationRatings,
            'traineeRatings' => $traineeRatings,
            'trainerRatings' => $trainerRatings
        ]);
    }
}
