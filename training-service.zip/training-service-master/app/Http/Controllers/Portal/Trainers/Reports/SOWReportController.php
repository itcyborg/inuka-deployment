<?php

namespace App\Http\Controllers\Portal\Trainers\Reports;

use App\Http\Controllers\Controller;
use App\Models\Sow;
use Illuminate\Support\Facades\Auth;

class SOWReportController extends Controller
{
    /**
     * Get all sows.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateSowReports', Sow::class);

        // Get the auth user
        $user = Auth::user();

        // get trainer profile of login type of trainer user
        $trainer = $user->getTrainerProfile();

        // Get the trainer (USER) id
        $sows = Sow::where('trainer_id', $trainer->trainable->id)->get();

        return view('portal.trainers.reports.sow', [
            'sows' => $sows
        ]);
    }
}
