<?php

namespace App\Http\Controllers\Portal\Trainers;

use App\Events\TrainingProvisionEnded;
use App\Events\TrainingProvisionStarted;
use App\Events\WorkplanModuleEnded;
use App\Events\WorkplanModuleStarted;
use App\Http\Controllers\Controller;
use App\Models\WorkPlan;
use App\Models\WorkPlanModule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class WorkplanModuleController extends Controller
{
    /**
     * Start a module training.
     *
     * @param  Request  $request
     * @param  WorkPlanModule  $workplanModule
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function start(Request $request, WorkPlanModule $workplanModule)
    {
        //  Authorize the request
        // $this->authorize('start', $workplanModule);

        //  Set the provision just begun flag to false
        $provisionJustStarted = false;

        //  Start a database transaction
        DB::transaction(function() use ($workplanModule, &$provisionJustStarted){
            //  Get the authenticated user
            $user = Auth::user();

            //  Start the module
            $workplanModule->start($provisionJustStarted);

            //  Check if the provision has just begun
            if($provisionJustStarted) {
                //  Get the training request
                $trainingRequest = $workplanModule->workplan->trainingRequest;

                //  Throw a training provision started event
                event(new TrainingProvisionStarted($trainingRequest, $user));
            }

            //  Throw an event to signify the starting of a module
            event(new WorkplanModuleStarted($workplanModule, $user));
        });      

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => $provisionJustStarted
                ? trans('alerts.success.training-provision.started') 
                : trans('alerts.success.workplan-module.started')  
        ]);  
    }

    /**
     * Start a module training.
     *
     * @param  Request  $request
     * @param  WorkPlanModule  $workplanModule
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function end(Request $request, WorkPlanModule $workplanModule)
    {
         //  Authorize the request
        //  $this->authorize('end', $workplanModule);

        //  Set the provision just begun flag to false
        $provisionJustEnded = false;

        //  Start a database transaction
        DB::transaction(function() use ($workplanModule, &$provisionJustEnded){
            //  Get the authenticated user
            $user = Auth::user();
 
            //  Start the module
            $workplanModule->end($provisionJustEnded);

            //  Throw an event to signify the starting of a module
            event(new WorkplanModuleEnded($workplanModule, $user));
 
            //  Check if the provision has just begun
            if($provisionJustEnded) {
                //  Get the training request
                $trainingRequest = $workplanModule->workplan->trainingRequest;
 
                //  Throw a training provision started event
                event(new TrainingProvisionEnded($trainingRequest, $user));
            }
         });      
 
        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => $provisionJustEnded 
                ? trans('alerts.success.training-provision.ended') 
                : trans('alerts.success.workplan-module.ended') 
        ]);         
    }
}
