<?php

namespace App\Http\Controllers\Portal\Trainers;

use App\Events\TrainingRequestSignedByTrainer;
use App\Http\Controllers\Controller;
use App\Models\Sow;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SOWController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Sow  $sow
     * @return \Illuminate\Http\Response
     */
    public function show(Sow $sow)
    {
        //  Authorize the request
        $this->authorize('view', $sow);

        //  Lazy eager load the sow relations
        $sow->load([
            'trainingRequest.workplan.modules',
            'trainingRequest.trainer.trainable', 
            'trainingRequest.topicTrainee.trainee.trainable',
            'trainingRequest.topicTrainee.topic.area.service',
        ]);

        //  Return the view
        return view('portal.trainers.sows.show', [
            'sow' => $sow,
        ]);
    }

    /**
     * Sign the SOW.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Sow  $sow
     * @return \Illuminate\Http\Response
     */
    public function sign(Request $request, Sow $sow)
    {
        //  Authorize the request
        $this->authorize('sign', [ $sow, 'trainer' ]);

        //  Set the valid flag to false
        $valid = false;

        //  Launch a database transaction
        DB::transaction(function() use ($sow, &$valid){
            //  Get the authenticated user
            $trainer = Auth::user();

            //  Get the manager
            $manager = $sow->manager;

            //  Sign the SOW as a trainer
            $sow->signAsATrainer($trainer, $manager); 

            //  Check if the signature is valid
            if($valid = $sow->managerSignatureIsValid()) {
                //  Get the training request
                $trainingRequest = $sow->trainingRequest;

                //  Update the request status
                $trainingRequest->setStatus('AWAITING_COMMENCEMENT');
                
                //  Launch a signed event
                event(new TrainingRequestSignedByTrainer($trainingRequest));
            }
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            ($valid ? 'success' : 'error') => $valid 
                ? trans('alerts.success.sow.signed_by_trainer') 
                : trans('alerts.error.sow.signing')
        ]);
    }

    /**
     * Ability to download sow
     */

    public function download(Sow $sow)
    {
        // eager sow relationships
        $sow->load([
            'trainingRequest.workplan.modules',
            'trainingRequest.trainer.trainable',
            'trainingRequest.courseTrainee.trainee.trainable',
            'trainingRequest.courseTrainee.course.area.service',
        ]);

        $managerSignitureFilePath = 'img/sows/verified-manager.png';

        $trainerSignitureFilePath = 'img/sows/verified-trainer.png';

        $data = [
            'sow_no' => $sow->sow_no,
            'contract_no' => $sow->contract_no,
            'trainer_name' => $sow->trainingRequest->trainer->trainable->name,
            'trainee_name' => $sow->trainingRequest->courseTrainee->trainee->trainable->name,
            'course_name' => $sow->trainingRequest->courseTrainee->course->name,
            'service_name' => $sow->trainingRequest->courseTrainee->course->area->service->name,
            'area_name' => $sow->trainingRequest->courseTrainee->course->area->name,
            'modules' => $sow->trainingRequest->workplan->modules,
            'commencement_date' => $sow->commencement_date,
            'termination_date' => $sow->termination_date,
            'module_count' => $sow->trainingRequest->workplan->modules->count(),
            'deliverables' => $sow->deliverables,
            'fee' => $sow->fee,
            'fee_arrangement' => $sow->fee_arrangement,
            'manager_name' => $sow->manager->name,
            'manager_signature_date' => $sow->manager_signature_date,
            'manager_signiture' => file($managerSignitureFilePath),
            'trainer_signature_date' => $sow->trainer_signature_date,
            'trainer_signiture' => file($trainerSignitureFilePath)

        ];

        $pdf = PDF::loadView('components.pdf.sow', $data);

        return $pdf->download('sow.pdf');
    }
}
