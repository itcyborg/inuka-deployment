<?php

namespace App\Http\Controllers\Portal\Trainers;

use App\Events\PasswordChangedEvent;
use App\Http\Controllers\Controller;
use App\Http\Requests\MyProfileRequest;
use App\Models\County;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AccountController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show()
    {
        // the authenticated user
        $user = Auth::user();

        /**First, authorization check for user */
        $this->authorize('viewProfile', $user);

        //  Get the counties sorted alphabeticaally
        $counties = County::oldest('name')->get();

        // Return response to view
        return view('portal.trainers.profiles.account', compact('user', 'counties'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(MyProfileRequest $request)
    {
        // Get current auth instance
        $user = Auth::user();

        /**First, authorization check for user */
        $this->authorize('updateProfile', $user);

        //validate request data
        $data = $request->all();

        // Initiate db transaction
        DB::transaction(function() use ($data, $user){
            $user->update($data);
        });

        // Return response to view
        //  Every action should return with a notification to the user
        return redirect()->back()->with([
            'success' => trans('alerts.success.user.profile-updated')
        ]);
    }
}
