<?php

namespace App\Http\Controllers\Portal\Trainers;

use App\Events\TrainingRequestAccepted;
use App\Events\TrainingRequestDeclined;
use App\Http\Controllers\Controller;
use App\Http\Requests\CommentRequest;
use App\Models\RatingParameter;
use App\Models\TrainingRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class TrainingRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index(): View
    {
        //  Authorize the request
        $this->authorize('viewAny', TrainingRequest::class);

        //  Get the authenticated user
        $user = Auth::user();

        //  Get the trainee record
        $trainer = $user->getTrainerProfile();

        //  Determine the type of training request that will be loaded
        $type = request()->query('type') == 'provisions' ? 'provisions' : 'requests';

        //  Get all the training requests
        $trainingRequests = $trainer->trainingRequests()->type($type)->with([
                'trainer', 'topicTrainee.topic', 'topicTrainee.trainee'
            ])->whereNotIn('status', config('settings.training_request.status.exclude.trainer'))
            ->latest('updated_at')
            ->get();

        //  Return a list of all raised training requests
        return view('portal.trainers.training-requests.index', [
            'trainingRequests' => $trainingRequests,
            'type' => $type
        ]);
    }

    /**
     * Display the specified training request.
     *
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(TrainingRequest $trainingRequest)
    {
        //  Authorize the request
        $this->authorize('view', $trainingRequest);

        //  Lazy eager load relations
        $trainingRequest->load([
            'sow', 'workplan.modules' => function($query){
                $query->oldest('start_date');
            },
            'workplan.modules.uploads',
            'workplan.modules.moduleTemplate.uploads',
            'topicTrainee.topic.area.service', 'trainer.trainable',
            'topicTrainee.trainee.trainable',
            'ratings'
        ]);

        //  get all rating parameters of entity trainee and
        //  type rating
        $criteria = RatingParameter::where([
            ['entity', 'trainee'], ['type', 'rating']
        ])->get();

        //  Return a view with all the trainer information
        return view('portal.trainers.training-requests.show', [
            'trainingRequest' => $trainingRequest,
            'criteria' => $criteria
        ]);
    }

        /**
     * Activate the specified training request.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return \Illuminate\Http\RedirectResponse
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function accept(Request $request, TrainingRequest $trainingRequest): RedirectResponse
    {
        //  Authorize the request
        $this->authorize('accept', $trainingRequest);

        //  Launch a database transaction
        DB::transaction(function() use ($trainingRequest){
            //  Update the training request to the status 'AWAITING_PRE-TRAINING_EVALUATION'
            $trainingRequest->setStatus('AWAITING_PRE-TRAINING_EVALUATION');

            // Update the responded_at time
            $trainingRequest->update([
                'responded_at' => now(),
            ]);

            event(new TrainingRequestAccepted($trainingRequest));
        });

        //  Redirect to the show page
        return redirect()->route('portal.trainers.training-requests.index')->with([
            'success' => trans('alerts.success.training-request.accepted')
        ]);
    }

    /**
     * Decline the specified training request.
     *
     * @param \Illuminate\Http\Request
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return \Illuminate\Http\RedirectResponse
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function decline(CommentRequest $request, TrainingRequest $trainingRequest): RedirectResponse
    {
        ///  Authorize the request
        $this->authorize('decline', $trainingRequest);

        /**
         * Steps on rejection
         * Step 1: Give reason and save to database
         * Step 2: Change status of training request
         * Step 3: Trigger notification event
         */

        //  Get the validated comment data
        $data = $request->validated();

        //  Launch a database transaction
        DB::transaction(function() use ($request, $trainingRequest, $data){
            //Update the specific training request status to 'REJECTED_BY_THE_TRAINER'
            $trainingRequest->setStatus('REJECTED_BY_THE_TRAINER');

            // Update the responded_at time
            $trainingRequest->update([
                'responded_at' => now(),
            ]);

            //Create comment for rejaction reason
            $comment = $trainingRequest->comment()->create($data);

            //Trigger notification event
            event(new TrainingRequestDeclined($trainingRequest, $data['comment']));
        });

        //  Redirect to the show page
        return redirect()->route('portal.trainers.training-requests.index')->with([
            'success' => trans('alerts.success.training-request.declined')
        ]);
    }
}
