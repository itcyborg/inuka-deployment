<?php

namespace App\Http\Controllers\Portal\Trainers;

use App\Events\TraineeRatingComplete;
use App\Events\TrainingProvisionComplete;
use App\Http\Controllers\Controller;
use App\Http\Requests\RatingRequest;
use App\Models\Rating;
use App\Models\TrainingRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class RatingController extends Controller
{
     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(RatingRequest $request, TrainingRequest $trainingRequest)
    {
        //  Authorize the request
        $this->authorize('create', [ Rating::class, $trainingRequest ]);

        //  Get the validated data
        $data = $request->validated();

        //  Store Ratings.
        DB::transaction(function() use ($data, $trainingRequest){
            //  Get the authentication ID
            $user = Auth::user();

            //  loop through each rating
            foreach ($data['ratings'] as $paramaterId => $details) {
                $trainingRequest->ratings()->updateOrCreate([
                    'user_id' => $user->id,
                    'rateable_id' => $paramaterId,
                    'rateable_type' => 'rating-parameters',
                    'type' => 'training-request',
                    'entity_type' => 'trainees',
                    'entity_id' => $trainingRequest->topicTrainee->trainee_id
                ],[
                    'value' => $details['value'],
                    'description' => $details['description'],
                ]);
            }

            //Store the trainees rating in db
            $trainingRequest->topicTrainee
                ->trainee->storeAverageRating($trainingRequest, 'trainees');

            //trigger event for trainees' rating complete
            event(new TraineeRatingComplete($trainingRequest));

            //  Check if provision is completed
            if($trainingRequest->isCompleted()){
                //change status of our training provision to complete
                $trainingRequest->setStatus('COMPLETED');

                //  Throw a completion event
                event(new TrainingProvisionComplete($trainingRequest));
            }
        });

        //  Redirect to the previous page and flash a message
        return redirect()->back()->with([
            'success' => trans('alerts.success.rating.trainer.created')
        ]);
    }
}
