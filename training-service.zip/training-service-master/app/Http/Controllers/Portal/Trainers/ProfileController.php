<?php

namespace App\Http\Controllers\Portal\Trainers;

use App\Http\Controllers\Controller;
use App\Models\Trainer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //  Authorize the request
        $this->authorize('view',  $trainer = Auth::user()->trainer);

        //  Lazy eager load the trainer relations
        $trainer->load([
            'trainable.organization',
            'trainable.county', 'uploads',
            'topics.area.service', 'languages',
            'qualifications' => function($query){
                return $query->latest('year');
            }, 'experiences' => function($query){
                return $query->latest('start_year');
            }
        ]);

        //  Return a view with all the trainer information
        return view('portal.trainers.profiles.show', [
            'trainer' => $trainer
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        //  Authorize the request
        $this->authorize('view',  $trainer = Auth::user()->trainer);

        //  Return a view with all the trainer information
        return view('portal.trainers.profiles.edit', [
            'trainer' => $trainer
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Trainer  $trainer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Trainer $trainer)
    {
        //
    }
}
