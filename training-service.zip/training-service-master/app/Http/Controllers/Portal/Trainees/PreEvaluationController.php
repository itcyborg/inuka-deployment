<?php

namespace App\Http\Controllers\Portal\Trainees;

use App\Events\PreEvaluationSubmitted;
use App\Events\WorkplanPreEvaluated;
use App\Http\Controllers\Controller;
use App\Http\Requests\PreEvaluationRequest;
use App\Models\Evaluation;
use App\Models\TrainingRequest;
use App\Models\WorkPlanModule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PreEvaluationController extends Controller
{
    /**
     * Display the training request feedback form.
     *
     * @param \App\Models\TrainingRequest $trainingRequest
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function create(TrainingRequest $trainingRequest)
    {
        //  Authorize the request
        $this->authorize('create', [ Evaluation::class, $trainingRequest, 'PRE' ]);

        //  Lazy load the training request relations
        $trainingRequest = $trainingRequest->load([
            'workplan.modules'
        ]);

        //return view with the specific training request & type of evaluation
        return view('portal.trainees.evaluations.pre.create', [
            'trainingRequest' => $trainingRequest
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     * &
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(PreEvaluationRequest $request, TrainingRequest $trainingRequest)
    {
        //  Authorize the request
        $this->authorize('create', [ Evaluation::class, $trainingRequest, 'PRE' ]);

        //  Get the validated data
        $data = $request->validated();

        //  Declare an empty evaluation
        $evaluation = null;

        //  launch a database transaction
        DB::transaction(function () use ($trainingRequest, $data, &$evaluation) {
            //  Get the workplan
            $workplan = $trainingRequest->workplan;

            //  Get the authenticated user
            $user = Auth::user();

            //  Save the Evaluation.
            $evaluation = $workplan->evaluations()->create([
                'user_id' => $user->id,
                'type' => 'PRE',
                'suggestion' => $data['suggestion'],
            ]);

            //  Store Module Ratings.
            foreach ($data['modules'] as $module => $details) {
                $evaluation->ratings()->create([
                    'rateable_id' => $module,
                    'rateable_type' => WorkPlanModule::make()->getMorphClass(),
                    'user_id' => $user->id,
                    'type' => 'pre-evaluation',
                    'value' => $details['scale'],
                    'description' => $details['reason'],
                ]);
            }

            // Throw a pre evaluation submitted event
            event(new PreEvaluationSubmitted($workplan, $user));

            //  Determine the number of trainers in an organization
            $traineeCount = $user->isADirectTrainee() ? 1 : $user->organization->users->count();

            //  Check if the evaluation is the final evaluation and launch a
            //  final event if that is the case
            if($workplan->hasReceivedAllEvaluations($traineeCount, 'PRE')){
                //  Change the status of the training request
                $trainingRequest->setStatus('AWAITING_MANAGER_SIGNATURE');

                //  Throw a workplan pre-evaluated event.
                event(new WorkplanPreEvaluated($workplan));
            }
        });

        //  Redirect to the previous page and flash a message
        return redirect()->route('portal.trainees.pre-evaluations.show', [
            'evaluation' => $evaluation
         ])->with([
            'success' => trans('alerts.success.evaluation.created')
        ]);
    }

    /**
     * Display the evaluation results.
     *
     * @param \App\Models\Evaluation $evaluation
     * @return View
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Evaluation $evaluation)
    {
        //  Authorize the request
        $this->authorize('view', $evaluation);

        //  Lazy eager load the relations
        $evaluation->load(['workplan', 'ratings' => function($query){
            $query->where('rateable_type', 'work_plan_module');
        }]);

        //  Load the saved ratings
        $evaluation->loadSavedRatings();

        //  return view with the specific training request & type of evaluation
        return view('portal.trainees.evaluations.pre.show', [
            'evaluation' => $evaluation
        ]);
    }

    /**
     * Display the training request feedback form.
     *
     * @param \App\Models\Evaluation $evaluation
     * @return View
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function edit(Evaluation $evaluation)
    {
        //  Authorize the request
        $this->authorize('update', $evaluation);

        //  Lazy eager load the relations
        $evaluation->load(['workplan', 'ratings' => function($query){
            $query->where('rateable_type', 'work_plan_module');
        }]);

        //  Load the saved ratings
        $evaluation->loadSavedRatings();

        //  return view with the specific training request & type of evaluation
        return view('portal.trainees.evaluations.pre.edit', [
            'evaluation' => $evaluation
        ]);
    }

    /**
     * Update an evaluation.
     *
     * @param  PreEvaluationRequest  $request
     * @param  Evaluation  $evaluation
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(PreEvaluationRequest $request, Evaluation $evaluation)
    {
        //  Authorize the request
        $this->authorize('update', $evaluation);

        //  Get the validated data
        $data = $request->validated();

        //  launch a database transaction
        DB::transaction(function () use ($evaluation, $data) {
            //  Update the Evaluation.
            $evaluation->update([
                'suggestion' => $data['suggestion'],
            ]);

            //  Update the module ratings.
            foreach ($data['modules'] as $module => $details) {
                $evaluation->ratings()->updateOrCreate([
                    'rateable_type' => 'work_plan_module',
                    'rateable_id' => $module,
                    'user_id' => Auth::id(),
                ],[
                    'value' => $details['scale'],
                    'description' => $details['reason'],
                ]);
            }
        });

        //  Redirect to the previous page and flash a message
        return redirect()->route('portal.trainees.pre-evaluations.show', [
            'evaluation' => $evaluation
         ])->with([
            'success' => trans('alerts.success.evaluation.updated')
        ]);
    }
}
