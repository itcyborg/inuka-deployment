<?php

namespace App\Http\Controllers\Portal\Trainees\Reports;

use App\Http\Controllers\Controller;
use App\Models\Rating;

class TrainerRatingReportController extends Controller
{
    /**
     * Generate all trainer rating reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateTrainerRatingReports', Rating::class);

        // get all trainer type ratings with relationships
        $ratings = Rating::with(['user', 'rateable'])->get();

        //  Get only the trainer ratings
        $trainerRatings = $ratings->where('type', 'trainer');

        return view('portal.trainees.reports.trainer-ratings', [
            'trainerRatings' => $trainerRatings
        ]);
    }
}
