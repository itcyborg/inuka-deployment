<?php

namespace App\Http\Controllers\Portal\Trainees\Reports;

use App\Http\Controllers\Controller;
use App\Models\Evaluation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PreEvaluationReportController extends Controller
{
    /**
     * Generate all pre-evaluation reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        // $this->authorize('generatePreEvaluationReport', Evaluation::class);

        //  Get the authenticated user
        $user = Auth::user();

        $preEvaluations = $user->evaluations()->where('type', 'PRE')->get();

        return view('portal.trainees.reports.pre-evaluation', [
            'preEvaluations' => $preEvaluations
        ]);
    }
}
