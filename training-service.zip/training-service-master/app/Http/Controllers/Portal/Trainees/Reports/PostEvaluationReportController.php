<?php

namespace App\Http\Controllers\Portal\Trainees\Reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostEvaluationReportController extends Controller
{
    /**
     * Generate all post-evaluation reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        // $this->authorize('generatePostEvaluationReport', Evaluation::class);

        //  Get the authenticated user
        $user = Auth::user();

        $postEvaluations = $user->evaluations()->where('type', 'POST')->get();

        return view('portal.trainees.reports.post-evaluation', [
            'postEvaluations' => $postEvaluations
        ]);
    }
}
