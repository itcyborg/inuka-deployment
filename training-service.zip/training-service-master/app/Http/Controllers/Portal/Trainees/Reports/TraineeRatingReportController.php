<?php

namespace App\Http\Controllers\Portal\Trainees\Reports;

use App\Http\Controllers\Controller;
use App\Models\Rating;

class TraineeRatingReportController extends Controller
{
    /**
     * Generate all trainee rating reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateTraineeRatingReports', Rating::class);

        // get all trainee type ratings with relationships
        $ratings = Rating::with(['user', 'rateable'])->get();

        $traineeRatings = $ratings->where('type', 'trainee');

        return view('portal.trainees.reports.trainee-ratings', [
            'traineeRatings' => $traineeRatings
        ]);
    }
}
