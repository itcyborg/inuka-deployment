<?php

namespace App\Http\Controllers\Portal\Trainees\Reports;

use App\Http\Controllers\Controller;
use App\Models\TrainingRequest;
use Illuminate\Support\Facades\Auth;

class TrainingRequestReportController extends Controller
{
    /**
     * Generate all training request reports.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function index()
    {
        //  Authorize the request
        $this->authorize('generateTrainingRequestReports', TrainingRequest::class);

        //  Get the authenticated user
        $user = Auth::user();

        //  Get the trainee record
        $trainee = $user->getTraineeProfile();

        //  Get all the training requests that belong to a trainee
        $trainingRequests = $trainee->trainingRequests()->with([
                'trainer', 'topicTrainee.topic', 'topicTrainee.trainee'
            ])->whereNotIn('status', config('settings.training_request.status.exclude.trainer'))
            ->latest('updated_at')
            ->get();

        return view('portal.trainees.reports.training-request', [
            'trainingRequests' => $trainingRequests
        ]);
    }
}
