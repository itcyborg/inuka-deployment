<?php

namespace App\Http\Controllers\Portal\Trainees;

use App\Http\Controllers\Controller;
use App\Models\RatingParameter;
use App\Models\Setting;
use App\Models\TrainingRequest;
use App\Models\User;
use App\Models\WorkPlan;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class TrainingRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function index()
    {
        //  Authorize the request
        $this->authorize('viewAny', TrainingRequest::class);

        //  Get the authenticated user
        $user = Auth::user();

        //  Get the trainee record
        $trainee = $user->getTraineeProfile();

        //  Get all the training requests
        $trainingRequests = $trainee->trainingRequests()->with([
            'trainer', 'topicTrainee.topic', 'topicTrainee.trainee'
        ])->whereNotIn('status', config('settings.training_request.status.exclude.trainee'))
            ->latest('updated_at')
            ->get();

        //  Return a list of all raised training requests
        return view('portal.trainees.training-requests.index', [
            'trainingRequests' => $trainee->trainingRequests->load('workplan'),
            'users' => User::all(),
        ]);
    }

    /**
     * Display the specified training request.
     *
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(TrainingRequest $trainingRequest): View
    {
        //  Authorize the request
        $this->authorize('view', $trainingRequest);

        //  Lazy eager load relations
        $trainingRequest->load([
            'workplan.modules' => function($query){
                $query->oldest('start_date');
            },
            'topicTrainee.topic.area.service', 'trainer.trainable',
            'topicTrainee.trainee.trainable', 'workplan.evaluations', 'ratings.entity'
        ]);

        //  get all rating parameters of entity trainee and
        //  type rating
        $criteria = RatingParameter::where([
            ['entity', 'trainer'], ['type', 'rating']
        ])->get();

        //  Return a view with all the trainer information
        return view('portal.trainees.training-requests.show', [
            'trainingRequest' => $trainingRequest,
            'criteria' => $criteria
        ]);
    }
}
