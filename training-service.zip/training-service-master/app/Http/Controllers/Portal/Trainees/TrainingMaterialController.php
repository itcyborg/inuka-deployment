<?php

namespace App\Http\Controllers\Portal\Trainees;

use App\Http\Controllers\Controller;
use App\Models\Upload;

class TrainingMaterialController extends Controller
{
    /**
     * Download the specified upload.
     *
     * @param \App\Models\Upload
     * @return \Illuminate\Http\Response
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function download(Upload $upload)
    {
        //  Check if the user is authorized
        $this->authorize('download', $upload);    

        //  Download the document
        return response()->download(public_path($upload->path));    
    }
}