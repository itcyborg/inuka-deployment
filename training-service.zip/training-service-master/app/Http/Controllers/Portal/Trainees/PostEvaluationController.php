<?php

namespace App\Http\Controllers\Portal\Trainees;

use App\Events\PostEvaluationSubmitted;
use App\Events\TrainingProvisionComplete;
use App\Http\Controllers\Controller;
use App\Http\Requests\PostEvaluationRequest;
use App\Models\Evaluation;
use App\Models\RatingParameter;
use App\Models\TrainingRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PostEvaluationController extends Controller
{
    /**
     * Display the training request feedback form.
     *
     * @param \App\Models\TrainingRequest $trainingRequest
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function create(TrainingRequest $trainingRequest, RatingParameter $criteria)
    {
        //  Authorize the request
        $this->authorize('create', [ Evaluation::class, $trainingRequest, 'POST' ]);

        //  Lazy load the training request relations
        $trainingRequest = $trainingRequest->load([
            'workplan.modules'
        ]);

         //  get all rating parameters of entity trainee and
        //  type rating
        $criteria = RatingParameter::where([
            ['entity', 'workplan'], ['type', 'post-evaluation']
        ])->get();

        //return view with the specific training request & type of evaluation
        return view('portal.trainees.evaluations.post.create', [
            'trainingRequest' => $trainingRequest,
            'criteria' => $criteria
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function store(PostEvaluationRequest $request, TrainingRequest $trainingRequest)
    {
        //  Authorize the request
        $this->authorize('create', [ Evaluation::class, $trainingRequest, 'POST' ]);

        //  Get the validated data
        $data = $request->validated();

        //  Declare an empty evaluation
        $evaluation = null;

        //  launch a database transaction
        DB::transaction(function () use ($trainingRequest, $data, &$evaluation) {
            //  Get the workplan
            $workplan = $trainingRequest->workplan;


            //  Get the authenticated user
            $user = Auth::user();

            //  Save the Evaluation.
            $evaluation = $workplan->evaluations()->create([
                'user_id' => $user->id,
                'type' => 'POST',
                'suggestion' => $data['suggestion'],
            ]);

            //  Store Module Ratings.
            foreach ($data['modules'] as $module => $details) {
                $evaluation->ratings()->create([
                    'rateable_id' => $module,
                    'rateable_type' => 'work_plan_module',
                    'user_id' => $user->id,
                    'type' => 'post-evaluation',
                    'value' => $details['scale'],
                    'description' => $details['reason'],
                ]);
            }

            // Throw a post evaluation submitted event
            event(new PostEvaluationSubmitted($workplan, $user));

            //  Check if provision is completed
            if($trainingRequest->isCompleted()){
                //change status of our training provision to complete
                $trainingRequest->setStatus('COMPLETED');

                //  Throw a completion event
                event(new TrainingProvisionComplete($trainingRequest));
            }
        });

        //  Redirect to the previous page and flash a message
        return redirect()->route('portal.trainees.training-requests.show', [
            'training_request' => $trainingRequest
         ])->with([
            'success' => trans('alerts.success.post-evaluation.created')
        ]);
    }

    /**
     * Display the evaluation results.
     *
     * @param \App\Models\Evaluation $evaluation
     * @return View
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function show(Evaluation $evaluation)
    {
        //  Authorize the request
        $this->authorize('view', $evaluation);

        //  Lazy eager load the relations
        $evaluation->load(['workplan', 'ratings' => function($query){
            $query->where('rateable_type', 'work_plan_module');
        }]);

        //  Load the saved ratings
        $evaluation->loadSavedRatings();

        //  get all rating parameters of entity trainee and
        //  type rating
        $criteria = RatingParameter::where([
            ['entity', 'workplan'], ['type', 'post-evaluation']
        ])->get();

        //  return view with the specific training request & type of evaluation
        return view('portal.trainees.evaluations.post.show', [
            'evaluation' => $evaluation,
            'criteria' => $criteria
        ]);
    }

    /**
     * Display the training request feedback form.
     *
     * @param \App\Models\Evaluation $evaluation
     * @return View
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function edit(Evaluation $evaluation)
    {
        //  Authorize the request
        $this->authorize('update', $evaluation);

        //  Lazy eager load the relations
        $evaluation->load(['workplan', 'ratings' => function($query){
            $query->where('rateable_type', 'work_plan_module');
        }]);

        //  Load the saved ratings
        $evaluation->loadSavedRatings();

        //  return view with the specific training request & type of evaluation
        return view('portal.trainees.evaluations.post.edit', [
            'evaluation' => $evaluation
        ]);
    }

    /**
     * Update an evaluation.
     *
     * @param  PreEvaluationRequest  $request
     * @param  Evaluation  $evaluation
     * @return \Illuminate\Http\Response
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(PostEvaluationRequest $request, Evaluation $evaluation)
    {
        //  Authorize the request
        $this->authorize('update', $evaluation);

        //  Get the validated data
        $data = $request->validated();

        //  launch a database transaction
        DB::transaction(function () use ($evaluation, $data) {
            //  Update the Evaluation.
            $evaluation->update([
                'suggestion' => $data['suggestion'],
            ]);

            //  Update the module ratings.
            foreach ($data['modules'] as $module => $details) {
                $evaluation->ratings()->updateOrCreate([
                    'rateable_type' => 'work_plan_module',
                    'rateable_id' => $module,
                    'user_id' => Auth::id(),
                ],[
                    'value' => $details['scale'],
                    'description' => $details['reason'],
                ]);
            }
        });

        //  Redirect to the previous page and flash a message
        return redirect()->route('portal.trainees.post-evaluations.show', [
            'evaluation' => $evaluation
         ])->with([
            'success' => trans('alerts.success.post-evaluation.updated')
        ]);
    }
}
