<?php

namespace App\Http\Controllers\Portal\Trainees;

use App\Http\Controllers\Controller;
use App\Models\Topic;
use App\Models\Trainee;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //  Authorize the request
        $this->authorize('viewAny', Trainee::class);

        //  Get the authenticated user
        $user = Auth::user();

        //  Get the trainee record
        $trainee = $user->organization
            ->trainee()
            ->with(['trainable', 'topics.area.service'])
            ->first();

        //  Fetch all topics
        $topics = Topic::with(['area.service'])->get();

        //  Return a view with trainee data
        return view('portal.trainees.profiles.show', [
            'trainee' => $trainee,
            'topics' => $topics
        ]);
    }
}
