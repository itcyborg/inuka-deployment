<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class TraineeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
    
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //  Create repetitive rules
        $uniqueRule = Rule::unique('organizations')->ignore($this->organization->id ?? null);
        $requiredRule = Rule::requiredIf(!$this->organization) ?: 'nullable';

        //  Return the validation rules
        return [
            'public_id' => [ $requiredRule, 'string', $uniqueRule ],
            'county_id' => [ 'nullable', 'numeric', 'exists:counties,id' ],
            'name' => [ $requiredRule, 'string', 'min:2', 'max:191' ],
            'email' => [ $requiredRule, 'email', $uniqueRule ],
            'telephone' => [ $requiredRule, 'string', 'min:8', 'max:15', $uniqueRule ],
            'status' => [ $requiredRule, Rule::in(config('settings.organization.status')) ],
            'locality' => [ 'nullable', 'string' ],
            'bio' => ['nullable', 'string', 'min:3'],
            'business_sector' => ['nullable', 'string', 'min:0']
        ];
    }
}
