<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OrganizationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    protected function prepareForValidation(): void
    {
        //  Define the error bag dynamically
        $this->errorBag = $this->{'_bag'};
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //  Return the validation rules
        return [
            'public_id' => [ 'required', 'string' ],
            'county_id' => [ 'nullable', 'numeric', 'exists:counties,id' ],
            'name' => [ 'required', 'string', 'min:3', 'max:191' ],
            'email' => [ 'required', 'email', 'min:3', 'max:191' ],
            'telephone' => [ 'string', 'min:8', 'max:15' ],
            'locality' => [ 'nullable', 'string' ],
            'bio' => [ 'nullable', 'string' ],
            'business_sector' => [ 'nullable', 'string' ],
        ];
    }
}
