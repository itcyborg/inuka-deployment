<?php

namespace App\Http\Requests;

use App\Models\Organization;
use App\Traits\HasLocations;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    protected function prepareForValidation(): void
    {        
        //  Get the organization and its properties
        $organization = Organization::publicId($this->organization_uid)->first();
        $publicId = $this->organization_uid ?? ($this->user ? $this->user->organization->public_id : null);
        $organizationId = $organization->id ?? ($this->user ? $this->user->organization->id : null);

        //  Merge the derived items into the request
        $this->merge([
            'organization_public_id' => $publicId,
            'organization_id' => $organizationId,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function rules(): array
    {
        //  Create repetitive rules
        $uniqueRule = Rule::unique('users')->ignore($this->user->id ?? null);
        $requiredRule = Rule::requiredIf(!$this->user) ?: 'nullable';

        //  Return the validation rules
        return [
            'county_id' => [ $requiredRule, 'numeric', 'exists:counties,id' ], 
            'organization_public_id' => [ $requiredRule, 'exists:organizations,public_id' ],
            'organization_id' => [ $requiredRule, 'exists:organizations,id' ],
            'name' => [ $requiredRule, 'string', 'min:2', 'max:191' ],
            'email' => [ $requiredRule, 'email', $uniqueRule ],
            'telephone' => [ $requiredRule, 'string', 'min:8', 'max:15', $uniqueRule ],
            'status' => [ $requiredRule, Rule::in(config('settings.user.status')) ],
            'locality' => [ $requiredRule, 'string' ],
            'roles' => [ $requiredRule, 'array' ],
            'roles.*' => [ Rule::in(config('settings.roles.trainee')) ],
        ];
    }
}
