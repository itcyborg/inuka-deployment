<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class TrainingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    protected function prepareForValidation(): void
    {
        //  Define the error bag dynamically
        $this->errorBag = $this->{'_bag'};

        //  Get the topic trainee record from the pivot table
        $pivot = $this->trainee
            ->topicTrainees()
            ->where('topic_id', $this->topic->id)
            ->firstOrFail();

        //  Merge the derived items into the request
        $this->merge([
            'topic_trainee_id' => $pivot->id,
            'trainer_id' => $this->trainer->id,
            'status' => 'AWAITING_PUBLISHING',
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'topic_trainee_id' => [ 'required', 'numeric', 'exists:topic_trainee,id' ],
            'trainer_id' => [ 'required', 'numeric', 'exists:trainers,id' ],
            'manager_id' => [ 'required', 'numeric', 'exists:users,id' ],
            'status' => [ 'required', 'max:1024', Rule::in( config('settings.training_request.status.requests') ) ],
        ];
    }
}