<?php

namespace App\Http\Requests;

use App\Models\User;
use App\Rules\NotCurrentPassword;
use App\Rules\MatchesCurrentPassword;
use App\Services\ValidationService;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class MyProfileRequest extends FormRequest
{
    /**
     * Variable to store the authenticated user
     *
     * @var User
     */
    public User $user;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    protected function prepareForValidation(): void
    {
        //  Define the error bag dynamically
        $this->errorBag = $this->{'_bag'};

        //  Define the user
        $this->user = $this->user();
    }

    /**
     * Configure the validator instance.
     * Its a hook
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return void
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function withValidator($validator)
    {
        //  Get the authenticated user
        $user = Auth::user();

        //  Get the authenticated user
        $this->merge([
            //  If no previous password get the current password
            'password' => $this->password
                ? Hash::make($this->password)
                : $this->user->password,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function rules(ValidationService $validationService)
    {
        //  Get the user rules from the validation service. Except the passwordrule
        $userRules = Arr::except($validationService->user($this->user), ['password']);

        //  Return a full list of user validation rules.
        return array_merge($userRules, [
            'current_password' => ['nullable', 'string', new MatchesCurrentPassword],
            'password' => ['required_with:current_password', 'nullable', 'string', 'confirmed', new NotCurrentPassword],
        ]);
    }
}
