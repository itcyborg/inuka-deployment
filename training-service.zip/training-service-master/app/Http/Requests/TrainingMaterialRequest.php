<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class TrainingMaterialRequest extends FormRequest
{
    /**
     * Define the validation error bag.
     *
     * @var $errorBag
     */
    protected $errorBag = 'training-materials-modal';

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    protected function prepareForValidation(): void
    {
        //  Define the error bag dynamically
        $this->errorBag = $this->{'_bag'};
        
        //  Merge the derived items into the request
        $this->merge([
            'user_id' => Auth::id(),
            'path' => $this->upload(),
            'type' => 'training-material'
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //  Create repetitive rules
        $requiredRule = Rule::requiredIf(!$this->upload) ?: 'nullable';

        return [
            'user_id' => [ 'required', 'numeric', 'exists:users,id' ],
            'name' => [ 'required', 'string', 'min:3' ],
            'file' => [ $requiredRule, 'max:1024', 'mimes:doc,docx,pdf,jpg,jpeg,png' ],
            'path' => [ 'required', 'string'],
            'type' => [ 'required', Rule::in(config('settings.upload.types'))]
        ];
    }

    /**
     * Upload the training material
     *
     * @return string|null
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function upload()
    {
        //  Upload if the file if it exists
        if($this->file) {
            //  File path and extension
            $path = "public/training-materials";
            $extension = $this->file->extension();
    
            //  Create the file name
            $name = "$this->name.$extension";
    
            //  Process and return the path
            return str_replace(
                'public/', 'storage/', $this->file->storeAs($path, $name), 
            );
        }

        //  Return the defined upload path
        return $this->upload->path ?? null;
    }
}