<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SowRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    protected function prepareForValidation(): void
    {
        //  Define the error bag dynamically
        $this->errorBag = $this->{'_bag'};
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //  Define global rules
        $requiredRule = Rule::requiredIf(!$this->sow) ?: 'nullable';

        return [
            'contract_no' => [ $requiredRule, 'string', 'min:3', 'max:191' ],
            'sow_no' => [ $requiredRule, 'string', 'min:3', 'max:191' ],
            'fee' => [ $requiredRule, 'numeric', 'min:0' ],
            'fee_arrangement' => [ $requiredRule, 'string', 'min:3' ],
            'effort_level' => [ $requiredRule, 'numeric', 'min:0' ],
            'effort_level_unit' => [ $requiredRule, 'string', Rule::in( config('settings.effort_level_units') ) ],
            'deliverables' => [ $requiredRule, 'string', 'min:3' ],
            'sow_date' => [ $requiredRule, 'date' ],
            'commencement_date' => [ $requiredRule, 'date', 'before_or_equal:termination_date' ],
            'termination_date' => [ $requiredRule, 'date' ],
        ];
    }
}
