<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class RatingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    protected function prepareForValidation(): void
    {
        //  Define the error bag dynamically
        $this->errorBag = $this->{'_bag'};
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'ratings.*.value' => 'rating value',
            'ratings.*.description' => 'reason',
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'ratings.*.value.required' => 'This :attribute is required',
            'ratings.*.description.required' => 'This :attribute is required',
        ];
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ratings.*.value' => [ 'required', 'numeric', 'min:0' ],
            'ratings.*.description' => [ 'required', 'min:3', 'max:191', 'string'],
        ];
    }
}
