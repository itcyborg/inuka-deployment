<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class EnsureUserCanViewPortal
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        //  Check if the user is authenticated
        if(!Auth::check()) {
            return redirect()->route('login');            
        }

        //  Get the current authenticated user
        $user = Auth::user();

        //  Check if the user is authorized
        if(!$user->canViewPortal()){
            return redirect()->route('portal.unauthorized');
        }

        //  Proceed to the request
        return $next($request);
    }
}
