<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureValidSocialProviders
{
    /**
     * Define the social authentication options 
     *
     * @var array
     */
    protected $providers = ['google', 'microsoft'];
    
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        //  Get the provider 
        $provider = $request->route('provider');

        //  Throw an error message if the wrong provider is 
        //  passed into the request
        return in_array($provider, $this->providers) 
            ? $next($request) 
            : redirect()->back()->with([
                'error' => trans('auth.socialite.invalid_provider')
            ]);
    }
}
