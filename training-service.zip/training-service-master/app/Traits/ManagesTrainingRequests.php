<?php

namespace App\Traits;

use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Support\Facades\Route;

trait ManagesTrainingRequests
{
    /**
     * Determine whether the trainee owns the training request
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return bool
     */
    public function isRequestOwner(User $user, TrainingRequest $trainingRequest): bool
    {
        //  Conditionally compute more permissions
        if(Route::is('portal.managers.*')) {
            $ownership = true;  

        } else if(Route::is('portal.trainers.*')) {
            $ownership = $this->trainerIsRequestOwner($user, $trainingRequest);  
             
        } else if(Route::is('portal.trainees.*')) {
            $ownership = $this->traineeIsRequestOwner($user, $trainingRequest);

        }

        //  Return the ownership or a default false
        return $ownership ?? false;
    }

    /**
     * Determine whether the trainer owns the training request
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return bool
     */
    public function trainerIsRequestOwner(User $user, TrainingRequest $trainingRequest)
    {
        //  Get the authenticated user's trainer profile and compare it 
        //  with the training request's training profile
        $trainer = $user->getTrainerProfile();

        //  Get the trainer ID
        $trainerId = $trainer->id ?? null;

        //  Determine the ownership
        return $trainingRequest->trainer_id === $trainerId;
    }

     /**
     * Determine whether the trainee owns the training request
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return bool
     */
    public function traineeIsRequestOwner(User $user, TrainingRequest $trainingRequest)
    {
        //  Get the authenticated user's trainee profile and compare it
        //  with the training request's training profile
        $trainee = $user->getTraineeProfile();

        //  Get the trainee ID
        $traineeId = $trainee->id ?? null;

        //  Determine the ownership
        return $trainingRequest->topicTrainee->trainee_id === $traineeId;
    }
}