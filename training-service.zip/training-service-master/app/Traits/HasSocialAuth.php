<?php

namespace App\Traits;

trait HasSocialAuth
{
    /**
     * Update of create a user's social profile from payload
     * returned by a provider.
     *
     * @param mixed $social
     * @param string $provider
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function updateSocialCredentials($social, string $provider): void
    {
        //  Define social auth details
        $this->socialAuth()->updateOrCreate([
            'user_id' => $this->id
        ], [
            'provider' => $provider,
            'provider_id' => $social->getId(),
            'token' => $social->token ?? null,
            'token_secret' => $social->tokenSecret ?? null,
            'refresh_token' => $social->refreshToken ?? null,
            'token_expires_at' => $social->expiresIn ?? null,
        ]);

        //  Check if the avatar is defined and update or create it 
        //  if it does
        if($avatar = $social->avatar ?? null) {
            $this->uploads()->updateOrCreate([
                'user_id' => $this->id, 'type' => 'avatar',
            ], [
                'path' => $avatar,
            ]);
        }
    }
}