<?php

namespace App\Traits;

trait HasSignatureKeys 
{
    /**
     * Generate RSA Public/Private Key
     *
     * @param \App\Models\User
     * @return mixed
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateSignatureKeys()
    {
        //  Create the private and public key
        $config = [
            'config' => storage_path('app/openssl.cnf'),
            'digest_alg' => 'sha512',
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ];

        //  Call the function to create the key
        $response = openssl_pkey_new($config);

        //  Extract the private key and public keys.
        openssl_pkey_export($response, $privateKey, NULL, $config);
        $publicKey = openssl_pkey_get_details($response)['key'];

        //  Store the key pair.
        return $this->signatureKeys()->create([
            'private_key' => $privateKey,
            'public_key' => $publicKey,
        ]);
    }
}