<?php

namespace App\Traits;

use App\Models\TrainingRequest;
use App\Models\User;

trait HasRatingAverages
{
    /**
     * Get the average rating of a trainee
     *
     * @param TrainingRequest $request
     * @param string $type
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function storeAverageRating(TrainingRequest $trainingRequest, string $type): void
    {
        //get collection of ratings to a specific to a training request with entity (rating parameter)
        $ratings = $this->ratings()
            ->with('rateable')
            ->where([
                ['parent_type', 'training_requests'],
                ['parent_id', $trainingRequest->id],
                ['entity_type', $type],
                ['entity_id', $this->id],
                ['type', 'training-request']
            ])->get();

        //if ratigs collection is not empty
        if ($ratings->isNotEmpty()) {
            //  Get the avarage value
            $rating = $ratings->map(function($rating){
                return $rating->value / $rating->rateable->max_rating;
            })->average();

            //  Update trainee rating
            $this->update(['rating' => $rating]);
        }
    }
}
