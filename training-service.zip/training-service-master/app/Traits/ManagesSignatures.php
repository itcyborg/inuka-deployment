<?php

namespace App\Traits;

use App\Models\User;

trait ManagesSignatures
{
    /**
     * Sign as a manager
     * 
     * @param \App\Models\User $manager
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function signAsAManager(User $manager): void
    {
        //  Create the manager's signature.
        openssl_sign(
            $this->signaturePayload($manager),
            $signature,
            $manager->signatureKeys->private_key,
            OPENSSL_ALGO_SHA256
        );

        //  Store the data.
        $this->update([
            'manager_id' => $manager->id,
            'manager_signature' => utf8_encode($signature),
            'manager_signature_date' => now(),
            'is_valid' => true,
        ]);
    }

    /**
     * Sign as a Trainer
     * 
     * @param \App\Models\User $trainer
     * @param \App\Models\User $manager
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function signAsATrainer(User $trainer, User $manager): void
    {
        //  Create the trainer's signature.
        openssl_sign(
            $this->signaturePayload($manager),
            $signature,
            $trainer->signatureKeys->private_key,
            OPENSSL_ALGO_SHA256
        );

        //  Store the data.
        $this->update([
            'trainer_id' => $trainer->id,
            'trainer_signature' => utf8_encode($signature),
            'trainer_signature_date' => now(),
        ]);
    }

    /**
     * Build the payload used in the signing of the data
     * 
     * @param \App\Models\User
     * @return json
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function signaturePayload(User $manager)
    {
        //  Determine payload used to generate the dataset
        $trainingRequest = $this->trainingRequest; 
        $workplan = $trainingRequest->workplan;

        //  Determine the trainer, trainee and topic information
        $trainer = $trainingRequest->trainer;
        $trainee = $trainingRequest->topicTrainee->trainee;
        $topic = $trainingRequest->topicTrainee->topic;

        //  Build the data payload and return a json object
        return json_encode([
            'parties' => [
                'manager' => [
                    'id' => $manager->id
                ],
                'trainer' => [
                    'id' => $trainer->id,
                    'type' => $trainer->trainable_type,
                    'trainable_id' => $trainer->trainable->id 
                ], 
                'trainee' => [
                    'id' => $trainee->id,
                    'type' => $trainee->trainable_type,
                    'trainable_id' => $trainee->trainable->id 
                ]
            ],
            'scope' => [
                'topic' => $topic->name,
                'modules' => $workplan->modules->map(function($module){
                    return $module->only(['name', 'description', 'start_date', 'end_date']);
                })
            ],
            'terms' => $this->only([
                'contract_no', 'sow_no', 
                'fee', 'fee_arrangement', 
                'effort_level', 'effort_level_unit',
                'deliverables', 'sow_date', 
                'commencement_date', 'termination_date',
            ])
        ]);
    }

    /**
     * Determine if the manager has signed
     * 
     * @return bool
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasManagerSigned(): bool
    {
        return (bool) $this->manager_signature;
    }

    /**
     * Determine if the trainer has signed
     * 
     * @return bool
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasTrainerSigned(): bool
    {
        return (bool) $this->trainer_signature;
    }

    /**
     * Determine if the manager signature is valid
     * 
     * @return bool
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function managerSignatureIsValid(): bool
    {
        //  Check if the manager has already signed
        if($this->hasManagerSigned()){
            //  Get the manager data
            $manager = $this->manager;
            $publicKey = $manager->signatureKeys->public_key;
            $signature = utf8_decode($this->manager_signature);

            //  Validate the signature
            return $this->validateSignature($this->manager, $publicKey, $signature);
        }

        //  Return a default false
        return false;
    }

    /**
     * Determine if the trainer signature is valid
     * 
     * @return bool
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainerSignatureIsValid(): bool
    {
        //  Check if the trainer has already signed
        if($this->hasTrainerSigned()){
            //  Get the trainer data
            $trainer = $this->trainer;
            $publicKey = $trainer->signatureKeys->public_key;
            $signature = utf8_decode($this->trainer_signature);

            //  Validate the signature
            return $this->validateSignature($this->manager, $publicKey, $signature);
        }

        //  Return a default false
        return false;
    }

    /**
     * Determine if the signature is valid
     * 
     * @return bool
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function validateSignature(User $manager, string $publicKey, string $signature)
    {
        //  Verify the signature using the openssl lib
        $valid = openssl_verify(
            $this->signaturePayload($manager),
            $signature,
            $publicKey,
            OPENSSL_ALGO_SHA256
        );

        //  Determine if the signature was invalid at some point
        $valid = $valid && $this->is_valid;

        //  Perfom the validity check
        if($valid) return true;
        
        //  Change the valid checksum to false
        $this->update(['is_valid' => false]);

        //  Return false by default
        return false;
    }
}