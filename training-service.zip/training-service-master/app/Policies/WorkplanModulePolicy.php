<?php

namespace App\Policies;

use App\Models\TrainingRequest;
use App\Models\User;
use App\Models\WorkplanModule;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Route;

class WorkplanModulePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_workplan_modules');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return mixed
     */
    public function view(User $user, WorkplanModule $workplanModule)
    {
        return $user->hasPermissionTo('view_workplan_modules');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function create(User $user, TrainingRequest $trainingRequest)
    {
        return $user->hasPermissionTo('create_workplan_modules')
            && $trainingRequest->hasStatus([
                'AWAITING_PUBLISHING',
                'AWAITING_TRAINER_APPROVAL',
                'AWAITING_PRE-TRAINING_EVALUATION',
                'AWAITING_MANAGER_SIGNATURE',
            ]);
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return mixed
     */
    public function update(User $user, WorkplanModule $workplanModule)
    {
        //  Get the training request
        $trainingRequest = $workplanModule->workplan->trainingRequest;

        //  Check for permissions
        return $user->hasPermissionTo('update_workplan_modules')
            && $trainingRequest->hasStatus([
                'AWAITING_PUBLISHING',
                'AWAITING_TRAINER_APPROVAL',
                'AWAITING_PRE-TRAINING_EVALUATION',
                'AWAITING_MANAGER_SIGNATURE',
            ]);
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return mixed
     */
    public function delete(User $user, WorkplanModule $workplanModule)
    {
        //  Get the training request
        $trainingRequest = $workplanModule->workplan->trainingRequest;

        //  Check for permissions
        return $user->hasPermissionTo('delete_workplan_modules')
            && $trainingRequest->hasStatus([
                'AWAITING_PUBLISHING',
                'AWAITING_TRAINER_APPROVAL',
                'AWAITING_PRE-TRAINING_EVALUATION',
                'AWAITING_MANAGER_SIGNATURE',
            ]);
    }

    /**
     * Determine whether the specific users training request has been rejected
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WorkplanModule  $module
     * @return mixed
     */
    public function viewAnyTrainingMaterials(User $user, WorkplanModule $module)
    {
        return (bool) $module->trainingMaterials()->count()
            && $this->trainingMaterialsPrerequisite($user, $module)
            && $user->hasPermissionTo('view_uploads');
    }

    /**
     * Determine whether the user can start a module.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return mixed
     */
    public function start(User $user, WorkplanModule $workplanModule)
    {
        //  Get the training request
        $trainingRequest = $workplanModule->workplan->trainingRequest;

        //  Check for permissions
        return $user->hasPermissionTo('start_workplan_modules')
            && !$workplanModule->hasStarted()
            && $trainingRequest->hasStatus([
                'AWAITING_COMMENCEMENT',
                'ONGOING'
            ]);
    }

    /**
     * Determine whether the user can start a module.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return mixed
     */
    public function end(User $user, WorkplanModule $workplanModule)
    {
        //  Get the training request
        $trainingRequest = $workplanModule->workplan->trainingRequest;

        //  Check for permissions
        return $user->hasPermissionTo('end_workplan_modules')
            && $workplanModule->isOngoing()
            && $trainingRequest->hasStatus('ONGOING');
    }

    /**
     * Determine whether the user can start a module.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WorkplanModule  $workplanModule
     * @return mixed
     */
    public function trainingMaterialsPrerequisite(User $user, WorkplanModule $workplanModule)
    {
        //  Get the training request
        $trainingRequest = $workplanModule->workplan->trainingRequest;

        //  Determine the policy
        return Route::is('portal.trainees.*')
            ? !$trainingRequest->hasStatus([
                'AWAITING_PUBLISHING', 'AWAITING_TRAINER_APPROVAL',
                'AWAITING_PRE-TRAINING_EVALUATION'
            ]) : true;
    }

    /**
     * Determine whether the user can access workplan reports
     *
     * @param  \App\Models\Workplan $user
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateWorkPlanReports(User $user)
    {
        return $user->hasPermissionTo('generate_workplan_report');
    }
}
