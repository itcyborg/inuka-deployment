<?php

namespace App\Policies;

use App\Models\Upload;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UploadPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_uploads');
    }

    /**
     * Determine whether the user can view the upload.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Upload  $upload
     * @return mixed
     */
    public function view(User $user, Upload $upload)
    {
        return $user->hasPermissionTo('view_uploads');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        return $user->hasPermissionTo('create_uploads');
    }

    /**
     * Determine whether the user can update the upload.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Upload  $upload
     * @return mixed
     */
    public function update(User $user, Upload $upload)
    {
        return $user->hasPermissionTo('update_uploads');
    }

    /**
     * Determine whether the user can delete the upload.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Upload  $upload
     * @return mixed
     */
    public function delete(User $user, Upload $upload)
    {
        // return $user->hasPermissionTo('delete_uploads');
    }

    /**
     * Determine whether the user can permanently download the upload.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Upload  $upload
     * @return mixed
     */
    public function download(User $user, Upload $upload)
    {
        return $user->hasPermissionTo('download_uploads');
    }
}