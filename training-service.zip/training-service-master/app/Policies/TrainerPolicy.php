<?php

namespace App\Policies;

use App\Models\Trainer;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Route;

class TrainerPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_trainers');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Trainer  $trainer
     * @return mixed
     */
    public function view(User $user, Trainer $trainer)
    {
        //  Get the trainer user
        $trainerUser = !$trainer->isAUser() 
            ? $trainer->trainable->user
            : $trainer->trainable;

        //  Get the owner of the profile
        $isProfileOwner = Route::is('portal.managers.*') || ($trainerUser->id == $user->id);
        
        //  Return the policy
        return $isProfileOwner && $user->hasPermissionTo('view_trainers');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Trainer  $trainer
     * @return mixed
     */
    public function update(User $user, Trainer $trainer)
    {
        //  Get the trainer user
        $trainerUser = !$trainer->isAUser() 
            ? $trainer->trainable->user
            : $trainer->trainable;

        //  Get the owner of the profile
        $isProfileOwner = Route::is('portal.managers.*') || ($trainerUser->id == $user->id);
        
        //  Return the policy
        return $isProfileOwner && $user->hasPermissionTo('update_trainers');
    }

    /**
     * Determine whether the user can permanently activate the trainer.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Trainer  $trainer
     * @return mixed
     */
    public function activate(User $user, Trainer $trainer)
    {
        return $user->hasPermissionTo('activate_trainers') &&
            $trainer->trainable->status === 'DEACTIVATED';
    }

    /**
     * Determine whether the user can permanently deactivate the trainer.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Trainer  $trainer
     * @return mixed
     */
    public function deactivate(User $user, Trainer $trainer)
    {
        return $user->hasPermissionTo('deactivate_trainers') &&
            $trainer->trainable->status === 'ACTIVE';
    }
}
