<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UserPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param User $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_users')
        && $user->hasPermissionTo('view_manager_portal');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param User $user
     * @param User $activeUser
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function view(User $user, User $activeUser)
    {
        return $user->hasPermissionTo('view_users');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param User $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function create(User $user)
    {
        return $user->hasPermissionTo('create_users');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param User $user
     * @param User $activeUser
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(User $user, User $activeUser)
    {
        return $user->hasPermissionTo('update_users');
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param User $user
     * @param User $activeUser
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function delete(User $user, User $activeUser)
    {
        return $user->hasPermissionTo('delete_users');
    }

    /**
     * Determine whether the user can permanently activate the trainer.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function activate(User $user, User $activeUser)
    {
        return $user->hasPermissionTo('activate_users')
            && $activeUser->id != $user->id
            && $activeUser->hasStatus('DEACTIVATED');
    }

    /**
     * Determine whether the user can permanently deactivate the trainer.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function deactivate(User $user, User $activeUser)
    {
        return $user->hasPermissionTo('deactivate_users')
            && $activeUser->id != $user->id
            && $activeUser->hasStatus('ACTIVE');
    }

    /**
     * Determine whether the user can assign permissions.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function assignPermission(User $user, User $activeUser)
    {
        return $user->hasPermissionTo('update_user_permissions');
    }

    /**
     * Determine whether the user can view user profile.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function viewProfile(User $user)
    {
        return $user->hasPermissionTo('view_user_portal');
    }

    /**
     * Determine whether the user can update user profile.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function updateProfile(User $user)
    {
        return $user->hasPermissionTo('update_user_portal');
    }

    /**
     * Determine whether the user can generate user model reports.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateUserReports(User $user)
    {
        return $user->hasPermissionTo('generate_user_report');
    }
}
