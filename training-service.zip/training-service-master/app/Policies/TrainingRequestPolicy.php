<?php

namespace App\Policies;

use App\Models\Topic;
use App\Models\Trainee;
use App\Models\TrainingRequest;
use App\Models\User;
use App\Traits\ManagesTrainingRequests;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Route;

class TrainingRequestPolicy
{
    use HandlesAuthorization, ManagesTrainingRequests;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_training_requests');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return mixed
     */
    public function view(User $user, TrainingRequest $trainingRequest)
    {
        //  Check if the user has the permission and is the owner of
        //  the training request
        return $user->hasPermissionTo('view_training_requests')
            && $this->isRequestOwner($user, $trainingRequest);
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function create(User $user, Trainee $trainee, Topic $topic)
    {
        //  Prevent 2 similar training requests from being raised
        $requestable = $trainee->trainingRequests->filter(function($trainingRequest) use ($topic){
            return $trainingRequest->topicTrainee->topic_id == $topic->id;
        })->whereNotIn('status', [
            'REJECTED_BY_THE_TRAINER', 'CANCELED', 'COMPLETED'
        ])->isEmpty();

        return $requestable && $user->hasPermissionTo('create_training_requests');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return mixed
     */
    public function update(User $user, TrainingRequest $trainingRequest)
    {
        return $user->hasPermissionTo('update_training_requests')
            && $this->isRequestOwner($user, $trainingRequest);
    }

    /**
     * Determine whether the user can publish a training request for
     * trainer approval.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return mixed
     */
    public function publish(User $user, TrainingRequest $trainingRequest)
    {
        return $trainingRequest->hasStatus('AWAITING_PUBLISHING')
            && $user->hasPermissionTo('update_training_requests')
            && $this->isRequestOwner($user, $trainingRequest);
    }

    /**
     * Determine whether the user can accept a training request
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return mixed
     */
    public function accept(User $user, TrainingRequest $trainingRequest)
    {
        return $trainingRequest->hasStatus('AWAITING_TRAINER_APPROVAL')
            && $user->hasPermissionTo('accept_training_requests')
            && $this->isRequestOwner($user, $trainingRequest);
    }

    /**
     * Determine whether the user can decline a training request
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return mixed
     */
    public function decline(User $user, TrainingRequest $trainingRequest)
    {
        return $trainingRequest->hasStatus('AWAITING_TRAINER_APPROVAL')
            && $user->hasPermissionTo('decline_training_requests')
            && $this->isRequestOwner($user, $trainingRequest);
    }

    /**
     * Determine whether the specific users training request has been rejected
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     * @return mixed
     */
    public function rejected(User $user, TrainingRequest $trainingRequest)
    {
        return $trainingRequest->hasStatus('REJECTED_BY_THE_TRAINER');
    }

    /**
     * Determine the signature status of a training request
     *
     * @return string|null
     */
    public function signStatus(): ?string
    {
        //  Conditionally compute the status
        if (Route::is('portal.managers.*')) {
            $status = 'AWAITING_MANAGER_SIGNATURE';
        } else if (Route::is('portal.trainers.*')) {
            $status = 'AWAITING_TRAINER_SIGNATURE';
        }

        //  Return the status or a default null
        return $status ?? null;
    }

    /**
     * Determine whether the user can generate specific reports to the training.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateTrainingRequestReports(User $user)
    {
        return $user->hasPermissionTo('generate_training_request_report');
    }

    /**
     * Determine whether the user can generate specific reports to the training.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateTrainingProvisionReports(User $user)
    {
        return $user->hasPermissionTo('generate_training_provision_report');
    }

    /**
     * Determine whether the user can generate specific reports to the training.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateCompleteTrainingReports(User $user)
    {
        return $user->hasPermissionTo('generate_complete_training_report');
    }
}
