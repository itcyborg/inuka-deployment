<?php

namespace App\Policies;

use App\Models\Service;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ServicePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_services');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Service  $service
     * @return mixed
     */
    public function view(User $user, Service $service)
    {
        return $user->hasPermissionTo('view_services');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        return $user->hasPermissionTo('create_services');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Service  $service
     * @return mixed
     */
    public function update(User $user, Service $service)
    {
        return $user->hasPermissionTo('update_services');
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Service  $service
     * @return mixed
     */
    public function delete(User $user, Service $service)
    {
        return $user->hasPermissionTo('delete_services');
    }

    /**
     * Determine whether the user can permanently activate the service.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\service  $service
     * @return mixed
     */
    public function activate(User $user, Service $service)
    {
        return $user->hasPermissionTo('activate_services') &&
            $service->trainable->status === 'inactive';
    }

    /**
     * Determine whether the user can permanently deactivate the service.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Service  $service
     * @return mixed
     */
    public function deactivate(User $user, Service $service)
    {
        return $user->hasPermissionTo('deactivate_services') &&
            $service->trainable->status === 'active';
    }
}
