<?php

namespace App\Policies;

use App\Models\RatingParameter;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class RatingParameterPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_rating_parameters');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\RatingParameter $ratingParameter
     * @return mixed
     */
    public function view(User $user, RatingParameter $ratingParameter)
    {
        return $user->hasPermissionTo('view_rating_parameters');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        return $user->hasPermissionTo('create_rating_parameters');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\RatingParameter $ratingParameter
     * @return mixed
     */
    public function update(User $user, RatingParameter $ratingParameter)
    {
        return $user->hasPermissionTo('update_rating_parameters');
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\RatingParameter $ratingParameter
     * @return mixed
     */
    public function delete(User $user, RatingParameter $ratingParameter)
    {
        return $user->hasPermissionTo('delete_rating_parameters');
    }

    /**
     * Determine whether the user can permanently activate the service.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\RatingParameter $ratingParameter
     * @return mixed
     */
    public function activate(User $user, RatingParameter $ratingParameter)
    {
        return $user->hasPermissionTo('activate_rating_parameters');
    }

    /**
     * Determine whether the user can permanently deactivate the service.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\RatingParameter $ratingParameter
     * @return mixed
     */
    public function deactivate(User $user, RatingParameter $ratingParameter)
    {
        return $user->hasPermissionTo('deactivate_rating_parameters');
    }
}
