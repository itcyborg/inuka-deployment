<?php

namespace App\Policies;

use App\Models\Area;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AreaPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_areas');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Area  $area
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function view(User $user, Area $area)
    {
        return $user->hasPermissionTo('view_areas');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function create(User $user)
    {
        return $user->hasPermissionTo('create_areas');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Area  $area
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(User $user, Area $area)
    {
        return $user->hasPermissionTo('update_areas');
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Area  $area
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function delete(User $user, Area $area)
    {
        return $user->hasPermissionTo('delete_areas');
    }
}
