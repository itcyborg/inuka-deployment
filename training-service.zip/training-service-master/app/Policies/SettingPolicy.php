<?php

namespace App\Policies;

use App\Models\Setting;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class SettingPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_settings');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Setting  $setting
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function view(User $user, Setting $setting)
    {
        return $user->hasPermissionTo('view_settings');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function create(User $user)
    {
        return $user->hasPermissionTo('create_settings');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Service  $service
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function update(User $user, Setting $setting)
    {
        return $user->hasPermissionTo('update_settings');
    }

    /**
     * Determine whether the user can delete settings.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function delete(User $user, Setting $setting)
    {
        return $user->hasPermissionTo('delete_setting_values')
            && count($setting->values) > 1;
    }
}
