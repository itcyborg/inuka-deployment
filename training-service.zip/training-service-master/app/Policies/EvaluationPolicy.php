<?php

namespace App\Policies;

use App\Models\Evaluation;
use App\Models\TrainingRequest;
use App\Models\User;
use App\Traits\ManagesTrainingRequests;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Route;

class EvaluationPolicy
{
    use HandlesAuthorization, ManagesTrainingRequests;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return mixed
     */
    public function viewAny(User $user, TrainingRequest $trainingRequest, string $type)
    {
        return $user->hasPermissionTo('view_evaluations')
            && $trainingRequest->workplan->evaluations->where('type', $type)->isNotEmpty()
            && Route::is('portal.managers.*');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Evaluation  $Evaluation
     * @return mixed
     */
    public function view(User $user, Evaluation $evaluation)
    {
        //  Get the training request
        $trainingRequest = $evaluation->workplan->trainingRequest;

        //  Return the relavant permissions
        return $user->hasPermissionTo('view_evaluations')
            && $this->isEvaluationOwner($user, $evaluation);
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @param  string $type
     * @return mixed
     */
    public function create(User $user, TrainingRequest $trainingRequest, string $type)
    {
        return $user->hasPermissionTo('create_evaluations')
            && $trainingRequest->hasStatus( $this->requestStatus($type) )
            && $this->isRequestOwner($user, $trainingRequest)
            && !$user->hasEvaluated($trainingRequest->workplan, $type);
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Evaluation  $Evaluation
     * @return mixed
     */
    public function update(User $user, ?Evaluation $evaluation)
    {
        return (bool) $evaluation
            && $user->hasPermissionTo('update_evaluations')
            && $evaluation->workplan->trainingRequest->hasStatus(
                $this->requestStatus($evaluation->type)
            ) && $this->isEvaluationOwner($user, $evaluation);
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Evaluation  $evaluation
     * @return mixed
     */
    public function isEvaluationOwner(User $user, Evaluation $evaluation): bool
    {
        //  Conditionally compute more permissions
        if(Route::is('portal.managers.*')) {
            $ownership = true;

        } else if(Route::is('portal.trainees.*')) {
            $ownership = $evaluation->user_id === $user->id;
        }

        //  Return the ownership or a default false
        return $ownership ?? false;
    }

    /**
     * Determine the type of a request dynamically
     *
     * @param  string $type
     * @return mixed
     */
    public function requestStatus(string $type)
    {
        //  Determine the training request status
        switch ($type) {
            case 'PRE':
                return [
                    'AWAITING_PRE-TRAINING_EVALUATION', 'AWAITING_MANAGER_SIGNATURE'
                ];
            break;

            case 'POST':
                return 'AWAITING_RATING';
            break;

            default:
                return '';
            break;
        }
    }

    /**
     * Determine whether the user can generate a pre-evaluation report
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generatePreEvaluationReport(User $user)
    {
        return $user->hasPermissionTo('generate_pre_evaluation_report');
    }

    /**
     * Determine whether the user can generate a post-evaluation report
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generatePostEvaluationReport(User $user)
    {
        return $user->hasPermissionTo('generate_post_evaluation_report');
    }
}
