<?php

namespace App\Policies;

use App\Models\Sow;
use App\Models\TrainingRequest;
use App\Models\User;
use App\Traits\ManagesTrainingRequests;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Route;

class SowPolicy
{
    use HandlesAuthorization, ManagesTrainingRequests;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->hasPermissionTo('view_sows');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Sow  $sow
     * @return mixed
     */
    public function view(User $user, ?Sow $sow)
    {
        return !is_null($sow)
            && $this->isSowOwner($user, $sow)
            && $user->hasPermissionTo('view_sows');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\TrainingRequest  $trainingRequest
     * @return mixed
     */
    public function create(User $user, TrainingRequest $trainingRequest)
    {
        return $user->hasPermissionTo('create_sows')
            && $trainingRequest->hasStatus('AWAITING_MANAGER_SIGNATURE')
            && !$trainingRequest->sow;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Sow  $sow
     * @return mixed
     */
    public function update(User $user, ?Sow $sow)
    {
        return !is_null($sow)
            && $sow->trainingRequest->hasStatus('AWAITING_MANAGER_SIGNATURE')
            && $user->hasPermissionTo('update_sows');
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Sow  $sow
     * @return mixed
     */
    public function delete(User $user, Sow $sow)
    {
        return $user->hasPermissionTo('delete_sows');
    }

    /**
     * Determine whether the user can sign an SOW
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Sow  $sow
     * @return mixed
     */
    public function sign(User $user, Sow $sow, $role = '')
    {
        $trainingRequest = $sow->trainingRequest;

        //  Determine if the route is valid
        $validRoute = ($role === 'manager' && Route::is('portal.managers.*'))
            ||  ($role === 'trainer' && Route::is('portal.trainers.*'));

        return $validRoute
            && $trainingRequest->hasStatus( $this->signStatus() )
            && $user->hasPermissionTo('sign_sows')
            && $this->isRequestOwner($user, $trainingRequest);
    }

    /**
     * Determine the signature status of an SOW's training request
     *
     * @return string|null
     */
    public function signStatus(): ?string
    {
        //  Conditionally compute the status
        if(Route::is('portal.managers.*')) {
            $status = 'AWAITING_MANAGER_SIGNATURE';

        } else if(Route::is('portal.trainers.*')) {
            $status = 'AWAITING_TRAINER_SIGNATURE';
        }

        //  Return the status or a default null
        return $status ?? null;
    }

    /**
     * Determine the ownership of an SOW
     * @return bool
     */
    public function isSowOwner(User $user, Sow $sow): bool
    {
        //  Conditionally compute the status
        if(Route::is('portal.managers.*')) {
            $ownership = true;

        } else if(Route::is('portal.trainers.*')) {
            $ownership = $this->trainerIsRequestOwner($user, $sow->trainingRequest);
        }

        //  Return the ownership or a default false
        return $ownership ?? false;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateSowReports(User $user)
    {
        return $user->hasPermissionTo('generate_sow_report');
    }

    /**
     * Can download Sow pdf
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function download(User $user, Sow $sow)
    {
        return !is_null($sow)
            && $user->hasPermissionTo('download_sow_pdf')
            && $sow->trainingRequest->hasStatus(['AWAITING_COMMENCEMENT', 'COMPLETED']);
    }
}
