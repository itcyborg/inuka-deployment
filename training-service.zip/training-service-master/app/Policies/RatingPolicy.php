<?php

namespace App\Policies;

use App\Models\Trainer;
use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;

class RatingPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function viewAny(User $user, TrainingRequest $trainingRequest, string $type )
    {
        return $user->hasPermissionTo('view_ratings')
            && $trainingRequest->ratings->where('rateable_type', $type)->isNotEmpty()
            && $trainingRequest->hasStatus(['COMPLETED', 'AWAITING_RATING'])
            && Route::is('portal.managers.*');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  Collection  $ratings
     * @return mixed
     */
    public function view(User $user, Collection $ratings)
    {
        return $ratings->isNotEmpty()
            && $user->hasPermissionTo('view_ratings')
            && $ratings->filter(function($rating) use ($user){
                return $rating->user_id != $user->id;
            })->isEmpty();
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     */
    public function create(User $user, TrainingRequest $trainingRequest)
    {
        return $user->hasPermissionTo('create_ratings')
            && $this->postEvaluationPrerequisite($user, $trainingRequest)
            && $trainingRequest->trainingHasEnded()
            && $trainingRequest->hasStatus('AWAITING_RATING')
            && $trainingRequest->userRatings($user)->isEmpty();
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  Collection  $ratings
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function viewPrequalification(User $user, Collection $ratings)
    {
        return $ratings->isNotEmpty()
            && $user->hasPermissionTo('view_pre_qualification_ratings')
            && $ratings->filter(function($rating) use ($user){
                return $rating->user_id != $user->id;
            })->isEmpty();
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function createPrequalification(User $user, Trainer $trainer)
    {
        //  Get the ratings
        $ratings = $trainer->userRatings($user);

        return $user->hasPermissionTo('create_pre_qualification_ratings')
            && $trainer->hasStatus('AWAITING_PREQUALIFICATION')
            && $ratings->filter(function($rating) use ($user){
                return $rating->user_id == $user->id;
            })->isEmpty();
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  TrainingRequest  $trainingRequest
     * @return mixed
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function updatePrequalification(User $user, Trainer $trainer)
    {
        //  Get the ratings
        $ratings = $trainer->userRatings($user);

        //  Determine the policy
        return $ratings->isNotEmpty()
            && $user->hasPermissionTo('update_pre_qualification_ratings')
            && $trainer->hasStatus('AWAITING_PREQUALIFICATION')
            && $ratings->filter(function($rating) use ($user){
                return $rating->user_id != $user->id;
            })->isEmpty();
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     */
    public function postEvaluationPrerequisite(User $user, TrainingRequest $trainingRequest): bool
    {
        return Route::is('portal.trainees.*')
            ? $user->hasEvaluated($trainingRequest->workplan, 'POST')
            : true;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     */
    public function ratingPrerequisite(User $user, TrainingRequest $trainingRequest): bool
    {
        return Route::is('portal.trainees.*')
            ? $user->hasEvaluated($trainingRequest->workplan, 'POST')
            : true;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generatePreQualificationRatingReports(User $user)
    {
        return $user->hasPermissionTo('generate_prequalification_rating_report');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateTraineeRatingReports(User $user)
    {
        return $user->hasPermissionTo('generate_trainee_rating_report');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User $user
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function generateTrainerRatingReports(User $user)
    {
        return $user->hasPermissionTo('generate_trainer_rating_report');
    }
}
