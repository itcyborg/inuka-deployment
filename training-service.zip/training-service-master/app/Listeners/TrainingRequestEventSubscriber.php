<?php

namespace App\Listeners;

use App\Events\PreEvaluationSubmitted;
use App\Events\TrainingRequestAccepted;
use App\Events\TrainingRequestCreated;
use App\Events\TrainingRequestDeclined;
use App\Events\TrainingRequestSignedByManager;
use App\Events\TrainingRequestSignedByTrainer;
use App\Events\WorkplanPreEvaluated;
use App\Models\User;
use App\Notifications\NotifyUser;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\Notification;

class TrainingRequestEventSubscriber
{
    /**
     * Handle training request submission
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handleTrainingRequestSubmission($event)
    {
        //  Get the training request
        $trainingRequest = $event->trainingRequest;

        //  Get the manager
        $manager = $trainingRequest->manager;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the trainee
        $trainee = $topicTrainee->trainee->trainable;

        //  Get the trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the trainer contact people
        $trainers = $trainingRequest->trainer->contactPeople();

        //  Send the notification to the provider
        Notification::send($trainers, new NotifyUser([
            'mail' => (new MailMessage)
            ->subject('You have a new training request')
                ->line($message = trans('notifications.training-request.published.trainer', [
                    'trainee_name' => $trainee->name,
                    'topic_name' => $topic->name
                ]))
                ->action('You can view the training request details here', $action = route('portal.trainers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the provider
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You are now a designated TSP')
                ->line($message = trans('notifications.training-request.published.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('You can view the training request details here', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle Manager Notification when training request is declined
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainingRequestDeclined($event)
    {
        //  Get training request
        $trainingRequest = $event->trainingRequest;

        //  Get the decline reason
        $reason = $event->reason;

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //Get the manager attached to training request using the manager_id using findOrFail on User model
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A Training Request has been Declined')
                ->line($message = trans('notifications.training-request.declined.manager', [
                    'trainer_name' => $trainer->name,
                    'reason' => $reason,
                ]))
                ->action('You can view the training request details here', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ]
            ]
        ]));
    }

    /**
     * Handle Manager Notification when training request is accepted
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainingRequestAccepted($event)
    {
        //  Get training request
        $trainingRequest = $event->trainingRequest;

        //  Get the topic Trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get all the trainee users
        $trainees = $topicTrainee->trainee->users();

        //  Get the training request topic
        $topic = $topicTrainee->topic;

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //Get the manager attached to training request using the manager_id using findOrFail on User model
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A Training Request has been Accepted')
                ->line($message = trans('notifications.training-request.accepted.manager', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('You can view the training request details here', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ]
            ]
        ]));

        //  Send the notification to the trainee
        Notification::send($trainees, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('New Training Available')
                ->line($message = trans('notifications.training-request.accepted.trainee', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to fill the pre-training evaluation questionnaire', $action = route('portal.trainees.pre-evaluations.create', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

     /**
     * Handle pre evaluation submission
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handlePreEvaluationSubmission($event)
    {
        //  Get the required variables
        $workplan = $event->workplan;

        //  Get the trainee that submitted the pre-evaluation
        $traineeUser = $event->user;

        //  Get the training request
        $trainingRequest = $workplan->trainingRequest;

        //  Get the manager of the training request
        $manager = $trainingRequest->manager;

        //  Get the topic
        $topic = $trainingRequest->topicTrainee->topic;

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A new pre-training evaluation has been submitted')
                ->line($message = trans('notifications.training-request.pre-evaluation-submitted.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $traineeUser->name,
                ]))
                ->action('You can view the pre-training evaluation details here', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $workplan->trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the manager
        Notification::send($traineeUser, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Your pre-training evaluation has been received')
                ->line($message = trans('notifications.training-request.pre-evaluation-submitted.trainee', [
                    'topic_name' => $topic->name
                ]))
                ->action('You can view the pre-training evaluation details here', $action = route('portal.trainees.pre-evaluations.show', [
                    'evaluation' => $workplan->evaluation($traineeUser, 'PRE')
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle pre evaluation completion
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handlePreEvaluationCompleted($event)
    {
        //  Get the required variables
        $workplan = $event->workplan;

        //  Get the training request
        $trainingRequest = $workplan->trainingRequest;

        //  Get the topicTrainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the topic, trainer and trainee
        $topic = $topicTrainee->topic;
        $trainee = $topicTrainee->trainee->trainable;
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the manager signatories
        $managers = User::permission('view_manager_portal')
            ->permission('sign_sows')->get();

        //  Send the notification to the provider
        Notification::send($managers, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You are required to sign an SOW')
                ->line($message = trans('notifications.training-request.requires_signing.manager', [
                    'topic_name' =>$topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view create the SOW', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Listener for handling the sigining of a training request
     * by a manager
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainingRequestSignedByManager($event)
    {
        //  Get the required variables
        $trainingRequest = $event->trainingRequest;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get all the trainee users
        $topic = $topicTrainee->topic;
        $trainee = $topicTrainee->trainee->trainable;

        //  Get the trainer contact people
        $trainers = $trainingRequest->trainer->signatories();

        //  Send the notification to the provider
        Notification::send($trainers, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You have an SOW that requires signing')
                ->line($message = trans('notifications.training-request.signed_by_manager.trainer', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name
                ]))
                ->action('Click here to sign the SOW', $action = route('portal.trainers.sows.show', [
                    'sow' => $trainingRequest->sow
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Listener for handling the sigining of a training request
     * by a trainer
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainingRequestSignedByTrainer($event)
    {
        //  Get the required variables
        $trainingRequest = $event->trainingRequest;

        //  Get the manager user
        $manager = $trainingRequest->manager;

        //  Get the trainer contact people
        $trainers = $trainingRequest->trainer->contactPeople();

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get all the trainee users
        $trainees = $topicTrainee->trainee->users();

        //  Get the topic, trainee and trainer
        $topic = $topicTrainee->topic;
        $trainee = $topicTrainee->trainee->trainable;
        $trainer = $trainingRequest->trainer->trainable;

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A '.prettify(config('settings.aliases.trainer')).' has signed an SOW')
                ->line($message = trans('notifications.training-request.signed_by_trainer.manager', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the SOW', $action = route('portal.managers.sows.show', [
                    'sow' => $trainingRequest->sow
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the trainer
        Notification::send($trainers, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You can now start training!')
                ->line($message = trans('notifications.training-request.signed_by_trainer.trainer', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name
                ]))
                ->action('Click here to start training', $action = route('portal.trainers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to all the trainees
        Notification::send($trainees, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('New Training alert')
                ->line($message = trans('notifications.training-request.signed_by_trainer.trainee', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the training workplan', $action = route('portal.trainees.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Register the listeners for the subscriber.
     *
     * @param  \Illuminate\Events\Dispatcher  $events
     * @return void
     */
    public function subscribe($events)
    {
        $events->listen(
            TrainingRequestCreated::class,
            [ TrainingRequestEventSubscriber::class, 'handleTrainingRequestSubmission' ]
        );

        $events->listen(
            TrainingRequestAccepted::class,
            [ TrainingRequestEventSubscriber::class, 'handleTrainingRequestAccepted' ]
        );

        $events->listen(
            TrainingRequestDeclined::class,
            [ TrainingRequestEventSubscriber::class, 'handleTrainingRequestDeclined' ]
        );

        $events->listen(
            PreEvaluationSubmitted::class,
            [ TrainingRequestEventSubscriber::class, 'handlePreEvaluationSubmission' ]
        );

        $events->listen(
            WorkplanPreEvaluated::class,
            [ TrainingRequestEventSubscriber::class, 'handlePreEvaluationCompleted' ]
        );

        $events->listen(
            TrainingRequestSignedByManager::class,
            [ TrainingRequestEventSubscriber::class, 'handleTrainingRequestSignedByManager' ]
        );

        $events->listen(
            TrainingRequestSignedByTrainer::class,
            [ TrainingRequestEventSubscriber::class, 'handleTrainingRequestSignedByTrainer' ]
        );
    }
}
