<?php

namespace App\Listeners;

use App\Events\TrainerRegistered;
use App\Models\User;
use App\Notifications\NotifyUser;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\Notification;

class RegistrationEventSubscriber
{
    /**
     * Handle registration of a trainer
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handleTrainerRegistration($event)
    {
        //  Get the trainer from the event
        $trainer = $event->trainer;

        //  Get the trainer contact people
        $trainerUser = $trainer->trainable;

        //  Handle email verification
        // if ($trainerUser instanceof MustVerifyEmail && ! $trainerUser->hasVerifiedEmail()) {
        //     $trainerUser->sendEmailVerificationNotification();
        // }

        //  Get the managers
        $managers = User::permission('view_manager_portal')->get();

        //  Send a notification to all managers informing the that a trainer has registered
        Notification::send($managers, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('New Trainer Registration')
                ->line($message = trans('notifications.trainer-registered.manager', [
                    'trainer_name' => $trainerUser->name
                ]))
                ->action(
                    'Click here to prequalify the '.config('settings.aliases.trainer'),
                     $action = route('portal.managers.trainers.show', ['trainer' => $trainer])
                ),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Register the listeners for the subscriber.
     *
     * @param  \Illuminate\Events\Dispatcher  $events
     * @return void
     */
    public function subscribe($events)
    {
        $events->listen(
            TrainerRegistered::class,
            [ RegistrationEventSubscriber::class, 'handleTrainerRegistration' ]
        );
    }
}
