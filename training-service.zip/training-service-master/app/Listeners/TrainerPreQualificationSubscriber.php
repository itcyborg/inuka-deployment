<?php

namespace App\Listeners;

use App\Events\TrainerPrequalificationComplete;
use App\Events\TrainerPrequalificationSubmitted;
use App\Models\User;
use App\Models\Trainer;
use App\Notifications\NotifyUser;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification;

class TrainerPreQualificationSubscriber
{
    /**
     * Handle pre-qualification submissions
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainerPreQualificationSubmission($event)
    {
        //  Get the training request
        $trainer = $event->trainer;

        //  Get the manager user
        $manager = Auth::user();

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Trainer '.$trainer->name.' pre-qualification successfully submitted')
                ->line($message = trans('notifications.trainer-pre-qualification.pre-qualification-submitted.manager', [
                    'trainer_name' => $trainer->name
                ]))
                ->action('You can view the pre-qualification ratings details here', $action = route('portal.managers.trainers.show', [
                    'trainer' => $trainer
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        // Get managers
        $managers = User::permission('view_manager_portal')
            ->permission('create_pre_qualification_ratings')
            ->get();

        //send notification to all managers that a trainer has been pre-qualificated
        Notification::send($managers, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Trainer ,'.$trainer->trainable->name.' partially rated')
                ->line($message = trans('notifications.trainer-pre-qualification.pre-qualification-submitted.all_managers', [
                    'trainer_name' => $trainer->trainable->name
                ]))
                ->action('Click here to view the trainer profile', $action = route('portal.managers.trainers.show', [
                    'trainer' => $trainer
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle Trainer pre-qualification by managers completed
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainerPreQualificationCompleted($event)
    {
        //  Get the required variables
        $trainer = $event->trainer;

        // Get managers
        $managers = User::permission('view_manager_portal')
            ->permission('create_pre_qualification_ratings')
            ->get();


        //send notification to all managers that trainer pre-qualification rating is complete
        Notification::send($managers, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Trainer ,'.$trainer->trainable->name.' pre-qualification has been successfully completed')
                ->line($message = trans('notifications.trainer-pre-qualification.pre-qualification-completed.manager', [
                    'trainer_name' => $trainer->trainable->name
                ]))
                ->action('Click here to view the trainer profile', $action = route('portal.managers.trainers.show', [
                    'trainer' => $trainer->trainable
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Check the prequalification threshold
        if($trainer->checkTrainerPrequalificationThreshold()) {
            //  Set the status of prequalified
            $trainer->setStatus('PREQUALIFIED');

            //  send notification to all managers that trainer pre-qualification rating is complete
            Notification::send($trainer->trainable, new NotifyUser([
                'mail' => (new MailMessage)
                    ->subject('Successful Prequalification as a Trainer')
                    ->line($message = trans('notifications.trainer-pre-qualification.pre-qualification-results.passed')),
                'database' => [
                    'body' => [
                        'message' => $message,
                    ],
                ]
            ]));

        }  else {
            //  Set the status of prequalified
            $trainer->setStatus('FAILED_PREQUALIFICATION');

            //send notification to all managers that trainer pre-qualification rating is complete
            Notification::send($trainer->trainable, new NotifyUser([
                'mail' => (new MailMessage)
                    ->subject('Unsuccessful Prequalification as a Trainer')
                    ->line($message = trans('notifications.trainer-pre-qualification.pre-qualification-results.failed')),
                'database' => [
                    'body' => [
                        'message' => $message,
                    ],
                ]
            ]));
        }
    }

    /**
     * Handle Trainer passed pre-qualification on completed
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainerPassedPreQualification($event)
    {
        //  Get the required variables
        $trainer = $event->trainer;

        //  Get the trainer
        $trainer = $trainer->trainable;

        //send notification to all managers that trainer pre-qualification rating is complete
        Notification::send($trainer, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Successful Prequalification as a Trainer')
                ->line($message = trans('notifications.trainer-pre-qualification.pre-qualification-results.passed')),
            'database' => [
                'body' => [
                    'message' => $message,
                ],
            ]
        ]));
    }

    /**
     * Handle Trainer failed pre-qualification on completed
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainerFailedPreQualification($event)
    {
        //  Get the required variables
        $trainer = $event->trainer;

        //  Get the trainer
        $trainer = $trainer->trainable;

        //send notification to all managers that trainer pre-qualification rating is complete
        Notification::send($trainer, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Unsuccessful Prequalification as a Trainer')
                ->line($message = trans('notifications.trainer-pre-qualification.pre-qualification-results.failed')),
            'database' => [
                'body' => [
                    'message' => $message,
                ],
            ]
        ]));
    }

    /**
     * Register the listeners for the subscriber.
     *
     * @param  \Illuminate\Events\Dispatcher  $events
     * @return void
     */
    public function subscribe($events)
    {
        $events->listen(
            TrainerPrequalificationSubmitted::class,
            [ TrainerPreQualificationSubscriber::class, 'handleTrainerPreQualificationSubmission' ]
        );

        $events->listen(
            TrainerPrequalificationComplete::class,
            [ TrainerPreQualificationSubscriber::class, 'handleTrainerPreQualificationCompleted' ]
        );
    }
}
