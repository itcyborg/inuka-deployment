<?php

namespace App\Listeners;

use App\Events\PostEvaluationSubmitted;
use App\Events\TraineeRatingComplete;
use App\Events\TrainerRatingComplete;
use App\Events\TrainingProvisionComplete;
use App\Events\TrainingProvisionEnded;
use App\Events\TrainingProvisionStarted;
use App\Events\WorkplanModuleEnded;
use App\Events\WorkplanModuleStarted;
use App\Notifications\NotifyUser;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\Notification;

class TrainingProvisionEventSubscriber
{
    /**
     * Handle training provision commencement
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handleProvisionCommencement($event)
    {
        //  Get the required variables
        $trainingRequest = $event->trainingRequest;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the topic
        $trainee = $topicTrainee->trainee->trainable;

        //  Get all the trainee users
        $trainees = $topicTrainee->trainee->users();

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //  Get the training request trainer user
        $trainerUser = $event->trainer;

        //Get

        //  Send the notification to the trainer
        Notification::send($trainerUser, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You have started the training')
                ->line($message = trans('notifications.training-provision.provision_started.trainer', [
                    'topic_name' => $topic->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.trainers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the trainees
        Notification::send($trainees, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Your training has just started')
                ->line($message = trans('notifications.training-provision.provision_started.trainee', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the training', $action = route('portal.trainees.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A training has just started')
                ->line($message = trans('notifications.training-provision.provision_started.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle module commencement
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handleModuleCommencement($event)
    {
        //  Get the module
        $module = $event->module;

        //  Get the required variables
        $trainingRequest = $module->workplan->trainingRequest;

        //  Get the training request trainer user
        $trainerUser = $event->trainer;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the topic
        $trainee = $topicTrainee->trainee->trainable;

        //  Get all the trainee users
        $trainees = $topicTrainee->trainee->users();

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //  Send the notification to the trainer
        Notification::send($trainerUser, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You have started a module')
                ->line($message = trans('notifications.training-provision.module_started.trainer', [
                    'topic_name' => $topic->name,
                    'module_name' => $module->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.trainers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the trainees
        Notification::send($trainees, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Your training on a module has just begun')
                ->line($message = trans('notifications.training-provision.module_started.trainee', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name,
                    'module_name' => $module->name
                ]))
                ->action('Click here to view the training', $action = route('portal.trainees.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A training on a module has just started')
                ->line($message = trans('notifications.training-provision.module_started.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name,
                    'module_name' => $module->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle module termination
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handleModuleTermination($event)
    {
        //  Get the module
        $module = $event->module;

        //  Get the required variables
        $trainingRequest = $module->workplan->trainingRequest;

        //  Get the training request trainer user
        $trainerUser = $event->trainer;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the topic
        $trainee = $topicTrainee->trainee->trainable;

        //  Get all the trainee users
        $trainees = $topicTrainee->trainee->users();

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //  Send the notification to the trainer
        Notification::send($trainerUser, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You have ended a module')
                ->line($message = trans('notifications.training-provision.module_ended.trainer', [
                    'topic_name' => $topic->name,
                    'module_name' => $module->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.trainers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the trainees
        Notification::send($trainees, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Your training on a module has just ended')
                ->line($message = trans('notifications.training-provision.module_ended.trainee', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name,
                    'module_name' => $module->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.trainees.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A module training has just ended')
                ->line($message = trans('notifications.training-provision.module_ended.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name,
                    'module_name' => $module->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle training provision termination
     *
     * * @author Nderi Kamau <nderikamau1212@gmail.com>.
     */
    public function handleProvisionTermination($event)
    {
        //  Get the required variables
        $trainingRequest = $event->trainingRequest;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the topic
        $trainee = $topicTrainee->trainee->trainable;

        //  Get all the trainee users
        $trainees = $topicTrainee->trainee->users();

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //  Get the training request trainer user
        $trainerUser = $event->trainer;

        //  Send the notification to the trainer
        Notification::send($trainerUser, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('You have ended the training')
                ->line($message = trans('notifications.training-provision.provision_ended.trainer', [
                    'topic_name' => $topic->name
                ]))
                ->action('Click here to rate your trainee', $action = route('portal.trainers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the trainees
        Notification::send($trainees, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Your training has just ended')
                ->line($message = trans('notifications.training-provision.provision_ended.trainee', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to rate your trainer', $action = route('portal.trainees.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A training has just ended')
                ->line($message = trans('notifications.training-provision.provision_ended.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to rate the trainer', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle Trainer rating notification to manager
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainerRatingComplete($event)
    {
        //  Get the required variables
        $trainingRequest = $event->trainingRequest;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the topic
        $trainee = $topicTrainee->trainee->trainable;

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //send notification to manager trainer rating is complete
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A '.config('settings.aliases.trainee').' user has rated a '.config('settings.aliases.trainer'))
                ->line($message = trans('notifications.training-provision.trainee_rated_trainer.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle Trainer rating notification to manager
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTraineeRatingComplete($event)
    {
        //  Get the required variables
        $trainingRequest = $event->trainingRequest;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the topic
        $trainee = $topicTrainee->trainee->trainable;

        //  Get the training request manager
        $manager = $trainingRequest->manager;

        //send notification to manager trainer rating is complete
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
            ->subject('A '.config('settings.aliases.trainer').' has just rated a '.config('settings.aliases.trainer'). ' user')
                ->line($message = trans('notifications.training-provision.trainer_rated_trainee.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle pre evaluation submission
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handlePostEvaluationSubmitted($event)
    {
        //  Get the required variables
        $workplan = $event->workplan;

        //  Get the trainee that submitted the pre-evaluation
        $traineeUser = $event->user;

        //  Get the training request
        $trainingRequest = $workplan->trainingRequest;

        //  Get the manager of the training request
        $manager = $trainingRequest->manager;

        //  Get the topic
        $topic = $trainingRequest->topicTrainee->topic;

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('A new post-training evaluation has been submitted')
                ->line($message = trans('notifications.training-provision.post-evaluation-submitted.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $traineeUser->name,
                ]))
                ->action('Click here to view the pre-training evaluation', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $workplan->trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the manager
        Notification::send($traineeUser, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Your post-training evaluation has been received')
                ->line($message = trans('notifications.training-provision.post-evaluation-submitted.trainee', [
                    'topic_name' => $topic->name
                ]))
                ->action('Click here to view the post-training evaluation', $action = route('portal.trainees.pre-evaluations.edit', [
                    'evaluation' => $workplan->evaluation($traineeUser, 'POST')
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }


    /**
     * Handle notify manager, trainer adn trainees that training provision has been completed
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleTrainingProvisionComplete($event)
    {
        //  Get the required variables
        $trainingRequest = $event->trainingRequest;

        //  Get the topic trainee instance
        $topicTrainee = $trainingRequest->topicTrainee;

        //  Get the training request trainer
        $trainer = $trainingRequest->trainer->trainable;

        //  Get the topic
        $topic = $topicTrainee->topic;

        //  Get the topic
        $trainee = $topicTrainee->trainee->trainable;

        //  Get all the trainee users
        $trainees = $topicTrainee->trainee->users();

        //  Get the training request manager
        $manager = $trainingRequest->manager;


        //Get

        //  Send the notification to the trainer
        Notification::send($trainer, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Training Provision Successfully Completed')
                ->line($message = trans('notifications.training-provision.provision-completed.trainer', [
                    'topic_name' => $topic->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.trainers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the trainees
        Notification::send($trainees, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Training Provision Successfully Completed')
                ->line($message = trans('notifications.training-provision.provision-completed.trainee', [
                    'topic_name' => $topic->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the training', $action = route('portal.trainees.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));

        //  Send the notification to the manager
        Notification::send($manager, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Training Provision Successfully Completed')
                ->line($message = trans('notifications.training-provision.provision-completed.manager', [
                    'topic_name' => $topic->name,
                    'trainee_name' => $trainee->name,
                    'trainer_name' => $trainer->name
                ]))
                ->action('Click here to view the training provision', $action = route('portal.managers.training-requests.show', [
                    'training_request' => $trainingRequest
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Register the listeners for the subscriber.
     *
     * @param  \Illuminate\Events\Dispatcher  $events
     * @return void
     */
    public function subscribe($events)
    {
        $events->listen(
            TrainingProvisionStarted::class,
            [ TrainingProvisionEventSubscriber::class, 'handleProvisionCommencement' ]
        );

        $events->listen(
            WorkplanModuleStarted::class,
            [ TrainingProvisionEventSubscriber::class, 'handleModuleCommencement' ]
        );

        $events->listen(
            WorkplanModuleEnded::class,
            [ TrainingProvisionEventSubscriber::class, 'handleModuleTermination' ]
        );

        $events->listen(
            TrainingProvisionEnded::class,
            [ TrainingProvisionEventSubscriber::class, 'handleProvisionTermination' ]
        );

        $events->listen(
            TrainerRatingComplete::class,
            [ TrainingProvisionEventSubscriber::class, 'handleTrainerRatingComplete' ]
        );

        $events->listen(
            TraineeRatingComplete::class,
            [ TrainingProvisionEventSubscriber::class, 'handleTraineeRatingComplete' ]
        );

        $events->listen(
            PostEvaluationSubmitted::class,
            [ TrainingProvisionEventSubscriber::class, 'handlePostEvaluationSubmitted' ]
        );

        $events->listen(
            TrainingProvisionComplete::class,
            [ TrainingProvisionEventSubscriber::class, 'handleTrainingProvisionComplete' ]
        );
    }
}
