<?php

namespace App\Listeners;

use App\Events\PasswordChangedEvent;
use App\Events\UserActivatedEvent;
use App\Events\UserDeactivatedEvent;
use App\Notifications\NotifyUser;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\Notification;

class UserEventSubscriber
{
    /**
     * Handle activation of a user
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleUserActivation($event)
    {
        //  Get the user from the event
        $user = $event->user;

        //  Send a notification to the user informning them they have been activated in the system
        Notification::send($user, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('User Successfully Activated')
                ->line($message = trans('notifications.user-activated.user', [
                    'user_name' => $user->name
                ]))
                ->action(
                    'Click here to access your TMP App account',
                     $action = route('login')
                ),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Handle deactivation of a user
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handleUserDeactivation($event)
    {
        //  Get the user from the event
        $user = $event->user;

        // Get reason from the even
        $reason = $event->reason;

        //  Send a notification to the user informning them they have been deactivated from the system
        Notification::send($user, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('User Deactivated')
                ->line($message = trans('notifications.user-deactivated.user', [
                    'user_name' => $user->name,
                    'reason' => $reason
                ])),
            'database' => [
                'body' => [
                    'message' => $message,
                ],
            ]
        ]));
    }

    /**
     * Handle password change by a user
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function handlePasswordChanged($event)
    {
        //  Get the user from the event
        $user = $event->user;

        //  Send a notification to the user informning them they have been activated in the system
        Notification::send($user, new NotifyUser([
            'mail' => (new MailMessage)
                ->subject('Password Successfully Changed')
                ->line($message = trans('notifications.user-password-changed.user'))
                ->action(
                    'Click here to access your TMP App account',
                     $action = route('login')
                ),
            'database' => [
                'body' => [
                    'message' => $message,
                    'action' => $action
                ],
            ]
        ]));
    }

    /**
     * Register the listeners for the subscriber.
     *
     * @param  \Illuminate\Events\Dispatcher  $events
     * @return void
     */
    public function subscribe($events)
    {
        $events->listen(
            UserActivatedEvent::class,
            [ UserEventSubscriber::class, 'handleUserActivation' ]
        );

        $events->listen(
            UserDeactivatedEvent::class,
            [ UserEventSubscriber::class, 'handleUserDeactivation' ]
        );

        $events->listen(
            PasswordChangedEvent::class,
            [UserEventSubscriber::class, 'handlePasswordChanged']
        );
    }
}
