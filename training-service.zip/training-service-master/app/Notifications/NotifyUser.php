<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NotifyUser extends Notification
{
    use Queueable;

    /**
     * Define the payload variable that will be received.
     *
     * @var $payload
     */
    public $payload;

    /**
     * Create a new notification instance.
     *
     * @param $payload
     */
    public function __construct($payload)
    {
        $this->payload = $payload;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function via($notifiable): array
    {
        return array_merge(
            // isset($this->payload['mail']) ? ['mail'] : [],
            isset($this->payload['database']) ? ['database'] : [],
        );
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return MailMessage
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function toMail($notifiable): MailMessage
    {
        //  Check if payload has been defined
        $mail = $this->payload['mail'] ?? null;

        //  Overide the greeting object
        $mail->greeting("Dear, $notifiable->name");

        //  Check if an attachment, cc and bcc are defined, and add
        //  them to the mail if they are.
        if ($mail) {
            if (isset($this->payload['cc'])) $mail->cc($this->payload['cc']);
            if (isset($this->payload['bcc'])) $mail->bcc($this->payload['bcc']);
            if (isset($this->payload['attachment'])) $mail->attach($this->payload['attachment']);
        }

        //  Return the mail object
        return $mail;
    }

    /**
     * Get the array representation of the notification for database
     * notifications.
     *
     * @param mixed $notifiable
     * @return array
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function toDatabase($notifiable): array
    {
        return $this->payload['database'] ?? null;
    }
}
