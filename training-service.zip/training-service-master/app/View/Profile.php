<?php

namespace App\View;

use Illuminate\Support\Facades\Route;
use Illuminate\View\Component;

class Profile extends Component
{
    /**
     * Determine the user profile route name
     *
     * @return string|null
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public static function profileRouteName(): ?string
    {
        //  Dynamically determine the route name
        if(Route::is('portal.trainers.*')) {
            return 'portal.trainers.user-profiles.show';

        } else if(Route::is('portal.trainees.*')) {
            return 'portal.trainees.user-profiles.show';
        }

        //  Return the manager route by default
        return 'portal.managers.user-profiles.show';
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('layouts.portal.navbar');
    }
}
