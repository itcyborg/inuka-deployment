<?php

namespace App\View\Composers;

use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class NotificationComposer
{
    /**
     * Bind data to the view.
     *
     * @param  \Illuminate\View\View  $view
     * @return void
     */
    public function compose(View $view)
    {
        //  Define the unread and notifications variable
        $notifications = [];
        $unread = 0;

        //  Check if user is authenticated
        if(Auth::check()) {
            $notifications = Auth::user()->notifications;
            $unread = $notifications->whereNull('read_at')->count();
            $notifications = $notifications->take(5);
        }

        //  Return the view with the notifications
        $view->with([
            'unreadNotifications' => $unread,
            'userNotifications' => $notifications,
        ]);
    }
}
