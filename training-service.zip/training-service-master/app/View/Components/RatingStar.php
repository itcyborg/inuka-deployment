<?php

namespace App\View\Components;

use Illuminate\View\Component;

class RatingStar extends Component
{
    /**
     * The value of the rating
     *
     * @var
     */
    public ?float $rating;

    /**
     * The number of full stars
     *
     * @var
     */
    public int $fullstars = 0;

    /**
     * The number of half stars
     *
     * @var
     */
    public bool $halfstar = false;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(?float $rating)
    {
        $this->rating = $rating;
    }

     /**
     * Determine the full and half stars
     *
     * @return void
     */
    public function generateStars(): void
    {
        //  If the rating is defined
        if($this->rating) {
            //  Get the scale
            $scale = config('settings.maximum_rating_value');

            //  Get the relative rating value
            $rating = $this->rating * $scale;

            //  Round off to the nearest 0.5
            $rating = round($rating * 2) / 2;

            //  Get the full stars
            $this->fullstars = floor($rating);

            //  Calculate the half star
            $this->halfstar = ($rating - $this->fullstars) == 0.5;
        }
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        //  Call the generate stars method
        $this->generateStars();

        //  Render the component view
        return view('components.rating-star');
    }
}
