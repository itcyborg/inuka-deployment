<?php

namespace App\View\Components\Tables;

use App\Models\Sow as ModelsSow;
use App\Models\Topic;
use App\Models\Trainee;
use App\Models\Trainer;
use App\Models\TrainingRequest;
use App\Models\WorkPlan;
use Illuminate\Support\Collection;
use Illuminate\View\Component;

class Sow extends Component
{
    /**
     * The sow instance
     *
     * @var
     */
    public ModelsSow $sow;

    /**
     * The training request instance
     *
     * @var
     */
    public TrainingRequest $trainingRequest;

    /**
     * The workplan instance
     *
     * @var
     */
    public WorkPlan $workplan;

    /**
     * The modules that belong to a workplan
     *
     * @var
     */
    public Collection $modules;

    /**
     * The trainer instance
     *
     * @var
     */
    public Trainer $trainer;

    /**
     * The trainee instance
     *
     * @var
     */
    public Trainee $trainee;

    /**
     * The topic instance
     *
     * @var
     */
    public Topic $topic;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(ModelsSow $sow)
    {
        $this->sow = $sow;
        $this->trainingRequest = $sow->trainingRequest;
        $this->workplan = $sow->trainingRequest->workplan;
        $this->modules = $this->workplan->modules;
        $this->trainer = $this->trainingRequest->trainer;
        $this->trainee = $this->trainingRequest->topicTrainee->trainee;
        $this->topic = $this->trainingRequest->topicTrainee->topic;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.tables.sow');
    }
}