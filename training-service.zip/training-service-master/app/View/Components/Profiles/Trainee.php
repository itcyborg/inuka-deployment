<?php

namespace App\View\Components\Profiles;

use App\Models\Trainee as ModelsTrainee;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Illuminate\View\Component;

class Trainee extends Component
{
    /**
     * The trainee instance
     *
     * @var
     */
    public ModelsTrainee $trainee;

    /**
     * The list of topics
     *
     * @var
     */
    public Collection $topics;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($trainee, $topics)
    {
        $this->trainee = $trainee;
        $this->topics = $topics;
    }

    /**
     * Return the download route name
     * @return string
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingRequestRoute()
    {
        //  Dynamically determine the route name
        if(Route::is('portal.trainers.*')) {
            $name = 'portal.trainers.training-requests.show';
        } else if(Route::is('portal.trainees.*')) {
            $name = 'portal.trainees.training-requests.show';
        }

        //  Return the determined name or a default one
       return $name ?? 'portal.managers.training-requests.show';
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.profiles.trainee');
    }
}
