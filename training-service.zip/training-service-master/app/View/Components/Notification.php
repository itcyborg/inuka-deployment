<?php

namespace App\View\Components;

use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Illuminate\View\Component;

class Notification extends Component
{
    /**
     * The title of the notification
     *
     * @var
     */
    public string $title;

    /**
     * The list of notifications
     *
     * @var Collection
     */
    public Collection $notifications;

    /**
     * The number of notifications to be displayed
     *
     * @var int
     */
    public int $count;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(Collection $notifications, string $title = 'Notifications', int $count = 5)
    {
        $this->notifications = $notifications;
        $this->title = $title;
        $this->count = $count;
    }

    /**
     * Determine the message from the notification object
     *
     * @param DatabaseNotification $notification
     * @return string|null
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getMessage($notification)
    {
        $item = json_decode(json_encode($notification->data));
        return $item->body->message ?? null;
    }

    /**
     * Determine the read class
     *
     * @param DatabaseNotification $notification
     * @return string|null
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function unreadClass(DatabaseNotification $notification): ?string
    {
        return $notification->unread() ? 'unread' : null;
    }

    /**
     * Determine the action route name
     *
     * @return string|null
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function actionRouteName(): ?string
    {
        //  Dynamically determine the route name
        if(Route::is('portal.trainers.*')) {
            return 'portal.trainers.notifications.action';

        } else if(Route::is('portal.trainees.*')) {
            return 'portal.trainees.notifications.action';
        }

        //  Return the manager route by default
        return 'portal.managers.notifications.action';
    }

    /**
     * Determine the view all route name
     *
     * @return string|null
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function viewAllRouteName(): ?string
    {
        //  Dynamically determine the route name
        if(Route::is('portal.trainers.*')) {
            return 'portal.trainers.notifications.index';

        } else if(Route::is('portal.trainees.*')) {
            return 'portal.trainees.notifications.index';
        }

        //  Return the manager route by default
        return 'portal.managers.notifications.index';
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.notifications');
    }
}
