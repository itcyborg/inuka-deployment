<?php

namespace App\View\Components\Modals\Tables;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Illuminate\View\Component;

class TrainingMaterials extends Component
{
    /**
     * The button's text
     *
     * @var
     */
    public string $buttonText;

    /**
     * The title of the modal
     *
     * @var
     */
    public string $title;

    /**
     * The list of training materials
     *
     * @var
     */
    public Collection $trainingMaterials;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($buttonText = '', $title = '', $trainingMaterials = null)
    {
        $this->buttonText = $buttonText;
        $this->title = $title;
        $this->trainingMaterials = $trainingMaterials;
    }

    /**
     * Return the download route name
     * @return string
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function downloadRouteName()
    {
        //  Dynamically determine the route name
        if(Route::is('portal.trainers.*')) {
            return 'portal.trainers.training-materials.download';            
        } else if(Route::is('portal.trainees.*')) {
            return 'portal.trainees.training-materials.download';
        }

        //  Return the manager route by default
        return 'portal.managers.training-materials.download';
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        $this->title = 'Training materials for this module';
        $this->buttonText = 'View Training Materials';
        return view('components.modals.tables.training-materials');
    }
}