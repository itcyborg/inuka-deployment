<?php

namespace App\Models;

use App\Traits\HasRatingAverages;
use App\Traits\HasStatus;
use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Support\Collection;
use OwenIt\Auditing\Contracts\Auditable;

class Trainee extends Model implements Auditable
{

    use HasFactory, HasUuid, HasRatingAverages, HasStatus;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     * @var array
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     *
     */
    protected $fillable = [
        'county_id',
        'trainable_id',
        'trainable_type',
        'business_sector',
        'bio',
        'rating',
        'status'
    ];

    /**
     * Get the owner of the trainee record
     *
     * @return MorphTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainable(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Get the county that a trainee is located
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function county(): BelongsTo
    {
        return $this->belongsTo(County::class);
    }

    /**
     * Get the languages that a trainee can speak
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function languages(): HasMany
    {
        return $this->hasMany(Language::class);
    }

    /**
     * Get the topics that a trainee is assigned to
     *
     * @return BelongsToMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function topics()
    {
        return $this->belongsToMany(Topic::class)->withTimestamps();
    }

    /**
     * Get the topic trainee instances that belong to a trainee
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function topicTrainees(): HasMany
    {
        return $this->hasMany(TopicTrainee::class);
    }

    /**
     * Get the training requests that belong to a trainee
     *
     * @return HasManyThrough
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingRequests(): HasManyThrough
    {
        return $this->hasManyThrough(
            TrainingRequest::class, TopicTrainee::class,
            'trainee_id', 'topic_trainee_id'
        );
    }

    /**
     * Get the ratings that belongs to a trainee
     *
     * @return MorphMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function ratings(): MorphMany
    {
        return $this->morphMany(Rating::class, 'entity');
    }

    /**
     * Get the users that belong to a trainee trainable type
     *
     * @return Collection
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function users(): Collection
    {
        //  Get the trainable model
        $trainable = $this->trainable;

        //  Check if a trainee is a user and return
        //  that user as a collection
        if($this->isAUser()) return collect([ $trainable ]);

        //  Return a collection of organization users
        return $trainable->users;
    }

    /**
     * Check if the trainable model is a user model
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isAUser(): bool
    {
        return get_class($this->trainable) === get_class(new User);
    }

    /**
     * Check if the trainer has an organization
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasAnOrganization(): bool
    {
        return $this->isAUser() && (bool) $this->trainable->organization;
    }

    /**
     * Check if the trainee hs rated
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasRated(): bool
    {
        return (bool) $this->trainer_signature;
    }
}
