<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Support\Facades\DB;
use OwenIt\Auditing\Contracts\Auditable;

class Topic extends Model implements Auditable
{
    use HasFactory, HasUuid;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are guarded.
     *
     * @var array
     */
    protected $guarded = [
        'id', 'created_at', 'updated_at'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'area_id',
    ];

    /**
     * Get the area that a topic belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function area(): BelongsTo
    {
        return $this->belongsTo(Area::class);
    }

    /**
     * Get the trainers that can facilitate a topic
     *
     * @return BelongsToMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainers(): BelongsToMany
    {
        return $this->belongsToMany(Trainer::class)
            ->withTimestamps();
    }

    /**
     * Get the trainees that are assigned to a topic
     *
     * @return BelongsToMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainees()
    {
        return $this->belongsToMany(Trainee::class)->withTimestamps();
    }

    /**
     * Get the training requests that belong to a topic
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingRequests(): HasManyThrough
    {
        return $this->hasManyThrough(
            TrainingRequest::class, TopicTrainee::class,
            'topic_id', 'topic_trainee_id'
        );
    }

    /**
     * Get the latest training requests that belongs to a trainee
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function currentRequest(Trainee $trainee)
    {
        return $this->trainingRequests->sortByDesc(function($trainingRequest){
            return $trainingRequest->created_at->timestamp;
        })->values()->filter(function($trainingRequest) use ($trainee){
            return $trainingRequest->topicTrainee->trainee_id ?? null == $trainee->id;
        })->first();
    }

    /**
     * Check whether topic has training request
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasTrainingRequest()
    {
        return $this->trainingRequests->isNotEmpty();
    }

    /**
     * Check whether topic belongs to trainers
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function belongsToTrainers()
    {
        return $this->trainers->isNotEmpty();
    }
}
