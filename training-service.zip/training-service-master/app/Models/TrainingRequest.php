<?php

namespace App\Models;

use App\Traits\HasStatus;
use App\Traits\HasUuid;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use OwenIt\Auditing\Contracts\Auditable;

class TrainingRequest extends Model implements Auditable
{
    use HasFactory, HasUuid, HasStatus;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'topic_trainee_id', 'trainer_id',
        'status', 'manager_id', 'approved_at', 'responded_at'
    ];

    /**
     * Scope a query to only include requests of a certain type.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $string
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeType($query, string $type)
    {
        return $query->whereIn('status', config("settings.training_request.status.$type"));
    }

    /**
     * Scope a query to only include requests.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeRequests($query)
    {
        return $query->whereIn('status', config('settings.training_request.status.requests'));
    }

    /**
     * Scope a query to only include provisions.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeProvisions($query)
    {
        return $query->whereIn('status', config('settings.training_request.status.provisions'));
    }

    /**
     * Determine more specific statuses
     *
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStatusAttribute($status)
    {
        //  Get the authenticated user
        $user = Auth::user();

        //  Check if the user exists
        if($user) {
            //  Modify the pre evaluation status for an already evaluated trainee
            if($this->hasStatus('AWAITING_PRE-TRAINING_EVALUATION') && $user->isATrainee()
                && $user->hasEvaluated($this->workplan, 'PRE')) {
                return'AWAITING OTHER PRE-TRAINING EVALUATIONS';
            }

            //  Modify the rating status for an already rated user
            if($this->hasStatus('AWAITING_RATING') && $user->hasRated($this)) {
                if($user->isATrainee() && !$user->hasEvaluated($this->workplan, 'POST')) {
                    return 'AWAITING POST-TRAINING EVALUATION';
                }

                //  Handle manager users
                if($user->isAManager()) {
                    //  If both trainers and trainees have not rated
                    if(!$this->trainersHaveRated() && !$this->traineesHaveRated()){
                        return 'AWAITING TRAINER AND TRAINEE RATING';
                    }

                    //  If only trainers have not rated
                    if(!$this->trainersHaveRated()){
                        return 'AWAITING TRAINER RATING';
                    }

                    //  If only trainees have not rated
                    if(!$this->traineesHaveRated()){
                        return 'AWAITING TRAINEE RATING';
                    }
                }

                //  Return the default rating of this type
                return 'AWAITING OTHER RATINGS';
            }
        }

        //  Return the default status
        return $status;
    }

    /**
     * Determine the project start time
     *
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStartDateAttribute(): ?string
    {
        //  Get the workplan modules
        $modules = $this->workplan->modules;

        //  Determine if the actual start dates are available
        $actualStartDates = $modules->pluck('actual_start_date')->filter()->isNotEmpty();

        //  If so, use them to determine the start date
        $attribute = $actualStartDates ? 'actual_start_date' : 'start_date';

        //  Get the earliest start date
        return $modules->sortBy(function($module) use ($attribute){
            return ($module->{$attribute} ?? $module->start_date)
                ->timestamp;
        })->values()->first()->{$attribute} ?? null;
    }

    /**
     * Determine the project end time
     *
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getEndDateAttribute(): ?string
    {
        //  Get the workplan modules
        $modules = $this->workplan->modules;

        //  Determine if the actual end dates are available
        $actualEndDates = $modules->pluck('actual_end_date')->filter()->isNotEmpty();

        //  If so, use them to determine the end date
        $attribute = $actualEndDates ? 'actual_end_date' : 'end_date';

        //  Get the earliest end date
        return $modules->sortByDesc(function($module) use ($attribute){
            return ($module->{$attribute} ?? $module->end_date)
                ->timestamp;
        })->values()->first()->{$attribute} ?? null;
    }

    /**
     * Determine a training request's duration
     *
     * @return int|float
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getDurationAttribute()
    {
        //  Get the start and end date
        $startDate = $this->start_date;
        $endDate = $this->end_date;

        //  Compare the start and end dates
        if($startDate && $endDate) {
            return Carbon::parse($startDate)->diffInHours(
                Carbon::parse($endDate)
            );
        }
    }

    /**
     * Get the course trainer instance that a training request belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function courseTrainee(): BelongsTo
    {
        return $this->belongsTo(CourseTrainee::class);
    }

    /**
     * Get the topic trainer instance that a training request belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function topicTrainee(): BelongsTo
    {
        return $this->belongsTo(TopicTrainee::class);
    }

    /**
     * Get the trainer that a training request belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainer(): BelongsTo
    {
        return $this->belongsTo(Trainer::class);
    }

    /**
     * Get the manager that overlooks a training request
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function manager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    /**
     * Get the workplan that is owned by the training request
     *
     * @return HasOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function workplan(): HasOne
    {
        return $this->hasOne(WorkPlan::class);
    }

    /**
     * Get the sow that is owned by the training request
     *
     * @return HasOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function sow(): HasOne
    {
        return $this->hasOne(Sow::class);
    }

    /**
     * Get the comment that belongs to a training request
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function comments(): MorphOne
    {
        return $this->morphOne(Comment::class, 'commentable');
    }

    /**
     * Get the comment that belongs to a training request
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function ratings(): MorphMany
    {
        return $this->morphMany(Rating::class, 'parent');
    }

    /**
     * Create a workplan from the templates
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function inheritWorkplanFromTemplate(): void
    {
        //  Get all modules
        $modules = ModuleTemplate::all();
        $totalDuration = $modules->sum('duration');

        //  Determine the start and end dates
        $startDate = now()->tomorrow()->addHours(8)->toDateTimeString();
        $endDate = Carbon::parse($startDate)
            ->addHours($totalDuration)
            ->toDateTimeString();

        //  Create a workplan
        $workplan = $this->workplan()->updateOrCreate([
            'approved_at' => now(),
        ]);

        //  Loop through all module templates
        foreach($modules as $module){
            $workplan->modules()->create([
                'module_template_id' => $module->id,
                'name' => $module->name,
                'description' => $module->description,
                'start_date' => $startDate,
                'end_date' => $endDate = Carbon::parse($startDate)
                    ->addHours($module->duration)
                    ->toDateTimeString(),
            ]);

            //  Calculate the new start date
            $startDate = $endDate;
        }
    }

    /**
     * Check if a training request is a provision
     *
     * @param string $status
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isAProvision(): bool
    {
        return $this->hasStatus(
            config('settings.training_request.status.provisions')
        );
    }

    /**
     * Check if a training request is a request
     *
     * @param string $status
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isARequest(): bool
    {
        return $this->hasStatus(
            config('settings.training_request.status.requests')
        );
    }

    /**
     * Get the type of the training request
     *
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function type(): string
    {
        return $this->isAProvision()
            ? 'provision'
            : 'request';
    }

    /**
     * Check if a training request has started
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingHasStarted(): bool
    {
        return $this->workplan->modules->filter(function($module){
            return $module->hasStarted();
        })->isNotEmpty();
    }

     /**
     * Check if a training request has ended
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingHasEnded(): bool
    {
        //  Get the modules
        $modules = $this->workplan->modules;

        //  Ensure all modules are complete
        return $modules->filter(function($module){
            return $module->hasEnded();
        })->count() === $modules->count();
    }

    /**
     * Return the rating of a specific user of a specific type
     *
     * @param User $user
     * @return Collection
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function userRatings(User $user, $update = false)
    {
        //  Get the ratings that belongs to a user. ALso ensure they are of
        //  the type that has been passed.
        $ratings =  $this->ratings
            ->where('user_id', $user->id)
            ->where('type', 'training-request');

        //  If the update flag is not true, return data as is
        if(!$update) return $ratings;

        //  Else, create an update object
        $updateRatings = collect([]);
        $this->ratings->each(function($rating) use ($updateRatings){
            $updateRatings->put($rating->rateable_id, [
                'value' => $rating->value,
                'description' => $rating->description
            ]);
        });

        //  Return the modified object
        return $updateRatings;
    }

    /**
     * Check if trainer has finished rating
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function traineesHaveRated(): bool
    {
        //  Get the ratings that belong to this training request
        $ratings = $this->ratings;

        //  Get the trainee users
        $trainees = $this->topicTrainee->trainee->users()->pluck('id');

        //  Get the trainees that have rated
        $ratedTrainees = $ratings->whereIn('user_id', $trainees->toArray())
            ->pluck('user_id')
            ->unique();

        //  Check if the post evaluation has been completed
        $workplan = $this->workplan;
        $evaluationsDone = $workplan->hasReceivedAllEvaluations($count = $trainees->count(), 'POST');

        //  Check if the number of trainees that have rated is equal to the
        //  total  number of trainees
        return $ratedTrainees->count() === $count
            && $evaluationsDone;
    }

    /**
     * Check if trainer has finished rating
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainersHaveRated(): bool
    {
        //  Get the ratings that belong to this training request
        $ratings = $this->ratings;

        //  Get the trainee users
        $trainers = $this->trainer->users()->pluck('id');

        //  Get the trainers that have rated
        $ratedTrainers = $ratings->whereIn('user_id', $trainers->toArray())
            ->pluck('user_id')
            ->unique();

        //  Check if the number of trainers that have rated is equal to the
        //  total  number of trainers and all evaluations have been done
        return $ratedTrainers->count() === $trainers->count();
    }

    /**
     * Check if trainer has finished rating
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function managersHaveRated(): bool
    {
        //  Get the Manager IDs
        $managerIds = User::permission('view_manager_portal')
            ->permission('create_ratings')
            ->pluck('id')
            ->toArray();

        //  Get the ratings that belong to this training request
        return $this->ratings
            ->whereIn('user_id', $managerIds)
            ->isNotEmpty();
    }

    /**
     * Check if trainer has finished rating
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isCompleted(): bool
    {
        //  Refresh this instance
        $this->refresh();

        //  Check if all conditions have been met
        return $this->trainersHaveRated()
            && $this->traineesHaveRated()
            && $this->managersHaveRated();
    }
}
