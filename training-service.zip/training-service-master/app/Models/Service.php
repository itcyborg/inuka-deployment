<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use OwenIt\Auditing\Contracts\Auditable;

class Service extends Model implements Auditable
{
    use \OwenIt\Auditing\Auditable;

    use HasFactory, HasUuid;

    /**
     * The attributes that are guarded.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'created_at',
        'updated_at'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name'
    ];

    /**
     * Get a service's areas
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function areas(): HasMany
    {
        return $this->hasMany(Area::class);
    }

   /**
     * Get a service's topics through the area
     *
     * @return HasManyThrough
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function topics(): HasManyThrough
    {
        return $this->hasManyThrough(Topic::class, Area::class);
    }

    /**
     * Check whether service has topics
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasTopics()
    {
        return $this->topics->isNotEmpty();
    }
}
