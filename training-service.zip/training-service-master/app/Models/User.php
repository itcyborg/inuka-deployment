<?php

namespace App\Models;

use App\Traits\HasAuthorizationChecks;
use App\Traits\HasSignatureKeys;
use App\Traits\HasSocialAuth;
use App\Traits\HasStatus;
use App\Traits\HasUuid;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use OwenIt\Auditing\Contracts\Auditable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable implements MustVerifyEmail, Auditable
{
    use HasFactory,
        HasUuid,
        HasSocialAuth,
        HasApiTokens,
        HasStatus,
        HasRoles,
        HasSignatureKeys,
        HasAuthorizationChecks,
        \OwenIt\Auditing\Auditable,
        Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    /**
     * Define tabel to read
     */
    protected $table = 'sso_users';

    protected $fillable = [
        'organization_id', 'county_id',
        'name', 'email', 'telephone',
        'gender', 'password',
        'locality', 'status', 'email_verified_at', 
        'staff_id', 'branch', 'mpassword', 'twofa',
        'twofa_secret', 'api_name', 'api_key', 'type',
        'active', 'notes', 'reset', 'deleted', 'default_system',
        'allowed_systems'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime'
    ];

    /**
     * Attributes that will be appended to the request
     *
     * @var array
     */
    protected $appends = [
        'avatar',
        'roles'
    ];

    /**
     *  Create an accessor for the avatar attribute
     *
     * @var null|string
     */
    public function getAvatarAttribute()
    {
        return $this->uploads->where('type', 'avatar')->first()->path ?? null;
    }

    public function getRoleAttribute()
    {
        return $this->roles()->get();
    }

    public function getRolesAttribute()
    {
        return $this->roles()->get();
    }

    /**
     * Get the social auth profile that belongs to a user
     *
     * @return HasOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function socialAuth(): HasOne
    {
        return $this->hasOne(Social::class);
    }

    /**
     * Get the uploads that belong to a user
     *
     * @return MorphMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function uploads(): MorphMany
    {
        return $this->morphMany(Upload::class, 'uploadable');
    }

    /**
     * Get the organization that a user belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    /**
     * Get the county that a user belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function county(): BelongsTo
    {
        return $this->belongsTo(County::class);
    }

    /**
     * Get a user's trainer record
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainer(): MorphOne
    {
        return $this->morphOne(Trainer::class, 'trainable');
    }

    /**
     * Get a user's trainees record
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainee()
    {
        return $this->morphOne(Trainee::class, 'trainable');
    }

    /**
     * Get the signature ke that belongs to a user
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function signatureKeys(): HasOne
    {
        return $this->hasOne(SignatureKey::class);
    }

    /**
     * Get the evaluations ke that belongs to a user
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function evaluations(): HasMany
    {
        return $this->hasMany(Evaluation::class);
    }

    /**
     * Get the ratings that belongs to a user
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function ratings(): HasMany
    {
        return $this->hasMany(Rating::class);
    }

    /**
     * Get the comment that belongs to a user
     *
     * @return MorphMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function comments(): MorphMany
    {
        return $this->morphMany(Comment::class, 'commentable');
    }

    /**
     * Assign default permissions to a user
     *
     * @param array|string $roles
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function assignDefaultPermissions($systemRoles): void
    {
        //  Get the systemRoles defined
        $permissions = json_decode(file_get_contents(
            database_path('data/json/permissions.json')
        ));
        
        //  Ensure that the role(s) is received as an array
        $systemRoles = is_array($systemRoles) ? $systemRoles : [$systemRoles];

        //  Assign the default role(s)
        $this->syncRoles($systemRoles);

        //  Assign default permissions
        collect($systemRoles)->each(function ($role) use ($permissions) {
            //  Get the groups
            $groups = $permissions->{$role};

            //  Get the values from groups
            $values = array_merge(...array_values((array) $groups));

            //  Assign the permissions to the user
            $this->givePermissionTo($values);
        });
    }

    /**
     * Check if a user is a trainer
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isATrainer()
    {
        return $this->isADirectTrainer()
            || $this->isATrainerViaAnOrganization();
    }

    /**
     * Check if a user is a direct trainer
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isADirectTrainer()
    {
        return (bool) $this->trainer;
    }

    /**
      * Check if a user is a trainer via an organization
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isATrainerViaAnOrganization()
    {
        return (bool) ($organization = $this->organization)
            &&  $organization->isATrainer();
    }

    /**
      * Get a trainer user's profile
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTrainerProfile()
    {
        return $this->isADirectTrainer()
            ? $this->trainer
            : $this->organization->trainer ?? null;
    }

    /**
     * Check if a user is a trainee
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isATrainee()
    {
        return $this->isADirectTrainee()
            || $this->isATraineeViaAnOrganization();
    }

    /**
     * Check if a user is a direct trainee
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isADirectTrainee()
    {
        return (bool) $this->trainee;
    }

    /**
     * Check if a user is a trainee via an organization
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isATraineeViaAnOrganization()
    {
        return (bool) ($organization = $this->organization)
            &&  $organization->isATrainee();
    }

    /**
      * Get a trainee user's profile
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getTraineeProfile()
    {
        return $this->isADirectTrainee()
            ? $this->trainee
            : $this->organization->trainee ?? null;
    }

    /*
     * Check if a user is a manager
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isAManager()
    {
        return $this->hasPermissionTo('view_manager_portal');
    }

    /**
     * Check if a user has already provided feedback
     *
     * @param Workplan $workplan
     * @param string $type
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasEvaluated(Workplan $workplan, $type = 'PRE')
    {
        return (bool) $this->evaluations
            ->where('work_plan_id', $workplan->id)
            ->where('type', $type)
            ->isNotEmpty();
    }

    /**
     * Check if a user has already provided ratings
     *
     * @param TrainingRequest $trainingRequest
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasRated(TrainingRequest $trainingRequest): bool
    {
        return (bool) $this->ratings
            ->where('parent_id', $trainingRequest->id)
            ->isNotEmpty();
    }
}
