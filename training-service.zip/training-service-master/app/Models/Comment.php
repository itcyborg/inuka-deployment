<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

class Comment extends Model implements Auditable
{
    use HasFactory, HasUuid;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'comment',
        'commentable_id',
        'commentable_type'
    ];

    /**
     * Get the parent commetable model (training request or anyother model).
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function commentable()
    {
        return $this->morphTo();
    }

    /**
     *A comments belongs to a training Request
     */
    public function trainingRequest()
    {
        return $this->belongsTo(TrainingRequest::class);
    }

    /**
     *A comments belongs to a training Request
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
