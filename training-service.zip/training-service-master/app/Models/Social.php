<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Social extends Model
{
    /**
     * Attributes that are mass fillable
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'nickname', 'provider', 'provider_id', 'token',
        'token_secret', 'refresh_token', 'token_expires_at',
    ];

    /**
     * Attributes that should be cast to dates
     *
     * @var array
     */
    protected $dates = [
        'token_expires_at'
    ];

    /**
     * Set the token expiration time
     *
     * @param  string  $value
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function setTokenExpiresAtAttribute(string $value)
    {
        //  Check if the time value exists
        if($value) {
            $this->attributes['token_expires_at'] = now()->addSeconds($value);
        }
    }

    /**
     * Return the user that owns the auth information
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
