<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use OwenIt\Auditing\Contracts\Auditable;

class WorkPlan extends Model implements Auditable
{
    use HasFactory, HasUuid, \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'training_request_id', 'approved_at', 'status'
    ];

    /**
     * Get the training request that owns a workplan
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingRequest(): BelongsTo
    {
        return $this->belongsTo(TrainingRequest::class);
    }

    /**
     * Get the modules that belong to a workplan
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function modules(): HasMany
    {
        return $this->hasMany(WorkPlanModule::class);
    }

    /**
     * Get the evaluations that belong to a workplan
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function evaluations()
    {
        return $this->hasMany(Evaluation::class);
    }

    /**
     * Get the evaluation for a specific user
     *
     * @param User $user
     * @param string $type
     * @return Evaluation|null
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function evaluation(User $user, string $type)
    {
        return $this->evaluations
            ->where('user_id', $user->id)
            ->where('type', $type)
            ->first();
    }

    /**
     * Check if all evaluations have been submitted
     *
     * @param int $userCount
     * @param string $type
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasReceivedAllEvaluations(int $userCount, string $type): bool
    {
        //  Count the number of submitted evaluations
        $evaluationCount = $this->evaluations->where('type', $type)->count();

        //  Compare the 2 values
        return $userCount === $evaluationCount;
    }

    /**
     * Get the first module in a particular workplan
     *
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function firstModule()
    {
        return $this->modules->sortBy(function($module){
            return $module->created_at->timestamp;
        })->values()->first();
    }
}
