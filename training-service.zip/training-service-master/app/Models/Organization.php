<?php

namespace App\Models;

use App\Traits\HasStatus;
use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use OwenIt\Auditing\Contracts\Auditable;

class Organization extends Model implements Auditable
{
    use HasFactory, HasUuid, HasStatus;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'public_id', 'county_id',
        'name', 'email', 'telephone',
        'locality', 'status'
    ];

    /**
     * Scope a query to search by uid.
     *
     * @param  Builder  $query
     * @param  string|null  $publicId
     * @return Builder
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function scopePublicId(Builder $query, ?string $publicId): Builder
    {
        return $query->where('public_id', $publicId);
    }

    /**
     * Get an organization's users
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    /**
     * Get an organization's trainee record
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainee(): MorphOne
    {
        return $this->morphOne(Trainee::class, 'trainable');
    }

    /**
     * Get an organization's trainer record
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainer(): MorphOne
    {
        return $this->morphOne(Trainer::class, 'trainable');
    }

    /**
     * Get the county that a user belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function county(): BelongsTo
    {
        return $this->belongsTo(County::class);
    }

    /**
     * Check if an organization is a direct trainer
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isATrainer()
    {
        return (bool) $this->trainer;
    }

    /**
     * Check if an organization is a direct trainee
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isATrainee()
    {
        return (bool) $this->trainee;
    }


    /**
     * Check whether an organization has users
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasUsers()
    {
        return $this->users->isNotEmpty();
    }
}
