<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\Pivot;

class CourseTrainee extends Pivot
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'course_id',
        'trainee_id'
    ];

    /**
     * Get the course that a course trainee instance owns
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class);
    }

    /**
     * Get the trainee that a course trainee instance owns
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainee(): BelongsTo
    {
        return $this->belongsTo(Trainee::class);
    }
}
