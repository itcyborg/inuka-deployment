<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use OwenIt\Auditing\Contracts\Auditable;

class Evaluation extends Model implements Auditable
{
    use HasFactory, HasUuid;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'work_plan_id',
        'user_id',
        'type',
        'suggestion'
    ];

    /**
     * Get the user that made the evaluation
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the workplan that owns the evaluation
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function workplan(): BelongsTo
    {
        return $this->belongsTo(WorkPlan::class, 'work_plan_id');
    }

    /**
     * Get the user that made the evaluation
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function ratings(): MorphMany
    {
        return $this->morphMany(Rating::class, 'entity');
    }

    /**
     * Get Saved Ratings for a particular evaluation
     *
     * @param \App\Models\Evaluation $evaluation
     * @return Evaluation
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function loadSavedRatings()
    {
        //  Get the saved ratings
        $ratings = collect([]);
        $this->ratings->each(function($rating) use ($ratings){
             $ratings->put($rating->rateable_id, [
                 'value' => $rating->value,
                 'description' => $rating->description
             ]);
         });

        //  Attach the saved ratings
        $this->saved_ratings = $ratings;

        //  Return the modifed object
        return $this;
    }
}
