<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use OwenIt\Auditing\Contracts\Auditable;

class Rating extends Model implements Auditable
{
    use HasFactory, HasUuid;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'rateable_id',
        'rateable_type',
        'entity_id',
        'entity_type',
        'parent_id',
        'parent_type',
        'type',
        'user_id',
        'value',
        'max_value',
        'description',
    ];

    /**
     * Get the percentage value of a rating
     *
     * @return float|void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getRatingPercentageAttribute()
    {
        //Check if value and max_value are numeric
        if(is_numeric($value = $this->value ) && is_numeric($maxValue = $this->max_value )) {

            return (float) $value / (float) $maxValue * 100;

        }
    }

    /**
     * Get the user that made the evaluation
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the model that the remark pertains
     *
     * @return MorphTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function rateable(): MorphTo
    {
        return $this->morphTo();
    }

     /**
     * Get the module that the remark describes
     *
     * @return MorphTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function entity(): MorphTo
    {
        return $this->morphTo();
    }


    public function getUserId($value)
    {
        return User::find($value)->name;
    }
}
