<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Support\Collection;
use OwenIt\Auditing\Contracts\Auditable;

class WorkPlanModule extends Model implements Auditable
{
    use HasFactory, HasUuid, \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'training_request_id', 'module_template_id',
        'name', 'description',
        'start_date', 'end_date',
        'actual_start_date', 'actual_end_date'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'start_date' => 'datetime',
        'end_date' => 'datetime',
        'actual_start_date' => 'datetime',
        'actual_end_date' => 'datetime',
    ];

    /**
     * Determine a workplan module's duration
     *
     * @return int|float
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getDurationAttribute()
    {
        return $this->start_date->diffInHours($this->end_date);
    }

    /**
     * Determine the sow duration
     *
     * @return int|float
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getActualDurationAttribute()
    {
        //  Get the actual start and end date
        $startDate = $this->actual_start_date;
        $endDate = $this->actual_end_date;

        //  If both the start and end date have been defined
        if($startDate && $endDate) {
            return $startDate->diffInHours($endDate);
        }
    }

    /**
     * Determine the status of the module
     *
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStatusAttribute(): ?string
    {
         //  If the module is on going, return the status
         if(!$this->hasStarted()) return 'NOT STARTED';

        //  If the module is on going, return the status
        if($this->isOngoing()) return 'ON GOING';

        //  If the module has come to an end return the status
        if($this->completedOnTime()) return 'COMPLETED ON TIME';

        //  If the module has come to an end return the status
        if(!$this->completedOnTime()) return 'COMPLETED LATE';
    }

    /**
     * Get the workplan that owns the module
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function workplan(): BelongsTo
    {
        return $this->belongsTo(WorkPlan::class, 'work_plan_id');
    }

    /**
     * Get the workplan that owns the module
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function uploads(): MorphMany
    {
        return $this->morphMany(Upload::class, 'uploadable');
    }

    /**
     * Get the module template that owns the module
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function moduleTemplate(): BelongsTo
    {
        return $this->belongsTo(ModuleTemplate::class);
    }

    /**
     * Get the training materials that belong to a module
     *
     * @return Collection
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingMaterials(): Collection
    {
        //  Get all uploads directly related to the module
        $directUploads = $this->uploads->where('type', 'training-material');

        //  Set indirect uploads to an empty collection
        $indirectUploads = collect([]);

        //  Get the related module template
        $moduleTemplate = $this->moduleTemplate;

        //  If the module template exists, get its uploads
        if($moduleTemplate) {
            //  Get all uploads related to the module via the tempalate
            $indirectUploads = $moduleTemplate->uploads->where('type', 'training-material');
        }

        //  Return all possible uploads
        return $directUploads->merge($indirectUploads);
    }

    /**
     * Start a workplan module
     *
     * @param bool $provisionJustStrated
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function start(&$provisionJustStrated): void
    {
        //  Get the training request that owns the module
        $trainingRequest = $this->workplan->trainingRequest;

        //  Update the status of the training request if this
        //  is the first module to start.
        if($trainingRequest->hasStatus('AWAITING_COMMENCEMENT')) {
            //  Set status as ongoing
            $trainingRequest->setStatus('ONGOING');

            //  Set the provision just begun flag to true
            $provisionJustStrated = true;
        }

        //  Finally Set the actual start date
        $this->update(['actual_start_date' => now()]);
    }

    /**
     * End a workplan module
     *
     * @param bool $provisionJustEnded
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function end(&$provisionJustEnded): void
    {
        //  Set the actual end date for the module
        $this->update(['actual_end_date' => now()]);

        //  Get the workplan
        $workplan = $this->workplan->refresh();

        //  Get the training request that owns the module
        $trainingRequest = $workplan->trainingRequest;

        //  Get all the modules
        $modules = $workplan->modules;

        //  Ended modules
        $endedModules = $modules->where('actual_end_date', '!=', null)->count();

        //  Update the status of the training request if this is the last module to end.
        if($trainingRequest->hasStatus('ONGOING') && ($modules->count() === $endedModules)) {
            //  Update the rating
            $trainingRequest->setStatus('AWAITING_RATING');

            //  Set the provision just begun flag to true
            $provisionJustEnded = true;
        }
    }

    /**
     * Check if module has started
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasStarted(): bool
    {
        return (bool) $this->actual_start_date;
    }

    /**
     * Check if module has ended
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasEnded(): bool
    {
        return $this->hasStarted() && (bool) $this->actual_end_date;
    }

    /**
     * Check if module is on going
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isOngoing(): bool
    {
        return $this->hasStarted()
            && !$this->hasEnded();
    }

     /**
     * Check if module was completed on time
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function completedOnTime(): bool
    {
        //  Compute the end time
        $endDate = $this->end_date;
        $actualEndDate = $this->actual_end_date;

        //  Check if the end dates have been defined
        if($endDate && $actualEndDate) {
            return $this->hasEnded()
                && $actualEndDate->lte($endDate);
        }

        //  Return the default completed time
        return false;
    }
}
