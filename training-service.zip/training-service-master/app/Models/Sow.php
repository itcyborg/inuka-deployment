<?php

namespace App\Models;

use App\Traits\HasUuid;
use App\Traits\ManagesSignatures;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use OwenIt\Auditing\Contracts\Auditable;

class Sow extends Model implements Auditable
{
    use HasFactory, HasUuid, ManagesSignatures;

    use \OwenIt\Auditing\Auditable;

    /**
     * Attributes that are mass fillable
     *
     * @var array
     */
    protected $fillable = [
        'training_request_id',
        'trainer_id', 'manager_id',
        'contract_no', 'sow_no',
        'fee', 'fee_arrangement',
        'effort_level', 'effort_level_unit',
        'deliverables', 'sow_date',
        'commencement_date', 'termination_date',
        'trainer_signature', 'trainer_signature_date',
        'manager_signature', 'manager_signature_date',
        'is_valid'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'sow_date' => 'date',
        'commencement_date' => 'date',
        'termination_date' => 'date',
    ];

    /**
     * The attributes that should be appended to the request.
     *
     * @var array
     */
    protected $appends = [
        'duration',
    ];

    /**
     * Determine the sow duration
     *
     * @return int|float
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getDurationAttribute()
    {
        return $this->commencement_date->diffInDays($this->termination_date);
    }

    /**
     * Get the training request that an sow belongs to
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingRequest(): BelongsTo
    {
        return $this->belongsTo(TrainingRequest::class);
    }

    /**
     * Get the manager user that signed the sow.
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function manager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    /**
     * Get the trainer user that signed the sow.
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'trainer_id');
    }
}
