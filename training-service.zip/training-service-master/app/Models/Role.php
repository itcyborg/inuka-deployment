<?php

namespace App\Models;

use Spatie\Permission\Models\Role as RoleModel;

class Role extends RoleModel
{
    protected $table = 'roles';
    
    // public function getNameAttribute(){
    //     return $this->title;
    // }    
}
