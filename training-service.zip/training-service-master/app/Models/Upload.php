<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use OwenIt\Auditing\Contracts\Auditable;

class Upload extends Model implements Auditable
{
    use HasFactory, HasUuid;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'uploadable_id', 'uploadable_type', 'user_id',
        'name', 'path', 'type'
    ];

    /**
     * Scope the query by type
     *
     * @param $query
     * @param $type
     * @return Builder
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function scopeType(Builder $query, string $type): Builder
    {
        return $query->where('type', $type);
    }

    /**
     * Get the model that the upload pertains
     *
     * @return MorphTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function uploadable(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Get the owner of the upload
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
