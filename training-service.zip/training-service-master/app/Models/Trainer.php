<?php

namespace App\Models;

use App\Events\PassedPreQualification;
use App\Traits\HasRatingAverages;
use App\Traits\HasStatus;
use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use OwenIt\Auditing\Contracts\Auditable;

class Trainer extends Model implements Auditable
{
    use HasFactory, HasUuid, HasRatingAverages, HasStatus;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'trainable_id', 'trainable_type',
        'website', 'bio', 'rating', 'pre_qualification_rating',
        'status'
    ];

    /**
     * Determine more specific statuses
     *
     * @return string
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function getStatusAttribute($status)
    {
        //  Get the authenticated user
        $user = Auth::user();

        //  Handle manager users
        if ($user->isAManager()) {
            //  If manager has rated
            if ($this->managerHasRated($user) && !$this->prequalificationIsComplete()) {
                return 'AWAITING OTHER MANAGERS RATING';
            }
        }

        return $status;
    }

    /**
     * Get the owner of the trainer record
     *
     * @return MorphTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainable(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Get the topics that a trainer has
     *
     * @return BelongsToMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function topics(): BelongsToMany
    {
        return $this->belongsToMany(Topic::class)
            ->withTimestamps();
    }

    /**
     * Get the training requests that belong to a traine
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function trainingRequests(): HasMany
    {
        return $this->hasMany(TrainingRequest::class);
    }

    /**
     * Get the county that a trainer is located
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function county(): BelongsTo
    {
        return $this->belongsTo(County::class);
    }

    /**
     * Get the languages that a trainer can speak
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function languages(): HasMany
    {
        return $this->hasMany(Language::class);
    }

    /**
     * Get the qualifications that a trainer has
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function qualifications(): HasMany
    {
        return $this->hasMany(Qualification::class);
    }

    /**
     * Get the experiences that a trainer has
     *
     * @return HasMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function experiences(): HasMany
    {
        return $this->hasMany(Experience::class);
    }

    /**
     * Get the uploads that a trainer owns
     *
     * @return MorphMany
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function uploads(): MorphMany
    {
        return $this->morphMany(Upload::class, 'uploadable');
    }

    /**
     * Get the ratings that belongs to a training request
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function ratings(): MorphMany
    {
        return $this->morphMany(Rating::class, 'entity');
    }

    /**
     * Get the pre-qualification ratings that belongs to a trainer
     *
     * @return MorphOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function preQualifications(): MorphMany
    {
        return $this->morphMany(Rating::class, 'parent');
    }

    /**
     * Get the users that belong to a trainer trainable type
     *
     * @return Collection
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function users(): Collection
    {
        //  Get the trainable model
        $trainable = $this->trainable;

        //  Check if a trainer is a user and return
        //  that user as a collection
        if ($this->isAUser()) return collect([$trainable]);

        //  Return a collection of organization users
        return $trainable->users;
    }

    /**
     * Check if the trainable model is a user model
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isAUser(): bool
    {
        return get_class($this->trainable) === get_class(new User);
    }

    /**
     * Check if the trainer has an organization
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasAnOrganization(): bool
    {
        return $this->isAUser() && (bool) $this->trainable->organization;
    }

    /**
     * Check if the trainer has contact people
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasContactPeople(): bool
    {
        return !$this->isAUser() && $this->contactPeople()->isNotEmpty();
    }

    /**
     * Return an upload of a specific type
     *
     * @return \App\Models\Upload
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function uploadOfType(string $type)
    {
        return $this->uploads
            ->where('type', $type)
            ->first();
    }

    /**
     * Check if a trainer is under pre-qualification
     *
     * @param string $status
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function isPreQualified(): bool
    {
        return $this->hasStatus('PREQUALIFIED');
    }

    /**
     * Get the trainer organization's contact people
     *
     * @param bool $all
     * @return \Illuminate\Support\Collection
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function contactPeople($permission = 'contact_person')
    {
        //  Get the trainable model
        $trainable = $this->trainable;

        //  Check if the trainer instance is an organization
        if (!$this->isAUser()) {
            //  Return the oldest contact person user
            return $trainable->users()
                ->permission($permission)
                ->get();
        }

        //  Return the trainable model by default
        return collect([$trainable]);
    }

    /**
     * Get the trainer organization's signatories
     *
     * @return \Illuminate\Support\Collection
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function signatories()
    {
        return $this->contactPeople('sign_sows');
    }

    /**
     * Check id user has qualifications
     * 
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function hasQualifications()
    {
        return $this->qualifications()->exists();
    }

    /**
     * Return the rating of a specific user of a specific type
     *
     * @param User $user
     * @return Collection
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function userRatings(User $user, $update = false)
    {
        //  Get the ratings that belongs to a user. ALso ensure they are of
        //  the type that has been passed.
        $ratings =  $this->ratings
            ->where('user_id', $user->id)
            ->where('type', 'pre-qualification');

        //  If the update flag is not true, return data as is
        if (!$update) return $ratings;

        //  Else, create an update object
        $updateRatings = collect([]);
        $this->ratings->each(function ($rating) use ($updateRatings) {
            $updateRatings->put($rating->rateable_id, [
                'value' => $rating->value,
                'description' => $rating->description
            ]);
        });

        //  Return the modified object
        return $updateRatings;
    }

    /**
     * Check if manager has finished rating
     *
     * @param User $user
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function managerHasRated(User $user): bool
    {
        //  Get the ratings that belong to this trainer
        return $this->ratings
            ->where('user_id', $user->id)
            ->isNotEmpty();
    }

    /**
     * Get the average pre-qualification rating of a trainer
     *
     * @return void
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function storeAveragePreQualificationRating(): void
    {
        //get collection of pre-qualification ratings to a specific trainer with entity (rating parameter)
        $ratings = $this->ratings()
            ->with('rateable')
            ->where([
                ['type', 'pre-qualification'],
                ['entity_type', Trainer::make()->getMorphClass()],
                ['entity_id', $this->id],
            ])->get();

        //if ratigs collection is not empty
        if ($ratings->isNotEmpty()) {
            //  Get the avarage value
            $rating = $ratings->map(function ($rating) {
                return $rating->value / $rating->rateable->max_rating;
            })->average();

            //  Update trainee rating
            $this->update(['pre_qualification_rating' => $rating]);
        }
    }

    /**
     * Check whether all the pre-qualification raters have rated
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function managersHaveRated(): bool
    {
        //  Get the Manager IDs
        $managerIds = User::permission('view_manager_portal')
            ->permission('view_pre_qualification_ratings')
            ->pluck('id')
            ->toArray();

        //  Get the number of managers that have rated a trainer
        $managerRatingsCount = $this->ratings
            ->where('type', 'pre-qualification')
            ->whereIn('user_id', $managerIds)
            ->unique('user_id')
            ->count();

        return $managerRatingsCount == config('settings.required_number_of_prequalification_raters');
    }

    /**
     * Check if trainer has finished rating
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function prequalificationIsComplete(): bool
    {
        //  Refresh this instance
        $this->refresh();

        //  Check if all conditions have been met
        return $this->managersHaveRated();
    }

    /**
     * Check if trainer trainer rating against set threshold
     *
     * @return bool
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */

    public function checkTrainerPrequalificationThreshold(): bool
    {
        //convert the the pre_qualification_rating to percentage
        $percentageAverage = (float) $this->pre_qualification_rating * 100;

        // check if the percentage is greater or equal to the prequalification_threshold in settings
        return $percentageAverage >= config('settings.prequalification_threshold');
    }
}
