<?php

namespace App\Models;

use App\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use OwenIt\Auditing\Contracts\Auditable;

class ModuleTemplate extends Model implements Auditable
{
    use HasFactory, HasUuid;

    use \OwenIt\Auditing\Auditable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'description', 'duration'
    ];

    /**
     * Get the workplan that owns the module
     *
     * @return BelongsTo
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function uploads(): MorphMany
    {
        return $this->morphMany(Upload::class, 'uploadable');
    }

    /**
     * Get the work plan module that belongs to the module template
     *
     * @return HasOne
     * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function workplanModule(): HasOne
    {
        return $this->hasOne(WorkPlanModule::class);
    }
}
