<?php

namespace App\Events;

use App\Models\User;
use App\Models\WorkplanModule;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class WorkplanModuleStarted
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Define the training request variable
     *
     * @return void
     */
    public WorkplanModule $module;

    /**
     * The trainer user.
     *
     * @var TrainingRequest
     */
    public User $trainer;

    /**
     * Create a new event instance.
     *
     * @param WorkplanModule $module
     * @param User $trainer
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function __construct(WorkplanModule $module, User $trainer)
    {
        $this->module = $module;
        $this->trainer = $trainer;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
