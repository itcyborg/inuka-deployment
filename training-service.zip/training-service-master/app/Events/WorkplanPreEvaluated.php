<?php

namespace App\Events;

use App\Models\Workplan;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class WorkplanPreEvaluated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Define the training request variable
     *
     * @return void
     */
    public Workplan $workplan;

    /**
     * Create a new event instance.
     *
     * @param Workplan $workplan
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function __construct(Workplan $workplan)
    {
        $this->workplan = $workplan;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
