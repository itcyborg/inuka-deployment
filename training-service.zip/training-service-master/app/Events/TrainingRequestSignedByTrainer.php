<?php

namespace App\Events;

use App\Models\TrainingRequest;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class TrainingRequestSignedByTrainer
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Define the training request variable
     *
     * @return void
     */
    public TrainingRequest $trainingRequest;

    /**
     * Create a new event instance.
     *
     * @param TrainingRequest $trainingRequest
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function __construct(TrainingRequest $trainingRequest)
    {
        $this->trainingRequest = $trainingRequest;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
