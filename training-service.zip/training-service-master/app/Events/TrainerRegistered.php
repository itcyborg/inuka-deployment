<?php

namespace App\Events;

use App\Models\Trainer;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class TrainerRegistered
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * The trainer user.
     *
     * @var TrainingRequest
     */
    public Trainer $trainer;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Trainer $trainer)
    {
        $this->trainer = $trainer;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
