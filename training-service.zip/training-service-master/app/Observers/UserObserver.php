<?php

namespace App\Observers;

use App\Models\User;

class UserObserver
{
    /**
     * Handle the User "created" event.
     *
     * @param  \App\Models\User  $user
     * @return void
     * * @author Nderi Kamau <nderikamau1212@gmail.com>
     */
    public function created(User $user)
    {
        //  Generate signature keys
        $user->generateSignatureKeys();
    }
}
