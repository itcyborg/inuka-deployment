<?php

namespace App\Observers;

use App\Models\Setting;
use App\Models\SettingValue;
use Illuminate\Support\Facades\Cache;

class SettingValueObserver
{
    /**
     * Handle the Setting "created" event.
     *
     * @param  \App\Models\SettingValue  $settingValue
     * @return void
     * @author Nderi kamau nderikamau1212@gmail.com>
     */
    public function saving(SettingValue $settingValue)
    {
        // delete the existing cache
        Setting::clearCache();

        //create new cache settings data
        Cache::rememberForever('settings', function () {
            return Setting::all();
        });
    }
}
