<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('process',[\App\Http\Controllers\PayslipController::class,'process']);
Route::get('payslips',[\App\Http\Controllers\PayslipController::class,'index']);
Route::get('ts',function(){
    \App\Jobs\SendPayslip::dispatch(\App\PayslipV1::find(318));
});
