<?php

    use App\Mail\PayslipMail;
    use App\Role;
    use App\Staff;
    use App\StaffRole;
    use Barryvdh\DomPDF\Facade;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Log;
    use Illuminate\Support\Facades\Mail;
    use Illuminate\Support\Facades\Route;
    use Illuminate\Support\Facades\Storage;

    /*
    |--------------------------------------------------------------------------
    | Web Routes
    |--------------------------------------------------------------------------
    |
    | Here is where you can register web routes for your application. These
    | routes are loaded by the RouteServiceProvider within a group which
    | contains the "web" middleware group. Now create something great!
    |
    */

Route::get('/', function () {
    $pdf = PDF::loadView('layouts.pdf');
    return $pdf->stream();
//    return $pdf->download('payslip.pdf');
//    return view('layouts.pdf');
});

Route::get('/test', function () {
    $payslip = \App\PayslipV1::orderBy('created_at','desc')->first();
    $staff=null;
    $branch=null;
    $role=null;
    $data=null;
    $region=null;
    $performance=null;
    // check status
    // check if notify is enabled
    // check if schedule is set
//        dd($this->payslip);
    $payslip=$payslip;
    if($payslip->status=='pending' || $payslip->status=='failed') {
        if ($payslip->notify) {
//            $this->delay($payslip->schedule_notify);
            $staff = Staff::find($payslip->staff_id);
            $staff_role = StaffRole::where('staff', '=', $staff->id)->first();
            $role = Role::find($staff_role->role);
            $branch = (object)['name' => $payslip->branch];
            $region = (object)['name' => $payslip->region];
            $performance_heads = $payslip->performance_heads;
            $email = $staff->email;
            $bank = DB::table('hrm_banks')
                ->where('id', $staff->bank)
                ->first();
            $data = (object)[
                'month' => $payslip->month,
                'year' => $payslip->year,
                'retainer' => $payslip->earnings->basic_pay ?? $role->retainer,
                'performance' => $payslip->performance_heads,
                'commissions' => $payslip->earnings->commissions,
                'bonuses' => $payslip->earnings->bonuses,
                'total_other' => $payslip->earnings->total_other,
                'gratuity' => $payslip->earnings->gratuity,
                'total_earned' => $payslip->total_earnings,
                'total_paid' => $payslip->taxable_earnings,
                'paye' => $payslip->deductions->paye,
                'nhif' => $payslip->deductions->nhif,
                'nssf' => $payslip->deductions->nssf,
                'helb' => $payslip->deductions->helb,
                'sacco' => $payslip->deductions->sacco,
                'sacco_loan' => $payslip->deductions->sacco_loan,
                'welfare' => $payslip->deductions->welfare,
                'other_deductions' => $payslip->deductions->other_deductions,
                'total_deductions' => $payslip->total_deductions,
                'net_pay' => $payslip->net_pay,
                'tax_type' => $role->tax_type,
                'role_security' => $payslip->role_security
            ];
            $role = (object)[
                'title' => $role->title
            ];
            $staff = (object)[
                'name' => $staff->name,
                'id' => $staff->id,
                'telephone' => $staff->telephone,
                'status' => $staff->status,
                'pay_mode' => $staff->pay_mode,
                'ac_number' => $staff->ac_number,
                'join_date' => $staff->join_date
            ];
            $performance = $performance_heads;
            $template_name = null;
            switch ($payslip->template) {
                case 'hq':
                    $template_name = 'HQ';
                    break;
                case 'admin':
                    $template_name = 'admin';
                    break;
                case 'admin_reliever':
                    $template_name = 'admin_relievers';
                    break;
                case 'bs':
                    $template_name = 'BS';
                    break;
                case 'lo':
                    $template_name = 'LO';
                    break;
                case 'rm':
                    $template_name = 'RM';
                    break;
                case 'ro':
                    $template_name = 'RO';
                    break;
                default:
                    Log::emergency('Template file not found for :' . $payslip->template);
                    return;
            }
            $path = Storage::disk('local')->path('');
            $file_name = "payslip" . $payslip->id . $staff->id . ".pdf";

            return view($template_name, compact(
                'staff',
                'data',
                'role',
                'branch',
                'region',
                'performance',
                'bank'
            ));
            if (Facade::loadView($template_name, compact(
                'staff',
                'data',
                'role',
                'branch',
                'region',
                'performance',
                'bank'
            ))->save($path . $file_name)) {
                Mail::to($email)->send(new PayslipMail($file_name));
            }
        }
    }
});
