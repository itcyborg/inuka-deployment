<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $pdf = PDF::loadView('layouts.pdf');
    return $pdf->stream();
//    return $pdf->download('payslip.pdf');
//    return view('layouts.pdf');
});

Route::get('/test', function () {
    $data = \App\Payslip::first();

    $unserializedData = (object)[
        "id" => $data->id,
        "staff" => $data->staff,
        "role" => $data->role,
        "role_details" => unserialize($data->role_details),
        "month" => $data->month,
        "year" => $data->year,
        "tax_type" => $data->tax_type,
        "retainer" => $data->retainer,
        "commissions" => unserialize($data->commissions),
        "total_commissions" => $data->total_commissions,
        "bonuses" => unserialize($data->bonuses),
        "total_bonuses" => $data->total_bonuses,
        "other" => $data->other,
        "total_other" => $data->total_other,
        "total_earned" => $data->total_earned,
        "paye" => $data->paye,
        "nssf" => $data->nssf,
        "nhif" => $data->nhif,
        "helb" => $data->helb,
        "lateness" => $data->lateness,
        "welfare" => $data->welfare,
        "sacco" => $data->sacco,
        "sacco_loan" => $data->sacco_loan,
        "advance" => $data->advance,
        "sacco_registration" => $data->sacco_registration,
        "pledges" => $data->pledges,
        "sacco_saving_addon" => $data->sacco_saving_addon,
        "liability" => $data->liability,
        "other_deduction" => $data->other_deduction,
        "staff_loan" => $data->staff_loan,
        "withholding_tax" => $data->withholding_tax,
        "net_pay" => $data->net_pay,
        "deductions" => unserialize($data->deductions),
        "total_deductions" => $data->total_deductions,
        "total_paid" => $data->total_paid,
        "gratuity" => $data->gratuity,
        "gratuity_posted" => $data->gratuity_posted,
        "gratuity_error" => $data->gratuity_error,
        "recalc" => $data->recalc,
        'gross_pay'=>array_sum([$data->retainer,$data->total_bonuses,$data->total_other,$data->total_commissions]),
        'all_deductions'=>array_sum([$data->total_deductions,$data->paye,$data->nssf,$data->nhif,$data->helb,$data->lateness,$data->sacco,$data->pledges,$data->advance,$data->total_deductions])
    ];
//    dd((object) $unserializedData);
    $branch = \App\Branch::find($data->staffRole()->first()->office);
    $bank = $data->staff()->first()->bank()->first();
    if ($branch->parent_id) {
        $region = \App\Branch::find($branch->parent_id);
    } else {
        $region = (object)['name' => 'Nairobi Region'];
    }
    $pdf = PDF::loadView('LO', ['data' => $unserializedData, 'staff' => $data->staff()->first(), 'role' => $data->role()->first(), 'branch' => $branch, 'region' => $region, 'bank' => $bank]);
    return $pdf->stream();
});
