<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payslip</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body{
            font-size: 0.65em;
        }
    </style>
</head>
<body class="p-0 m-0" style="page-break-inside: avoid;">
<div class="container-fluid p-0 m-0 w-100">
    <!-- Logo -->
    <div>
        <img src="https://inukaafrica.com/wp-content/themes/inuka/library/img/logo.png" alt="Logo" class="img-fluid" style="width: 150px;">
    </div>

    <h6 class="text-center">Pay Statement</h6>
    <!-- Staff details -->
    <div class="pl-2 p-0 m-0">
        <table class="table table-borderless w-100 table-sm p-0 m-0">
            <tbody>
            <tr>
                <td class="w-25">Staff Name</td>
                <td class="w-75"><?php echo e(Str::upper($staff->name)); ?></td>
            </tr>
            <tr>
                <td>Staff ID</td>
                <td><?php echo e($staff->id); ?></td>
            </tr>
            <tr>
                <td>Payroll Month</td>
                <td><?php echo e(\Carbon\Carbon::createFromFormat('m',$data->month)->monthName); ?></td>
            </tr>
            <tr>
                <td>Designation</td>
                <td><?php echo e($role->title); ?></td>
            </tr>
            <tr>
                <td>Duty Station</td>
                <td><?php echo e($branch->name); ?></td>
            </tr>
            <tr>
                <td>Phone Number</td>
                <td><?php echo e($staff->telephone); ?></td>
            </tr>
            <tr>
                <td>Status</td>
                <td><?php echo e($staff->status); ?></td>
            </tr>
            <tr>
                <td>Taxation Type</td>
                <td><?php echo e($data->tax_type); ?></td>
            </tr>
            <tr>
                <td>Payment Mode</td>
                <td><?php echo e($staff->pay_mode); ?></td>
            </tr>
            </tbody>
        </table>
    </div>

    <!-- Earnings -->
    <table class="table table-sm w-100 table-striped table-bordered table-fit">
        <thead class="w-100">
        <tr>
            <th class="w-100 bg-secondary" colspan="2">Earning Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class="w-50">Basic Pay</td>
            <td class="w-50">KES. <?php echo e(number_format($data->retainer)); ?></td>
        </tr>
        <tr>
            <td>Other Earnings</td>
            <td>KES. <?php echo e(number_format($data->total_other)); ?></td>
        </tr>
        <tr>
            <td>Gratuity Payment</td>
            <td><?php echo e($data->gratuity); ?></td>
        </tr>
        <tr>
            <td>Gross_Pay</td>
            <td><?php echo e($data->total_earned); ?></td>
        </tr>
        <tr>
            <td>Taxable_Pay</td>
            <td><?php echo e($data->total_paid); ?></td>
        </tr>
        </tbody>
    </table>

    <!-- Deductions -->
    <table class="table table-sm w-100 table-striped table-bordered">
        <thead class="w-100">
        <tr>
            <th class="w-100 bg-secondary" colspan="3">Deductions Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td rowspan="4" class="w-50">Statutory Deductions</td>
            <td class="w-25">Taxation</td>
            <td class="w-25"><?php echo e($data->paye); ?></td>
        </tr>
        <tr>
            <td>NHIF</td>
            <td><?php echo e($data->nhif); ?></td>
        </tr>
        <tr>
            <td>NSSF</td>
            <td><?php echo e($data->nssf); ?></td>
        </tr>
        <tr>
            <td>HELB</td>
            <td><?php echo e($data->helb); ?></td>
        </tr>
        <tr>
            <td rowspan="4">Other Deductions</td>
            <td>Sacco</td>
            <td><?php echo e($data->sacco); ?></td>
        </tr>
        <tr>
            <td>Advance</td>
            <td><?php echo e($data->sacco_loan); ?></td>
        </tr>
        <tr>
            <td>Welfare</td>
            <td><?php echo e($data->welfare); ?></td>
        </tr>
        <tr>
            <td>Others</td>
            <td><?php echo e($data->other_deductions); ?></td>
        </tr>
        <tr>
            <td colspan="2">Total Deduction</td>
            <td><?php echo e($data->total_deductions); ?></td>
        </tr>
        </tbody>
    </table>

    <table class="table table-sm w-100 p-0 m-0">
        <tbody>
        <tr>
            <td><b>Net Pay (Kshs):</b></td>
            <td><?php echo e($data->net_pay); ?></td>
        </tr>
        </tbody>
    </table>

    <table class="table table-sm w-100 table-borderless border-top">
        <tbody>
        <tr>
            <td colspan="3" class="text-center font-italic">
                Friends Church Office Complex, Ngong Road P.O BOX 24001-00100, Nairobi Kenya
                <br>
                Tel. 0703 395300, 0705 860150, 0732 591803. Email: info@inukaafrica.com <br>www.inukaafrica.com
            </td>
        </tr>
        <tr>
            <td class="font-italic" style="font-size: 0.8em;"><?php echo e(\Carbon\Carbon::now()->toDateTimeString()); ?></td>
            <td></td>
            <td></td>
        </tr>
        </tbody>
    </table>
</div>
</body>
</html><?php /**PATH I:\PROJECTS\WORK\inuka\payroll\resources\views/HQ.blade.php ENDPATH**/ ?>