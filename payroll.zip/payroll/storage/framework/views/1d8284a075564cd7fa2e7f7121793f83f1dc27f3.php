<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payslip</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body{
            font-size: 0.65em;
        }
    </style>
</head>
<body class="p-0 m-0" style="page-break-inside: avoid;">
    <div class="container-fluid p-0 m-0 w-100">
        <!-- Logo -->
        <div class="text-center">
            <img src="https://inukaafrica.com/wp-content/themes/inuka/library/img/logo.png" alt="Logo" class="img-fluid" style="width: 150px;">
        </div>

        <h6 class="text-center">Branch Admin Pay and Performance Statement</h6>
        <!-- Staff details -->
        <div class="pl-2 p-0 m-0">
            <table class="table table-borderless w-100 table-sm p-0 m-0">
                <tbody>
                <tr>
                    <td class="w-25">Name</td>
                    <td class="w-75"><?php echo e(Str::upper($staff->name)); ?></td>
                </tr>
                <tr>
                    <td>Inuka_ID</td>
                    <td><?php echo e($staff->id); ?></td>
                </tr>
                <tr>
                    <td>Statement Month</td>
                    <td><?php echo e(\Carbon\Carbon::createFromFormat('m',$data->month)->monthName); ?></td>
                </tr>
                <tr>
                    <td>Designation</td>
                    <td><?php echo e($role->title); ?></td>
                </tr>
                <tr>
                    <td>Branch_Name</td>
                    <td><?php echo e($branch->name); ?></td>
                </tr>
                <tr>
                    <td>Region_Name</td>
                    <td><?php echo e($region->name); ?></td>
                </tr>
                <tr>
                    <td>Phone_Number</td>
                    <td><?php echo e($staff->telephone); ?></td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td><?php echo e($staff->status); ?></td>
                </tr>
                <tr>
                    <td>Taxation_Type</td>
                    <td><?php echo e($data->tax_type); ?></td>
                </tr>
                <tr>
                    <td>Payment_Mode</td>
                    <td><?php echo e($staff->pay_mode); ?></td>
                </tr>
                </tbody>
            </table>
        </div>

        <?php if(isset($performance)): ?>
        <!-- Admin Performance Heads -->
        <table class="table table-sm w-100 table-striped table-bordered table-left">
            <thead>
            <tr>
                <th colspan="2" class="text-center bg-secondary">
                    Admin Performance Heads
                </th>
            </tr>
            </thead>
            <tbody>
                <?php if(isset($performance->loan_totals)): ?>
                    <tr>
                        <td>New_Loans_Totals:</td>
                        <td><?php echo e($performance->loan_totals); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if(isset($performance->revival_loan_totals)): ?>
                    <tr>
                        <td>Revival_Loans_Totals</td>
                        <td><?php echo e($performance->revival_loan_totals); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if(isset($performance->total_loans_disbursed)): ?>
                    <tr>
                        <td>Total_loans_Disbursed</td>
                        <td><?php echo e($performance->total_loans_disbursed); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if(isset($performance->achievement_on_target)): ?>
                    <tr>
                        <td>% Achievement on Target</td>
                        <td><?php echo e($performance->achievement_on_target); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if(isset($performance->performance_verdict)): ?>
                    <tr>
                        <td>Performance_Verdict</td>
                        <td><?php echo e($performance->performance_verdict); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php endif; ?>
        <!-- Earnings -->
        <table class="table table-sm w-100 table-striped table-bordered table-fit">
                <thead class="w-100">
                <tr>
                    <th class="w-100 bg-secondary text-center" colspan="2">Earning Heads</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="w-50">Basic Pay</td>
                        <td class="w-50">KES. <?php echo e(number_format($data->retainer)); ?></td>
                    </tr>
                    <?php if(isset($data->commissions->loan_disbursal)): ?>
                    <tr>
                        <td>Loan Disbursement Commission</td>
                        <td>KES. <?php echo e(number_format($data->commissions->loan_disbursal)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->commissions->par_management)): ?>
                    <tr>
                        <td>PAR Commission</td>
                        <td>KES. <?php echo e(number_format($data->commissions->par_management)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->bonuses->penalty)): ?>
                    <tr>
                        <td>Penalty Bonus</td>
                        <td>KES. <?php echo e(number_format($data->bonuses->penalty)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->bonuses->loan_dis_bonus)): ?>
                    <tr>
                        <td>Loan Dis Bonus</td>
                        <td>KES. <?php echo e(number_format($data->bonuses->loan_dis_bonus)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->bonuses->par_management)): ?>
                    <tr>
                        <td>PAR Management Bonus</td>
                        <td>KES. <?php echo e(number_format($data->bonuses->par_management)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->total_other)): ?>
                    <tr>
                        <td>Other Earnings</td>
                        <td>KES. <?php echo e(number_format($data->total_other)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->gratuity)): ?>
                    <tr>
                        <td>Gratuity Payment</td>
                        <td><?php echo e($data->gratuity); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->total_earned)): ?>
                    <tr>
                        <td>Total Earnings</td>
                        <td><?php echo e($data->total_earned); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($data->total_paid)): ?>
                    <tr>
                        <td>Taxable Earnings</td>
                        <td><?php echo e($data->total_paid); ?></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
        </table>

        <!-- Deductions -->
        <table class="table table-sm w-100 table-striped table-bordered">
                <thead class="w-100">
                <tr>
                    <th class="w-100 bg-secondary text-center" colspan="3">Deductions Heads</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td rowspan="4" class="w-50">Statutory Deductions</td>
                    <td class="w-25">PAYE</td>
                    <td class="w-25"><?php echo e($data->paye); ?></td>
                </tr>
                <?php if(isset($data->nhif)): ?>
                <tr>
                    <td>NHIF</td>
                    <td><?php echo e($data->nhif); ?></td>
                </tr>
                <?php endif; ?>
                <?php if(isset($data->nssf)): ?>
                <tr>
                    <td>NSSF</td>
                    <td><?php echo e($data->nssf); ?></td>
                </tr>
                <?php endif; ?>
                <?php if(isset($data->helb)): ?>
                <tr>
                    <td>HELB</td>
                    <td><?php echo e($data->helb); ?></td>
                </tr>
                <?php endif; ?>
                <?php if(isset($data->sacco)): ?>
                <tr>
                    <td rowspan="4">Other Deductions</td>
                    <td>Sacco</td>
                    <td><?php echo e($data->sacco); ?></td>
                </tr>
                <?php endif; ?>
                <?php if(isset($data->sacco_loan)): ?>
                <tr>
                    <td>Advance</td>
                    <td><?php echo e($data->sacco_loan); ?></td>
                </tr>
                <?php endif; ?>
                <?php if(isset($data->welfare)): ?>
                <tr>
                    <td>Welfare</td>
                    <td><?php echo e($data->welfare); ?></td>
                </tr>
                <?php endif; ?>
                <?php if(isset($data->other_deductions)): ?>
                <tr>
                    <td>Others</td>
                    <td><?php echo e($data->other_deductions); ?></td>
                </tr>
                <?php endif; ?>
                <?php if(isset($data->total_deductions)): ?>
                <tr>
                    <td colspan="2">Total Deductions</td>
                    <td><?php echo e($data->total_deductions); ?></td>
                </tr>
                <?php endif; ?>
                </tbody>
        </table>

        <table class="table table-sm w-100 p-0 m-0">
            <tbody>
            <tr>
                <td><b>Net Pay (Kshs)</b></td>
                <td><?php echo e($data->net_pay); ?></td>
            </tr>
            </tbody>
        </table>

        <table class="table table-sm w-100 table-borderless border-top">
            <tbody>
                <tr>
                    <td colspan="3" class="text-center font-italic">
                        Friends Church Office Complex, Ngong Road P.O BOX 24001-00100, Nairobi Kenya
                        <br>
                        Tel. 0703 395300, 0705 860150, 0732 591803. Email: info@inukaafrica.com <br>www.inukaafrica.com
                    </td>
                </tr>
                <tr>
                   <td class="font-italic" style="font-size: 0.8em;"><?php echo e(\Carbon\Carbon::now()->toDateTimeString()); ?></td>
                   <td></td>
                   <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH I:\PROJECTS\WORK\inuka\payroll\resources\views/admin.blade.php ENDPATH**/ ?>