[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH I:\PROJECTS\WORK\inuka\payroll\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>