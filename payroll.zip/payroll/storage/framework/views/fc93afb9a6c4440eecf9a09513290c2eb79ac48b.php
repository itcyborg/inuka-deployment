<?php $__env->startComponent('mail::message'); ?>
    # Payslip Generated

    Your has been generated!

    Thanks,
    <?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH I:\PROJECTS\WORK\inuka\payroll\resources\views/mail_template.blade.php ENDPATH**/ ?>