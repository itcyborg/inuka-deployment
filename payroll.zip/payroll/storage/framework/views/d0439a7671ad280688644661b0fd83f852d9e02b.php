<?php echo e($slot); ?>

<?php /**PATH I:\PROJECTS\WORK\inuka\payroll\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>