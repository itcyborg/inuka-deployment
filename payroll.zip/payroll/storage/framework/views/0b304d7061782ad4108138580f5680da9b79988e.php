<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payslip</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            font-size: 0.65em;
        }

        .bg-yellow{
            background-color: rgba(241, 241, 52, 0.79);
        }

        .text-head-blue {
            font-weight: bold;
            color: blue !important;
        }

        .text-blue {
            color: blue !important;
        }

        .underline {
            font-weight: bolder;
            text-decoration: underline !important;
            text-decoration-style: solid !important;
        }

        .bg-aqua {
            background-color: aqua !important;
        }

        .bg-yellow-brow {
            background-color: #FFF4CE !important;
        }

        .text-yellow-brown {
            color: #836708 !important;
        }

        .text-brown {
            color: saddlebrown !important;
        }

        .text-red-brown {
            color: #bd3914 !important;
        }

        .text-green {
            color: darkgreen !important;
        }

        .bold {
            font-weight: bold !important;
        }

        .td-border-red {
            border: 1px solid #c51a1a !important;
        }

        .td-border-top-red {
            border-top: 1px solid #c51a1a !important;
        }

        .td-border-bottom-red {
            border-bottom: 1px solid #c51a1a !important;
        }

        footer {
            position: fixed;
            bottom: 0cm;
            left: 0cm;
            right: 0cm;
            height: 1.5cm;

            /** Extra personal styles **/
            text-align: center;
            line-height: 0.5cm;
        }
    </style>
</head>
<body class="p-0 m-0" style="page-break-inside: auto;">
<div class="container-fluid p-0 m-0 w-100">
    <!-- Logo -->
    <div class="text-center">
        <img src="https://inukaafrica.com/wp-content/themes/inuka/library/img/logo.png" alt="Logo" class="img-fluid" style="width: 150px;">
    </div>

    <h6 class="text-center text-decoration-underline p-1" style="text-decoration: underline;text-underline-offset: 3px;">Regional Manager Pay and Performance Statement</h6>

    <!-- Staff details -->
    <div class="row w-100 pb-3">
        <div class="col-4 w-100"></div>
        <div class="col-8" style="margin-left:150px;">
            <div class="pl-2 p-0 m-0">
                <table class="table table-borderless w-100 table-sm p-0 m-0">
                    <tbody>
                    <tr>
                        <td class="col-2 text-head-blue">Name</td>
                        <td class="col-8 text-left">: &nbsp;&nbsp;&nbsp;<?php echo e(Str::upper($staff->name)); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Inuka ID</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e($staff->id); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Statement Month</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e(\Carbon\Carbon::createFromFormat('m',$data->month)->monthName.'_'.$data->year); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Designation</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e($role->title); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Region Name</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e($region->name); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Phone Number</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e($staff->telephone); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Status</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e($staff->status); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Taxation Type</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e($data->tax_type); ?></td>
                    </tr>
                    <tr>
                        <td class="col-2 text-head-blue">Payment Mode</td>
                        <td>: &nbsp;&nbsp;&nbsp;<?php echo e($staff->pay_mode); ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!--Performance Heads-->
    <table class="table table-sm w-100 table-bordered td-border-top-red" style="margin-right:5em;margin-left:5em;">
        <thead>
        <tr>
            <th colspan="2"
                class="text-center bg-aqua text-head-blue text-center">Branch Performance Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr class="m-0 p-0">
            <td>
                <table class="w-100 table">
                    <tr>
                        <td class="text-brown">New_Loans:</td>
                        <td class="text-blue"><?php echo e($performance->new_loans); ?></td>
                    </tr>
                    <tr>
                        <td class="text-brown">Repeat_Loans</td>
                        <td class="text-blue"><?php echo e($performance->repeat_loans); ?></td>
                    </tr>
                    <tr>
                        <td class="text-brown bold bg-yellow-brow">Total_Loans</td>
                        <td class="text-red-brown bold bg-yellow-brow"><?php echo e($performance->total_loans); ?></td>
                    </tr>
                    <tr>
                        <td class="text-brown">Closing_PAR(Ksh)</td>
                        <td class="text-blue">Kshs. <?php echo e(number_format($performance->closing_par,2)); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="bg-yellow">% Achievement on Cut-Off Target</td>
                    </tr>
                    <tr>
                        <td colspan="2" class="bg-yellow">% Achievement on Total Target</td>
                    </tr>
                </table>
            </td>
            <td>
                <table class="w-100 table">
                    <tr>
                        <td class="text-brown">New_Loans_Totals:</td>
                        <td class="text-blue">Kshs. <?php echo e(number_format($performance->new_loan_totals,2)); ?></td>
                    </tr>
                    <tr>
                        <td class="text-brown">Repeat_Loans_Totals</td>
                        <td class="text-blue">Kshs. <?php echo e(number_format($performance->repeat_loans_totals,2)); ?></td>
                    </tr>
                    <tr>
                        <td class="text-brown bold">Total_Disbursed</td>
                        <td class="text-red-brown bold">Kshs. <?php echo e(number_format($performance->total_disbursed,2)); ?></td>
                    </tr>
                    <tr>
                        <td class="text-brown bold">Closing_PAR(%) </td>
                        <td class="text-red-brown bold"><?php echo e($performance->closing_par_percentage); ?></td>
                    </tr>
                    <tr>
                        <td class="bg-yellow"><?php echo e($performance->achievement_on_cut_off_target); ?></td>
                        <td rowspan="2" class="text-blue"><?php echo e($performance->performance_verdict); ?></td>
                    </tr>
                    <tr>
                        <td class="bg-yellow"><?php echo e($performance->achievement_on_target); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
        </tbody>
    </table>

    <!-- Earnings -->
    <table class="table table-sm w-100 table-bordered td-border-top-red" style="margin-right:5em;margin-left:5em;">
        <thead class="w-100">
        <tr>
            <th class="w-100 bg-aqua text-center text-blue" colspan="2">Earning Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class="w-50 text-blue">Basic Pay</td>
            <td class="w-50 text-brown">Kshs. <?php echo e(number_format($data->retainer,2)); ?></td>
        </tr>
        <tr>
            <td class="text-blue">Loan Dis Commission</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->commissions->loan_disbursal,2)); ?></td>
        </tr>
        <tr>
            <td class="text-blue">PAR Commission</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->commissions->par_management,2)); ?></td>
        </tr>
        <tr>
            <td class="text-blue">Penalty Bonus</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->bonuses->penalty,2)); ?></td>
        </tr>
        <tr>
            <td class="text-blue">Loan Dis Bonus</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->bonuses->loan_dis_bonus,2)); ?></td>
        </tr>
        <tr>
            <td class="text-blue">PAR Mngt Bonus</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->bonuses->par_management,2)); ?></td>
        </tr>
        <tr>
            <td class="text-blue">Other Earnings</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->total_other,2)); ?></td>
        </tr>
        <tr>
            <td class="text-blue" style="border-bottom:1px solid #c51a1a !important;">Gratuity Payment</td>
            <td class="text-brown" style="border-bottom:1px solid #c51a1a !important;"><?php echo e($data->gratuity); ?></td>
        </tr>
        <tr>
            <td class="text-red-brown bg-yellow-brow bold td-border-red">Total Earnings</td>
            <td class="text-red-brown bg-yellow-brow bold td-border-red"><?php echo e($data->total_earned); ?></td>
        </tr>
        <tr>
            <td class="text-red-brown bg-yellow-brow bold td-border-red">Taxable Pay</td>
            <td class="text-red-brown bg-yellow-brow bold td-border-red"><?php echo e($data->total_paid); ?></td>
        </tr>
        </tbody>
    </table>

    <!-- Deductions -->
    <table class="table table-sm w-100 table-bordered td-border-top-red" style="margin-right:5em;margin-left:5em;">
        <thead class="w-100">
        <tr>
            <th class="w-100 bg-aqua text-center text-head-blue" colspan="3">Deductions Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td rowspan="4" class="w-50 bg-yellow-brow text-brown bold">Statutory Deductions</td>
            <td class="w-25 text-brown">PAYE</td>
            <td class="w-25 text-blue">Kshs. <?php echo e(number_format($data->paye,2)); ?></td>
        </tr>
        <tr>
            <td class="text-brown">NHIF</td>
            <td class="text-blue">Kshs. <?php echo e(number_format($data->nhif,2)); ?></td>
        </tr>
        <tr>
            <td class="text-brown">NSSF</td>
            <td class="text-blue">Kshs. <?php echo e(number_format($data->nssf,2)); ?></td>
        </tr>
        <tr>
            <td class="text-brown">HELB</td>
            <td class="text-blue">Kshs. <?php echo e(number_format($data->helb,2)); ?></td>
        </tr>
        <tr>
            <td rowspan="4" class="bg-yellow-brow text-brown">Other Deductions</td>
            <td class="text-green">Sacco</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->sacco,2)); ?></td>
        </tr>
        <tr>
            <td class="text-green">Loans/ Advance</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->sacco_loan,2)); ?></td>
        </tr>
        <tr>
            <td class="text-green">Welfare</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->welfare,2)); ?></td>
        </tr>
        <tr>
            <td class="text-green">Others</td>
            <td class="text-brown">Kshs. <?php echo e(number_format($data->other_deductions,2)); ?></td>
        </tr>
        <tr>
            <td colspan="2" class="text-red-brown bg-yellow-brow">Total Deduction</td>
            <td class="text-red-brown bg-yellow-brow">Kshs. <?php echo e(number_format($data->total_deductions,2)); ?></td>
        </tr>
        </tbody>
    </table>

    <table class="table table-sm w-100 table-bordered td-border-top-red" style="margin-right:5em;margin-left:5em;">
        <tbody>
        <tr>
            <td class="bg-yellow-brow text-blue td-border-red"><b>Net Pay (Kshs):</b></td>
            <td class="bg-yellow-brow text-red-brown bold td-border-red">Kshs <?php echo e(number_format($data->net_pay,2)); ?></td>
        </tr>
        </tbody>
    </table>

    <footer>
        <table class="table table-sm w-100 table-borderless border-top">
            <tbody>
            <tr>
                <td colspan="3" class="text-center text-yellow-brown font-italic">
                    Kindaruma Business Centre, Kindaruma Road P.O BOX 24001-00100, Nairobi Kenya
                    <br>
                    Tel. 0703 395300, 0705 860150, 0732 591803. Email: Info@inukaafrica.com
                    <br>
                    www.inukaafrica.com
                </td>
            </tr>
            <tr>
                <td class="font-italic text-yellow-brown" style="font-size: 0.8em;"><?php echo e(\Carbon\Carbon::now()->toDateTimeString()); ?></td>
                <td></td>
                <td></td>
            </tr>
            </tbody>
        </table>
    </footer>
</div>
</body>
</html>
<?php /**PATH I:\PROJECTS\WORK\inuka\payroll\resources\views/RM.blade.php ENDPATH**/ ?>