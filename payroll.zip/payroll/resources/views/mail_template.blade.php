@component('mail::message')
    # Payslip Generated

    Your has been generated!

    Thanks,
    {{ config('app.name') }}
@endcomponent