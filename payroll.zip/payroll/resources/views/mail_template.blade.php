@component('mail::message')
    # Payslip Generated

    Your payslip has been generated!

    Thanks,
    {{ config('app.name') }}
@endcomponent
