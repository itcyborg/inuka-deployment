<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payslip</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            font-size: 0.65em;
        }
    </style>
</head>
<body class="p-0 m-0" style="page-break-inside: avoid;">
<div class="container-fluid p-0 m-0 w-100">
    <!-- Logo -->
    <div>
        <img src="https://inukaafrica.com/wp-content/themes/inuka/library/img/logo.png" alt="Logo" class="img-fluid"
             style="width: 150px;">
    </div>

    <h6 class="text-center">Branch Supervisor Pay and Performance Statement</h6>
    <!-- Staff details -->
    <div class="pl-2 p-0 m-0">
        <table class="table table-borderless w-100 table-sm p-0 m-0">
            <tbody>
            <tr>
                <td class="w-25">Staff Name</td>
                <td class="w-75">{{Str::upper($staff->name)}}</td>
            </tr>
            <tr>
                <td>Staff ID</td>
                <td>{{$staff->id}}</td>
            </tr>
            <tr>
                <td>Statement Month</td>
                <td>{{\Carbon\Carbon::createFromFormat('m',$data->month)->monthName}}</td>
            </tr>
            <tr>
                <td>Designation</td>
                <td>{{$role->title}}</td>
            </tr>
            <tr>
                <td>Branch Name</td>
                <td>{{$branch->name}}</td>
            </tr>
            <tr>
                <td>Region Name</td>
                <td>{{$region->name}}</td>
            </tr>
            <tr>
                <td>Phone Number</td>
                <td>{{$staff->telephone}}</td>
            </tr>
            <tr>
                <td>Status</td>
                <td>{{$staff->status}}</td>
            </tr>
            <tr>
                <td>Taxation Type</td>
                <td>{{$data->tax_type}}</td>
            </tr>
            <tr>
                <td>Payment Mode</td>
                <td>{{$staff->pay_mode}}</td>
            </tr>
            </tbody>
        </table>
    </div>


    <!-- Admin Performance Heads -->
    <table class="table table-sm w-100 table-striped table-bordered table-left">
        <thead>
        <tr>
            <th colspan="2"
                class="text-center bg-secondary">Branch Performance Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr class="m-0 p-0">
            <td>
                <table class="w-100 table">
                    <tr>
                        <td>New_Loans:</td>
                        <td>{{$performance->new_loans}}</td>
                    </tr>
                    <tr>
                        <td>Repeat_Loans</td>
                        <td>{{$performance->repeat_loans}}</td>
                    </tr>
                    <tr>
                        <td>Total_Loans</td>
                        <td>{{$performance->total_loans}}</td>
                    </tr>
                    <tr>
                        <td>Closing_PAR(Ksh)</td>
                        <td>{{$performance->closing_par}}</td>
                    </tr>
                    <tr>
                        <td colspan="2">% Achievement_on_Disbursement_Target</td>
                    </tr>
                    <tr>
                        <td colspan="2">Performance Verdict</td>
                    </tr>
                </table>
            </td>
            <td>
                <table class="w-100 table">
                    <tr>
                        <td>New_Loans_Totals:</td>
                        <td>{{$performance->new_loan_totals}}</td>
                    </tr>
                    <tr>
                        <td>Repeat_Loans_Totals</td>
                        <td>{{$performance->repeat_loans_totals}}</td>
                    </tr>
                    <tr>
                        <td>Total_Disbursed</td>
                        <td>{{$performance->total_disbursed}}</td>
                    </tr>
                    <tr>
                        <td>Closing_PAR(%) </td>
                        <td>{{$performance->closing_par_percentage}}</td>
                    </tr>
                    <tr>
                        <td colspan="2">{{$performance->achievement_on_target}}</td>
                    </tr>
                    <tr>
                        <td colspan="2">{{$performance->performance_verdict}}</td>
                    </tr>
                </table>
            </td>
        </tr>
        </tbody>
    </table>

    <!-- Earnings -->
    <table class="table table-sm w-100 table-striped table-bordered table-fit">
        <thead class="w-100">
        <tr>
            <th class="w-100 bg-secondary" colspan="2">Earning Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class="w-50">Basic Pay</td>
            <td class="w-50">KES. {{number_format($data->retainer)}}</td>
        </tr>
        <tr>
            <td>Loan Disbursement Commission</td>
            <td>KES. {{number_format($data->commissions->loan_disbursal)}}</td>
        </tr>
        <tr>
            <td>PAR Commission</td>
            <td>KES. {{number_format($data->commissions->par_management)}}</td>
        </tr>
        <tr>
            <td>Penalty Bonus</td>
            <td>KES. {{number_format($data->bonuses->penalty)}}</td>
        </tr>
        <tr>
            <td>Loan Dis Bonus</td>
            <td>KES. {{number_format($data->bonuses->loan_dis_bonus)}}</td>
        </tr>
        <tr>
            <td>PAR Management Bonus</td>
            <td>KES. {{number_format($data->bonuses->par_management)}}</td>
        </tr>
        <tr>
            <td>Other Earnings</td>
            <td>KES. {{number_format($data->total_other)}}</td>
        </tr>
        <tr>
            <td>Gratuity Payment</td>
            <td>{{$data->gratuity}}</td>
        </tr>
        <tr>
            <td>Total_Earnings</td>
            <td>{{$data->total_earned}}</td>
        </tr>
        <tr>
            <td>Taxable_Earnings</td>
            <td>{{$data->total_paid}}</td>
        </tr>
        </tbody>
    </table>

    <!-- Deductions -->
    <table class="table table-sm w-100 table-striped table-bordered">
        <thead class="w-100">
        <tr>
            <th class="w-100 bg-secondary" colspan="3">Deductions Heads</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td rowspan="4" class="w-50">Statutory Deductions</td>
            <td class="w-25">Taxation</td>
            <td class="w-25">{{$data->paye}}</td>
        </tr>
        <tr>
            <td>NHIF</td>
            <td>{{$data->nhif}}</td>
        </tr>
        <tr>
            <td>NSSF</td>
            <td>{{$data->nssf}}</td>
        </tr>
        <tr>
            <td>HELB</td>
            <td>{{$data->helb}}</td>
        </tr>
        <tr>
            <td rowspan="4">Other Deductions</td>
            <td>Sacco</td>
            <td>{{$data->sacco}}</td>
        </tr>
        <tr>
            <td>Advance</td>
            <td>{{$data->sacco_loan}}</td>
        </tr>
        <tr>
            <td>Welfare</td>
            <td>{{$data->welfare}}</td>
        </tr>
        <tr>
            <td>Others</td>
            <td>{{$data->other_deductions}}</td>
        </tr>
        <tr>
            <td colspan="2">Total Deduction</td>
            <td>{{$data->total_deductions}}</td>
        </tr>
        </tbody>
    </table>

    <table class="table table-sm w-100 p-0 m-0">
        <tbody>
        <tr>
            <td><b>Net Pay (Kshs):</b></td>
            <td>{{$data->net_pay}}</td>
        </tr>
        </tbody>
    </table>

    <table class="table table-sm w-100 table-borderless border-top">
        <tbody>
        <tr>
            <td colspan="3" class="text-center font-italic">
                Friends Church Office Complex, Ngong Road P.O BOX 24001-00100, Nairobi Kenya
                <br>
                Tel. 0703 395300, 0705 860150, 0732 591803. Email: info@inukaafrica.com <br>www.inukaafrica.com
            </td>
        </tr>
        <tr>
            <td class="font-italic" style="font-size: 0.8em;">{{\Carbon\Carbon::now()->toDateTimeString()}}</td>
            <td></td>
            <td></td>
        </tr>
        </tbody>
    </table>
</div>
</body>
</html>