<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePayslipV1STable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payslip_v1_s', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('staff_id');
            $table->unsignedInteger('year');
            $table->unsignedInteger('month');
            $table->string('branch')->nullable();
            $table->string('region')->nullable();
            $table->string('tax_type')->nullable();
            $table->json('earnings')->nullable();
            $table->double('total_earnings')->default(0);
            $table->double('taxable_earnings')->default(0);
            $table->json('deductions')->nullable();
            $table->json('performance_heads')->nullable();
            $table->string('performance_head_title')->nullable();
            $table->double('total_deductions')->default(0);
            $table->double('net_pay')->default(0);
            $table->enum('notify',[0,1])->default(0);
            $table->date('schedule_notify')->nullable();
            $table->string('template');
            $table->double('role_security')->nullable();
            $table->enum('status',['pending','processed','failed'])->default('pending');
            $table->json('errors')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payslip_v1_s');
    }
}
