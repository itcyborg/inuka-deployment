<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slip extends Model
{
    protected $table='hrm_staff_slips';

}
