<?php

namespace App\Http\Requests;

use Illuminate\Http\Request;

/**
 * Class BaseRequest
 *
 * @package App\Http\Requests
 * @author  isaac
 */
class BaseRequest extends Request
{
    /**
     * @return bool
     * @author isaac
     */
    public function expectsJson(): bool
    {
        return true;
    }

    /**
     * @return bool
     * @author isaac
     */
    public function wantsJson(): bool
    {
        return true;
    }

    public function acceptsJson(): bool
    {
        return true;
    }

    public function isJson()
    {
        return true;
    }
}