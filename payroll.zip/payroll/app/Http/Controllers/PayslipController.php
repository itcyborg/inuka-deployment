<?php

namespace App\Http\Controllers;

use App\PayslipV1;
use Illuminate\Http\Request;

class PayslipController extends Controller
{
    public function process(Request $request)
    {
        $request->validate([
            'staff_id'=>'required',
            'year'=>'required|numeric',
            'month'=>'required|numeric',
            'template'=>'required',
            'earnings'=>'required',
            'deductions'=>'required',
            'net_pay'=>'required',
        ]);

        return PayslipV1::create([
            'staff_id'=>$request->staff_id,
            'year'=>$request->year,
            'month'=>$request->month,
            'template'=>$request->template,
            'earnings'=>$request->earnings,
            'deductions'=>$request->deductions,
            'net_pay'=>$request->net_pay,
            'schedule_notify'=>$request->schedule_notify,
            'notify'=>(string) $request->notify,
            'performance_heads'=>$request->heads,
            'total_deductions'=>$request->total_deductions,
            'total_earnings'=>$request->total_earnings,
            'performance_head_title'=>$request->heads_title,
            'role_security'=>$request->role_security
        ]);
    }

    public function index(Request $request)
    {
        $per_page=20;
        $query=PayslipV1::query();
        if($request->has('ids')){
            $query->whereIn('id',explode(',',$request->ids));
        }
        if($request->has('staff_id')){
            $query->where('staff_id',$request->staff_id);
        }
        if($request->has('year')){
            $query->where('year','=',$request->year);
        }
        if($request->has('month')){
            $query->where('month','=',$request->month);
        }
        if($request->has('template')){
            $query->where('template','=',$request->template);
        }
        if($request->has('status')){
            $query->where('status','=',$request->status);
        }
        if($request->has('per_page')){
            $per_page=$request->per_page;
        }
        return $query->paginate($per_page)->toJson();
    }
}
