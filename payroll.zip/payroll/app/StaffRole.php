<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaffRole extends Model
{

    protected $table='hrm_staff_roles';

    //
}
