<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaffDeduction extends Model
{
    protected $table='hrm_staff_deductions';

    protected $fillable=[
        'staff_id',
        'type',
        'description',
        'amount',
        'start_month',
        'stop_month',
        'start_year',
        'stop_month'
    ];
}
