<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use \Znck\Eloquent\Traits\BelongsToThrough;

    protected $table='hrm_staff';

    // get the role relation of staff

    public function staffRole()
    {
        return $this->hasOne(StaffRole::class,'id','staff');
    }

    public function bank()
    {
        return $this->belongsTo(Bank::class,'bank');
    }
}
