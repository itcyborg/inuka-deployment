<?php

namespace App;

use App\Jobs\SendPayslip;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PayslipV1 extends Model
{
    use HasFactory,SoftDeletes;

    protected $guarded=[];

    protected $casts=[
        'earnings'=>'object',
        'deductions'=>'object',
        'performance_heads'=>'object',
    ];

    protected static function boot()
    {
        parent::boot();
        self::created(function($model){
            SendPayslip::dispatch($model);
        });
    }
}
