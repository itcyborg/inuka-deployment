<?php

namespace App\Jobs;

use App\Branch;
use App\Mail\PayslipMail;
use App\Role;
use App\Staff;
use App\StaffRole;
use Barryvdh\DomPDF\Facade;
use Barryvdh\DomPDF\PDF;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use function PHPUnit\Framework\objectEquals;

class SendPayslip implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $payslip;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($payslip)
    {
        $this->payslip=$payslip;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $staff=null;
        $branch=null;
        $role=null;
        $data=null;
        $region=null;
        $performance=null;
        // check status
        // check if notify is enabled
        // check if schedule is set
//        dd($this->payslip);
        $payslip=$this->payslip;
        if($payslip->status=='pending' || $payslip->status=='failed'){
            if($payslip->notify){
                $this->delay($payslip->schedule_notify);
                $staff=Staff::find($payslip->staff_id);
                $staff_role=StaffRole::where('staff','=',$staff->id)->first();
                $role=Role::find($staff_role->role);
                $branch=(object) ['name'=>$payslip->branch];
                $region=(object) ['name'=>$payslip->region];
                $performance_heads= $payslip->performance_heads;
                $email=$staff->email;
                $bank=DB::table('hrm_banks')
                    ->where('id',$staff->bank)
                    ->first();
                $data=(object)[
                    'month'=>$payslip->month,
                    'year'=>$payslip->year,
                    'retainer'=>$payslip->earnings->basic_pay ?? $role->retainer,
                    'performance'=>$payslip->performance_heads,
                    'commissions'=>$payslip->earnings->commissions,
                    'bonuses'=>$payslip->earnings->bonuses,
                    'total_other'=>$payslip->earnings->total_other,
                    'gratuity'=>$payslip->earnings->gratuity,
                    'total_earned'=>$payslip->total_earnings,
                    'total_paid'=>$payslip->taxable_earnings,
                    'paye'=>$payslip->deductions->paye,
                    'nhif'=>$payslip->deductions->nhif,
                    'nssf'=>$payslip->deductions->nssf,
                    'helb'=>$payslip->deductions->helb,
                    'sacco'=>$payslip->deductions->sacco,
                    'sacco_loan'=>$payslip->deductions->sacco_loan,
                    'welfare'=>$payslip->deductions->welfare,
                    'other_deductions'=>$payslip->deductions->other_deductions,
                    'total_deductions'=>$payslip->total_deductions,
                    'net_pay'=>$payslip->net_pay,
                    'tax_type'=>$role->tax_type,
                    'role_security'=>$payslip->role_security
                ];
                $role=(object)[
                    'title'=>$role->title
                ];
                $staff=(object)[
                    'name'=>$staff->name,
                    'id'=>$staff->id,
                    'telephone'=>$staff->telephone,
                    'status'=>$staff->status,
                    'pay_mode'=>$staff->pay_mode,
                    'ac_number'=>$staff->ac_number,
                    'join_date'=>$staff->join_date
                ];
                $performance=$performance_heads;
                $template_name=null;
                switch ($payslip->template){
                    case 'hq':
                        $template_name='HQ';
                        break;
                    case 'admin':
                        $template_name='admin';
                        break;
                    case 'admin_reliever':
                        $template_name='admin_relievers';
                        break;
                    case 'bs':
                        $template_name='BS';
                        break;
                    case 'lo':
                        $template_name='LO';
                        break;
                    case 'rm':
                        $template_name='RM';
                        break;
                    case 'ro':
                        $template_name='RO';
                        break;
                    default:
                        Log::emergency('Template file not found for :'.$payslip->template);
                        return;
                }
                $path=Storage::disk('local')->path('');
                $file_name="payslip".$payslip->id.$staff->id.".pdf";
                if(Facade::loadView($template_name,compact(
                    'staff',
                    'data',
                    'role',
                    'branch',
                    'region',
                    'performance',
                    'bank'
                ))->save($path.$file_name)){
                    Mail::to($email)->send(new PayslipMail($file_name));
                }
            }
        }
    }
}
