<?php

namespace App\Jobs;

use App\Deduction;
use App\PAYEE;
use App\Staff;
use App\StaffDeduction;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class ProcessPayroll implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $retainer=0;
    private $net=0;
    private $gross=0;
    private $deductions=0;
    private $allowances=0;
    private $taxable=0;
    private $payee=0;
    private $rate=0;
    private $payeeWithRelief=0;
    private $relief=0;
    private $totalDeductions=[];
    private $totalAllowances=[];
    private $benefits=0;
    private $benefitsData=[];


    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // list all the staff with their relevant retainers

        $employees=DB::table('hrm_staff')
            ->join('hrm_staff_roles','hrm_staff.id','=','hrm_staff_roles.staff')
            ->join('hrm_roles','hrm_staff_roles.role','=','hrm_roles.id')
            ->get();

        $employeeData=[];
        foreach ($employees as $employee) {
            // set the base pay for the employee
            $this->retainer=$employee->retainer;

            // calculate all the global allowances
            $this->addGlobalAllowances();

            // calculate all the staff's allowances
            $this->addAllowances($employee->staff);

            // calculate all the global deductions
            $this->doGlobalDeductions();

            // calculate all the staff deductions
            $this->doDeductions($employee->staff);

            // calculate gross
            $this->calculateGross();

            // calculate benefits
            $this->calculateNssf();

            // calculate the total taxable income
            $this->calculateTaxableIncome();

            // calculate the total payee (without relief)
            $this->calculatePayee();

            // set the relief
            $this->addRelief();

            // calculate the net pay after relief and deducting payee
            $this->calculateNet();

            $employeeData[$employee->staff]=[
                'basic'=>$this->retainer,
                'gross'=>$this->gross,
                'taxable'=>$this->taxable,
                'relief'=>$this->relief,
                'net'=>$this->net,
                'payee'=>$this->payee,
                'payeeRelief'=>$this->payeeWithRelief,
                'total_deductions'=>$this->deductions,
                'total_allowances'=>$this->allowances,
                'deductions'=>$this->totalDeductions,
                'allowances'=>$this->totalAllowances,
                'total_benefits'=>$this->benefits,
                'benefits'=>$this->benefitsData
            ];
        }

        return json_encode($employeeData);

        // get all the leave days which has no full pay
        
    }

    public function doGlobalDeductions()
    {
        $globalDeductions=Deduction::where('scope',1)->get();
        foreach ($globalDeductions as $globalDeduction) {
            $this->totalDeductions[]=['name'=>$globalDeduction->name,'amount'=>$globalDeduction->amount,'description'=>$globalDeduction->short_description];
        }
        $total=$globalDeductions->sum('amount');
        $this->deductions+=$total;
    }

    public function addGlobalAllowances()
    {

    }

    public function doDeductions($staff_id)
    {
        $total=0;

        $currentMonth=Carbon::now()->month;
        $currentYear=Carbon::now()->year;

        $staff_deductions=StaffDeduction::where('staff_id','=',$staff_id)
            ->where('start_month','<=',$currentMonth)
            ->where('start_year','<=',$currentYear)
            ->where('stop_month','>=',$currentMonth)
            ->where('stop_year','>=',$currentYear)
            ->get();
        if($staff_deductions->count()>0){
            foreach ($staff_deductions as $staff_deduction) {
                $this->totalDeductions[]=['type'=>$staff_deduction->type,'amount'=>$staff_deduction->amount,'description'=>$staff_deduction->description];
            }
            $total=$staff_deductions->sum('amount');
        }

        $this->deductions+=$total;
    }

    public function addAllowances($staff_id)
    {
    }

    public function calculateGross()
    {
        $this->gross=$this->retainer+$this->allowances;
    }

    public function calculatePayee()
    {
        $payees=PAYEE::orderBy('monthly_lower','asc')->get();

        $untaxed=$this->taxable;
        $tax_amount=0;
        $total_amount=0;
        foreach ($payees as $payee) {
            if($untaxed>0) {
                if($payee->monthly_upper==0){
                    $untaxed=$this->taxable-$total_amount;
                    $tax_amount+=$untaxed*$payee->rate/100;
                }else {
                    $amount = $payee->monthly_upper - $payee->monthly_lower;
                    $total_amount=$total_amount+$amount;
                    $tax_amount += $amount * ($payee->rate / 100);
                }
            }
        }
        $this->payee=$tax_amount;
    }

    public function addRelief()
    {
        $this->relief=2400;
        $this->payeeWithRelief=$this->payee-$this->relief;
    }

    public function calculateNet()
    {
        $this->net=$this->taxable-($this->payee-$this->relief)-$this->deductions;
    }

    public function calculateNssf()
    {
        $this->benefitsData[]=[
            'nssf'=>200
        ];
        $this->benefits=200;
    }

    public function calculateTaxableIncome()
    {
        $this->taxable=$this->gross-$this->benefits;
    }
}
