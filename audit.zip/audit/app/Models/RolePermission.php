<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, $role)
 */
class RolePermission extends Model
{
    protected $table='permissions_role';

    protected $casts=[
        'permissions'=>'array'
    ];

    protected $fillable=[
        'role_id',
        'permissions'
    ];
}
