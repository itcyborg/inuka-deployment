<?php

namespace App\Policies;

use App\Http\Controllers\Authorize;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class HistoryPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }


    public function history(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'audit_list_history');
    }
}
