<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AuditResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return parent::toArray($request);
//        return [
//            'sequence'=>$this->sequence,
//            'uuid'=>$this->uuid,
//            'batch_id'=>$this->batch_id,
//            'family_hash'=>$this->family_hash,
//            'should_display_on_index'=>$this->should_display_on_index,
//            'service'=>$this->service,
//            'type'=>$this->type,
//            'content'=>$this->content,
//            'created_at'=>$this->created_at
//        ];
    }
}
