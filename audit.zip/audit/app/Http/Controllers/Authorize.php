<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\RolePermission;
use Illuminate\Support\Facades\Cache;
use Throwable;

/**
 * Class Authorize
 *
 * @package App\Http\Controllers
 * @author  isaac
 */
class Authorize extends Controller
{
    /**
     * @param $role
     * @param $action
     *
     * @return bool
     * @author isaac
     */
    public static function action($role,$action): bool
    {
        try {
            // get the permissions for that role
            $permissions = Cache::remember('role_' . $role, 150, function () use ($role) {
                return RolePermission::where('role_id', $role->role)->first();
            });
            if (in_array($action, $permissions->permissions) == true) {
                return true;
            } else {
                return false;
            }
        }catch (Throwable $e){
            return false;
        }
    }

    /**
     * @param $user
     *
     * @return mixed
     * @author isaac
     */
    public static function getRole($user)
    {
        // get the role of the user
        return Role::where('staff',$user->staff_id)->first();
    }
}
