<?php

namespace App\Http\Controllers;

use App\Http\Resources\AuditResource;
use App\Models\Audit;
use App\Models\History;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class AuditController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return AuditResource|Response
     */
    public function audit()
    {
        $this->authorize('audit',Audit::class);
        return new AuditResource(Audit::orderBy('created_at','desc')->paginate(50));
    }

    public function history()
    {
        $this->authorize('history',History::class);
        return new \App\Http\Resources\HistoryResource(\App\Models\History::orderBy('created_at','desc')->paginate(50));
    }
}
