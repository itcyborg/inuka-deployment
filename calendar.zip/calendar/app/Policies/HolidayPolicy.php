<?php

namespace App\Policies;

use App\Http\Controllers\Authorize;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class HolidayPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function store(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'calendar_save_holiday');
    }

    public function update(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'calendar_update_holiday');
    }

    public function destroy(User $user)
    {
        $role=Authorize::getRole($user);
        return Authorize::action($role,'calendar_delete_holiday');
    }
}
