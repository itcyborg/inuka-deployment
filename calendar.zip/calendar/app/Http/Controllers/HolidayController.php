<?php


    namespace App\Http\Controllers;


    use App\Holiday;
    use Carbon\Carbon;
    use Illuminate\Http\Request;

    class HolidayController extends Controller
    {
        public function index()
        {
            $holidays= Holiday::select(['calendar_date','log_id as id','name','recurrent','remarks','status'])->get();
            if(is_null($holidays)||empty($holidays) ||count($holidays)<1){
                return response()->json(['message'=>'No holiday found!']);
            }
            return response()->json(['message'=>'Holidays found!','data'=>$holidays]);
        }

        public function store(Request $request)
        {
            // $this->authorize('store',Holiday::class);
            $this->validate($request,[
                'name'=>'required',
                'holiday'=>'required',
                'description'=>'required',
                'recurrent'=>'required',
            ]);
            $date=Carbon::parse($request->holiday)->toDateString();
            try {
                $holiday=Holiday::create([
                    'name' => $request->name,
                    'remarks' => $request->description,
                    'calendar_date' => $date,
                    'recurrent' => $request->recurrent,
                ]);
                return response()->json(['message'=>'Holiday created!','data'=>$holiday]);
            }catch (\Throwable $e){
                return response()->json(['message'=>'Error creating holiday!','error'=>$e->getMessage()]);
            }
        }

        public function show($id)
        {
            try {
                $holiday=Holiday::where('log_id',$id)->select(['calendar_date','log_id as id','name','recurrent','remarks','status'])->first();
                if(is_null($holiday)||empty($holiday)){
                    return response()->json(['message'=>'Holiday not found!'],404);
                }
                return response()->json(['message'=>'Holiday found!','data'=>$holiday]);
            }catch (\Throwable $e){
                return response()->json(['message'=>'Error','error'=>$e->getMessage()],500);
            }
        }

        public function update(Request $request,$id)
        {
            // $this->authorize('update',Holiday::class);
            try{
                $holiday=Holiday::where('log_id',$id)->first();
                $date=Carbon::parse($request->holiday)->toDateString();
                $holiday->update([
                    'name' => $request->name,
                    'remarks' => $request->description,
                    'calendar_date' => $date,
                    'recurrent' => $request->recurrent,
                ]);
                return response()->json(['message'=>'Holiday updated!','data'=>$holiday]);
            }catch (\Throwable $e){
                return response()->json(['message'=>'Error occurred!','error'=>$e->getMessage()],500);
            }
        }

        public function destroy(Holiday $holiday)
        {
            // $this->authorize('destroy',Holiday::class);
            if($holiday->delete()){
                return response('Holiday deleted successfully',200);
            }
            abort(500,'An error occurred deleting holiday');
        }

        public function isWorkingDay(Request $request)
        {
            $this->validate($request,[
                'date'=>'required'
            ]);

            $date=Carbon::parse($request->date);
            if($date->isSunday()){
                return response()->json(['message'=>'Not a working day']);
            }
            $holiday=Holiday::whereDate('holiday',$date)->count();
            if($holiday<1){
                return response()->json(['message'=>'Working day']);
            }else{
                return response()->json(['message'=>'Not a working day']);
            }
        }

        public function between(Request $request)
        {
            $this->validate($request,[
               'start_date'=>'required|date',
               'end_date'=>'required|date|after:start_date'
            ]);
            $holidays=Holiday::whereBetween('calendar_date',[
                Carbon::parse($request->start_date)->toDateString(),
                Carbon::parse($request->end_date)->toDateString()
            ])->get();

            $start=Carbon::parse($request->start_date);
            $end=Carbon::parse($request->end_date);
            $weekends=[];
            for ($i=$start;!$i->isSameDay($end);$i->addDay()){
                if($i->isWeekend()){
                    $weekends[]=$i->toDateString();
                }
            }

            return response()->json([
                'holidays'=>$holidays,
                'weekends'=>$weekends
            ]);
        }
    }
