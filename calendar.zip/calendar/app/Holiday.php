<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use OwenIt\Auditing\Contracts\Auditable;

class Holiday extends Model implements Auditable
{

    use \OwenIt\Auditing\Auditable;

    protected $primaryKey='log_id';

    protected $fillable=['name','remarks','calendar_date','recurrent'];

    protected static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->log_id = (string) Str::uuid();
        });
    }
}
