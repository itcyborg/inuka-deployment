<?php

namespace App\Http\Controllers;

use Illuminate\Http\Response;
use Laravel\Passport\Http\Controllers\AccessTokenController;
use Psr\Http\Message\ServerRequestInterface;

class ApiTokenController extends AccessTokenController
{
    /**
     * @param ServerRequestInterface $request
     *
     * @return Response
     * @author isaac
     */
    public function issuePassportToken(ServerRequestInterface $request)
    {
        // dd($request);
        return $this->issueToken($request);
    }
}
