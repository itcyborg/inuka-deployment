<?php

namespace App\Http\Controllers;

use App\RolePermission;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;

class RolePermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return RolePermission[]|Collection|Response
     */
    public function index()
    {
        return response()->json(RolePermission::all());
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'role_id',
            'permissions'
        ]);

        return RolePermission::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param $id
     *
     * @return Response
     */
    public function show($id)
    {
        return RolePermission::where('role_id',$id)->get();
    }


    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param         $id
     *
     * @return Response
     *
     */
    public function update(Request $request, $id): Response
    {
        $rolePermission=RolePermission::findOrFail($id);
        return $rolePermission->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param $id
     *
     * @return Response
     */
    public function destroy($id): Response
    {
        $rolePermission=RolePermission::findOrFail($id);
        return $rolePermission->delete();
    }

    /**
     * @param Request $request
     * @param         $id
     *
     * @throws ValidationException
     * @author isaac
     */
    public function add(Request $request,$id)
    {
        $this->validate($request,[
            'permissions'=>'required'
        ]);

        $rolePermission=RolePermission::where('role_id',$id)->first();
        $permissions=$rolePermission->permissions;
        foreach ($request->permissions as $permission) {
            array_push($permissions,$permission);
        }
        $rolePermission->permissions=$permissions;
        if($rolePermission->save()){
            return response('Permission added successfully');
        }
        return response('An error occurred adding permission.',500);
    }
}
