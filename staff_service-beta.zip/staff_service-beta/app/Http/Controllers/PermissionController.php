<?php

namespace App\Http\Controllers;

use App\Permission;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \App\Permission[]|\Illuminate\Database\Eloquent\Collection|\Illuminate\Http\Response
     */
    public function index()
    {
        return Permission::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>'required'
        ]);
        return Permission::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Permission  $permission
     * @return \App\Permission|\Illuminate\Http\Response
     */
    public function show(Permission $permission)
    {
        return $permission;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Permission  $permission
     * @return bool|\Illuminate\Http\Response
     */
    public function update(Request $request, Permission $permission)
    {
        return $permission->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Permission $permission
     * @return bool|\Illuminate\Http\Response
     * @throws \Exception
     */
    public function destroy(Permission $permission)
    {
        return $permission->delete();
    }
}
