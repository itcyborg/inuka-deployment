<?php

namespace App\Http\Controllers;

use App\Role;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \App\Role[]|\Illuminate\Database\Eloquent\Collection|\Illuminate\Http\Response
     */
    public function index()
    {
        return Role::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response|string
     */
    public function store(Request $request)
    {
        try {
            $this->validate($request, [
                'role_id' => 'required',
                'staff_id' => 'required'
            ]);
            return Role::create($request->all());
        }catch (ValidationException $e){
            return $e->getMessage();
        }catch (\PDOException $e){
            if($e->getCode()==23000){
                return response('The role for the user id has already been defined.',400);
            }
            return $e->getMessage();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Role  $role
     * @return \App\Role|\Illuminate\Http\Response
     */
    public function show(Role $role)
    {
        return $role;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Role  $role
     * @return bool|\Illuminate\Http\Response
     */
    public function update(Request $request, Role $role)
    {
        return $role->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Role $role
     * @return bool|\Illuminate\Http\Response
     * @throws \Exception
     */
    public function destroy(Role $role)
    {
        return $role->delete();
    }
}
