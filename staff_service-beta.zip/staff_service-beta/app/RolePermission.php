<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @method static create(array $all)
 * @method static findOrFail($id)
 * @method static find($id)
 */
class RolePermission extends Model implements Auditable
{
    use \OwenIt\Auditing\Auditable;

    protected $table='permissions_role';

    protected $fillable=[
        'role_id',
        'permissions'
    ];

    protected $casts=[
        'permissions'=>'array'
    ];
}
