<?php

namespace App\Policies;

use App\RolePermission;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class RolePermissionPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any role permissions.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the role permission.
     *
     * @param  \App\User  $user
     * @param  \App\RolePermission  $rolePermission
     * @return mixed
     */
    public function view(User $user, RolePermission $rolePermission)
    {
        //
    }

    /**
     * Determine whether the user can create role permissions.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the role permission.
     *
     * @param  \App\User  $user
     * @param  \App\RolePermission  $rolePermission
     * @return mixed
     */
    public function update(User $user, RolePermission $rolePermission)
    {
        //
    }

    /**
     * Determine whether the user can delete the role permission.
     *
     * @param  \App\User  $user
     * @param  \App\RolePermission  $rolePermission
     * @return mixed
     */
    public function delete(User $user, RolePermission $rolePermission)
    {
        //
    }

    /**
     * Determine whether the user can restore the role permission.
     *
     * @param  \App\User  $user
     * @param  \App\RolePermission  $rolePermission
     * @return mixed
     */
    public function restore(User $user, RolePermission $rolePermission)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the role permission.
     *
     * @param  \App\User  $user
     * @param  \App\RolePermission  $rolePermission
     * @return mixed
     */
    public function forceDelete(User $user, RolePermission $rolePermission)
    {
        //
    }
}
