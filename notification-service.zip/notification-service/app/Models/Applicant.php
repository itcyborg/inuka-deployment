<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use OwenIt\Auditing\Contracts\Auditable;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;

class Applicant extends Model
{
    use Notifiable;

    protected $guarded = [
        'id', 'created_at', 'updated_at'
    ];

    protected $casts = [
        'jobs.pivot.id' => 'string',
    ];

    protected $fillable = [
        'log_id',
        'first_name',
        'last_name',
        'middle_name',
        'gender',
        'age',
        'permanent_address',
        'physical_address',
        'email_address',
        'phone_number',
        'highest_education_level',
        'education_summary',
        'status',
        'resume',
        'cover_letter',
        'applied_date',
        'candidates'
    ];

    public static function boot()
    {
        parent::boot();
        self::creating(function ($model) {
            $model->log_id = (string) Str::uuid();
            $model->status = 0;
        });
    }

    public function setDateAttribute($value)
    {
        $this->attributes['applied_date'] = (new Carbon($value))->format('Y/m/d H:i:s');
    }

    public function getSearchResult(): SearchResult
    {
        $url = route('applicant.show', $this->id);

        return new SearchResult(
            $this,
            $this->first_name,
            $this->middle_name,
            $this->last_name,
            $this->email,
            $this->phone,
            $this->phone,
            $this->cover_letter,
            $this->applied_date,
            $url
         );
    }

    public function jobOpenings()
    {
        return $this->belongsToMany(JobOpening::class, 'applicant_job_opening', 'applicant_id', 'id');
    }

    public function questionnaires()
    {
        return $this->hasMany(Questionnaire::class);
    }

    public function pools()
    {
        return $this->belongsToMany(Pool::class);
    }

    public function results()
    {
        // return $this->belongsToMany(TestResult::class, 'test_results', 'candidate_id', 'id')->withTimestamps();
        return $this->hasMany(TestResult::class, 'candidate_id', 'id');
    }
}
