<?php

namespace App\Jobs;

use App\Models\Notification;
use App\Notifications\SendNotificationMessage;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        /**
         * Get all unsent notifications and send them to the relevant parties
         *
         */
        $notifications = Notification::where('sent_at', null)->get();

        foreach ($notifications as $notification) {
            $mailMessage = new MailMessage();
            // check if the notifiable class exists
            if (class_exists($notification->notifiable_type)) {
                // check if the model exists
                $notifiable = ($notification->notifiable_type)::find($notification->notifiable_id);
                print_r($notifiable);
                Log::info($notifiable);
                $message = (object) $notification->data;
                if ($notifiable) {
                    // check if the message starts with a body key
                    if (isset($message->body)) {
                        // put the contents of the body key to the message, sort of make it flat
                        $message=(object) $message->body;
                    }


                    #######################
                    /**
                     * Everything from here should be plug and play though needs verification and validation
                     */
                    #######################

                    // build the notification message
                    if (isset($message->priority)) {
                        $mailMessage->priority($message->priority);
                    }

                    if (isset($message->type)) {
                        // the default type/ level is info, this ships with laravel

                        // override the default if it needs overriding
                        if ($message->type == 'success') {
                            $mailMessage->success();
                        } elseif ($message->type == 'error') {
                            $mailMessage->error();
                        }
                    }

                    if (isset($message->title)) {
                        $mailMessage->subject($message->title);
                    }

                    if (isset($message->message)) {
                        // look for a line break and split the string where the linebreak exists

                        $lines = explode('\n', $message->message);

                        // loop through the lines removing empty spaces and dynamically creating the lines in the mail message object
                        foreach ($lines as $line) {
                            $mailMessage->line(trim($line));
                        }
                    }

                    if (isset($message->email)) {

                    }else{
                        if(isset($notifiable->email_address)){
                            $notifiable->email=$notifiable->email_address;
                            $message->email=$notifiable->email_address;
                        }elseif(isset($notifiable->email)){
                            $message->email=$notifiable->email_address;
                        }
                    }

                    if (isset($message->Name)) {

                    }

                    if (isset($message->phone)) {

                    }

                    if (isset($message->action)) {
                        // if action object/array is comprised of ['name'=>'Click Me','url'=>'https://example.com']
                        $mailMessage->action((isset($message->action->name)) ? $message->action->name : 'Click me', (isset($message->action->url)) ? $message->action->url : $message->action);
                    }

                    if (isset($message->actions)) {
                        foreach ($message->actions as $action) {
                            $mailMessage->action($action->name, $action->url);
                        }
                    }

                    if (isset($message->attachments)) {
                        foreach ($message->attachments as $attachment) {
                            $mailMessage->attach($attachment);
                        }
                    }

                    if (isset($message->attachment)) {
                        $mailMessage->attach($message->attachment);
                    }

                    // send the notification
                    $notifiable->notify(new SendNotificationMessage($mailMessage));
                    $notification->sent_at=Carbon::now()->toDateString();
                    $notification->save();
                }
            } else {
                // notify the developer/ it support or Log it
                Log::critical('Could not send some notifications. Probable cause is a missing notifiable class or class could not be found. ['.$notification->notifiable_type.']');
            }
        }
    }
}
